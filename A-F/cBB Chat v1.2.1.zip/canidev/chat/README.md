# cBB Chat Extension

## Install

1. Download the latest release and unzip the package.
2. Upload the content of the 'upload' directory to the 'ext' directory of your forum.
3. Navigate in the ACP to 'Customise -> Manage extensions'.
4. Look for "cBB Chat" under the Disabled Extensions list, and click its 'Enable' link.
5. Set up and configure the chat by navigating in the ACP to 'Extensions -> Chat'.


## Update

1. Download the latest release and unzip the package.
2. Navigate in the ACP to 'Customise -> Extension Management -> Extensions', look for 'cBB Chat' and click on 'Disable' link.
3. Delete the folder 'chat' which is within the directory '/ext/canidev/' in the server.
4. Upload the content of the 'upload' directory to the 'ext' directory of your forum.
5. In ACP, Look for "cBB Chat" under the Disabled Extensions list, and click its 'Enable' link.

## Uninstall

1. Navigate in the ACP to 'Customise -> Extension Management -> Extensions'.
2. Look for 'cBB Chat' under the Enabled Extensions list, and click its 'Disable' link.
3. To permanently uninstall, click 'Delete Data' and then delete the '/ext/canidev/chat' directory.

## License
[GNU General Public License v2](https://opensource.org/licenses/GPL-2.0)
