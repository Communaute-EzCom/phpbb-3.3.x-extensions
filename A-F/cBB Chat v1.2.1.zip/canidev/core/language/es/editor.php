<?php
/*
* editor.php [Spanish [Es]]
* @package Ext Common Core
* @version v1.0.6 01/04/2020
*
* @copyright (c) 2020 CaniDev
* @license https://opensource.org/licenses/gpl-license.php GNU Public License
*/

// @ignore
if(!defined('IN_PHPBB'))
{
	exit;
}

if(empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'AUTHOR'					=> 'Autor:',
	'CODE'						=> 'Código',
	'DATE'						=> 'Fecha:',
	'DESCRIPTION_OPTIONAL'		=> 'Descripción (Opcional):',
	'INSERT'					=> 'Insertar',
	'MAXIMIZE'					=> 'Maximizar editor',
	'PRINT'						=> 'Imprimir',
	'REMOVE_FORMAT'				=> 'Quitar Formatos',
	'UNLINK'					=> 'Quitar Vínculo',
	'URL'						=> 'Url:',
	'VIEW_SOURCE'				=> 'Ver Código',
));
