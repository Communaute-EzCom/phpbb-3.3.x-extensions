<?php
/*
* @package Ext Common Core
* @version v1.0.6 01/04/2020
*
* @copyright (c) 2020 CaniDev
* @license https://opensource.org/licenses/gpl-license.php GNU Public License
*/

/*
* Compatibility is obsoleted, this file is for avoid problems on extension updates
*/

namespace canidev\core\compatibility;

class base extends \canidev\core\plugins\base
{
}
