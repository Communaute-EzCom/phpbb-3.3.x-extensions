<?php
/**
 * 
 * Avatars on Memberlist
 * 
 * @copyright (c) 2015 Wolfsblvt ( www.pinkes-forum.de )
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 * @author Clemens Husung (Wolfsblvt)
 */

namespace wolfsblvt\avatarsonmemberlist;

class ext extends \phpbb\extension\base
{
}
