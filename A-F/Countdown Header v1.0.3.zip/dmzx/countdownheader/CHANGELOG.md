## Changelog

### 1.0.3 - 2019-01-09

- Twig update
- URL update

### 1.0.2 - 2017-05-02

- Added admin_controller
- Added acp language file
- Updated listener
- Updated acp_countdownheader_config.html
- Updated overall_header_breadcrumbs_after.html

### 1.0.1 - 2016-12-16

- Update code

### 1.0.0 - 2016-12-16

- First release
