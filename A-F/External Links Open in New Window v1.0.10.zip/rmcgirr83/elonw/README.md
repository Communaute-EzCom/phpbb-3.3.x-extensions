ELONW
=========================

phpBB extension that uses jQuery to force external links to open in a new window when clicked on.



[![Build Status](https://travis-ci.com/rmcgirr83/elonw.svg?branch=master)](https://travis-ci.com/rmcgirr83/elonw)
## Installation

### 1. clone
Clone (or download and move) the repository into the folder ext/rmcgirr83/elonw:

```
cd phpBB3
git clone https://github.com/rmcgirr83/elonw.git ext/rmcgirr83/elonw/
```

### 2. activate
Go to admin panel -> tab customise -> Manage extensions -> enable External Links in New Window

