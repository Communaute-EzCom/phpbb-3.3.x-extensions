<?php
/**
*
* @package phpBB Extension - FranckTH calendrierdanssujet
* @copyright (c) 2018 FranckTH
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace franckth\calendrierdanssujet\event;

/**
* @ignore
*/
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{

	static public function getSubscribedEvents()
	{
		return array(
			'core.viewtopic_modify_post_row'	=> 'add_calendar',
		);
	}

	/** @var \phpbb\config\config */
	protected $config;

	/* @var \phpbb\template\template */
	protected $template;

	/* @var \phpbb\user */
	protected $user;

	/**
	* Constructor
	*
	* @param \phpbb\config\config		$config			Config object
	* @param \phpbb\template			$template		Template object
	* @param \phpbb\user				$user			User object
	*/

	public function __construct(\phpbb\config\config $config, \phpbb\template\template $template, \phpbb\user $user)
	{
		$this->user			= $user;
		$this->template		= $template;
		$this->is_phpbb31	= phpbb_version_compare($config['version'], '3.1.0@dev', '>=') && phpbb_version_compare($config['version'], '3.2.0@dev', '<');
		$this->is_phpbb32	= phpbb_version_compare($config['version'], '3.2.0@dev', '>=') && phpbb_version_compare($config['version'], '3.3.0@dev', '<');
	}

	public function add_calendar($event)
	{
		$row = $event['row'];
		$event['post_row'] = array_merge($event['post_row'], array(
			'MOIS'		=> $this->user->format_date($row['post_time'], 'M Y', false),
			'DATE'				=> $this->user->format_date($row['post_time'], 'd', false),
			'JOUR'			=> $this->user->format_date($row['post_time'], 'l', false),
			'TIME_POST'			=> $this->user->format_date($row['post_time'], 'H:i', false),
		));
	}
}