;(function($, document)
{
	'use strict';

	$('.collapsible').click(function()
	{
		$('.donate-content').slideToggle('slow');
	});
})(jQuery, document);
