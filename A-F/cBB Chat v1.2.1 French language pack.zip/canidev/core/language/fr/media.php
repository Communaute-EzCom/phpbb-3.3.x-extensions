<?php
/**
*
* media.php [French [Fr]] translation by Galixte (http://www.galixte.com)
* @package Ext Common Core for the cBB Chat extension.
* @version v1.0.6 01/04/2020
*
* @copyright (c) 2020 CaniDev
* @license https://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//


$lang = array_merge($lang, array(
	'COPY_TO_LIST'			=> 'Copier la liste actuelle',
	'CREATE_SERVER_COPY'	=> 'Créer une copie sur ce serveur',
	'DELETE_FROM_LIST'		=> 'Supprimer de la liste',
	'DELETE_ICON'			=> 'Supprimer l’icône',
	'DELETE_IMAGE'			=> 'Supprimer l’image',
	'DELETE_PERMANENTLY'	=> 'Supprimer définitivement',
	'ICON_PREVIEW'			=> 'Aperçu de l’icône',
	'IMAGE_DESCRIPTION'		=> 'Description',
	'IMAGE_DETAILS'			=> 'Détails de l’image',
	'IMAGE_DIMENSIONS'		=> '<%width%> × <%height%> pixels',
	'IMAGE_SAVE_ERROR'		=> 'Impossible de sauvegarder l’image',
	'IMAGE_TITLE'			=> 'Titre',
	'IMAGE_URL'				=> 'URL',
	'INSERT_ON_ENTRY'		=> 'Insérer dans le texte',
	'FILES_DELETED'			=> 'Fichiers supprimés',
	'FILES_DRAG'			=> 'Glisser-déposer des fichiers à envoyer',
	'FILES_DROP'			=> 'Déposer des fichiers à envoyer',
	'FILES_REMOVE_CONFIRM'	=> 'Confirmer la suppression des fichiers sélectionnés.',
	'FORMAT_INVALID'		=> 'Format invalide',
	'MAX_FILESIZE'			=> 'Poids maximal du fichier : %s.',
	'MEDIA_UPDATED'			=> 'Modifications sauvegardées',
	'PROCCESS'				=> 'Processus',
	'SELECT_ICON'			=> 'Sélectionner une nouvelle icône',
	'SELECT_IMAGE'			=> 'Sélectionner une nouvelle image',
	'SELECT_FILE'			=> 'Sélectionner un fichier',
	'SELECT_FILES'			=> 'Sélectionner des fichiers',
	'SELECTED_COUNT'		=> '<span class="value">0</span> sélectionné',
	'SET_ICON'				=> 'Définir une icône',
	'SET_IMAGE'				=> 'Définir une image',
	'UPDATE'				=> 'Mettre à jour',
	'UPLOADING_FILES'		=> 'Envoi de fichiers…',
	
	'CURRENT_LIST'		=> 'Liste actuelle',
	'GALLERY'			=> 'Galerie',
	'ICONS'				=> 'Icônes',
	'INSERT_URL'		=> 'Insérer depuis l’URL',
	'UPLOAD_IMAGE'		=> 'Envoyer une image',
	
	'ICON_BRAND'			=> 'Marque',
	'ICON_DIRECTIONAL'		=> 'Directionnel',
	'ICON_FILE_TYPE'		=> 'Type de fichier',
	'ICON_GENDER'			=> 'Genre',
	'ICON_HAND'				=> 'Main',
	'ICON_MEDICAL'			=> 'Médical',
	'ICON_PAYMENT'			=> 'Paiement et monnaie',
	'ICON_TEXT_EDITOR'		=> 'Éditeur de texte',
	'ICON_TRANSPORTATION'	=> 'Transport',
	'ICON_VIDEO_PLAYER'		=> 'Lecteur vidéo',
	'ICON_WEB_APPLICATION'	=> 'Application Web',
));
