# Changelog

## 1.0.1 - 06-08-2017

- Mise en place d'un favicon de base

## 1.0.0 - 21-08-2016

- Première version de l'extension