<?php
/**
*
* @package phpBB Extension - Dernieres Creations
* @copyright (c) 2018 franckth
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/


/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
   exit;
}

if (empty($lang) || !is_array($lang))
{
   $lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(

    'ACP_AVATARS'                    => 'Dernières Créations',
    'ACP_AVATARS_CONFIG'             => 'Gestion des Dernières créations',
    'ACP_AVATARS_CONFIG_EXPLAIN'     => 'Depuis cette page il est possible de modifier les paramètres des dernières créations.',
    'ACP_AVATARS_CONFIG_SET'         => 'Paramètres',
    'AVATARS_CONFIG_SAVED'           => 'Les paramètres des dernières créations ont été sauvegardés avec succès !',

    'AVATARS_ACTIVATED'              => 'Activer l’affichage des dernières créations',
    'AVATARS_INDEX'                  => 'Afficher les dernières créations uniquement sur la page de l’index du forum',
    'AVATARS_MEMBER'                 => 'Afficher les dernières créations uniquement aux membres du forum',
	'AVATARS_SPEED'					 => 'Vitesse de défilement des créations',
	'AVATARS_SPEED_EXPLAIN'			 => 'Permet de saisir la durée en secondes de l’affichage d’un cycle du défilement des dernières créations. Par défaut cette période est définie sur 10 secondes.<br />Plus la valeur est importante et moins le défilement sera rapide, moins la valeur est importante et plus le défilement sera rapide.',

    'AVATARS_TEXT'                   => 'Texte des dernières créations',
    'AVATARS_TEXT_EXPLAIN'           => 'Permet de saisir le texte à aficher dans les dernières créations.',

    'AVATARS_PREVIEW'                => 'Aperçu des dernières créations',
    'AVATARS_PREVIEW_EXPLAIN'        => 'Permet d’afficher un aperçu de l’affichage des dernières créations sans avoir à activer l’affichage de celles-ci.',

));
