<?php
/**
*
* @package phpBB Extension - News Avatars
* @copyright (c) 2018 franckth
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace franckth\avatars\acp;

class avatars_module
{
	/** @var \phpbb\config\config */
	protected $config;

	/** @var \phpbb\config\db_text */
	protected $config_text;

	/** @var \phpbb\db\driver\driver_interface */
	protected $db;

	/** @var \phpbb\log\log */
	protected $log;

	/** @var \phpbb\request\request */
	protected $request;

	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/** @var string */
	protected $phpbb_root_path;

	/** @var string */
	protected $php_ext;

	/** @var string */
	public $u_action;

	public function main($id, $mode)
	{
		global $config, $db, $phpbb_log, $request, $template, $user, $phpbb_root_path, $phpEx, $phpbb_container;

		$this->config = $config;
		$this->config_text = $phpbb_container->get('config_text');
		$this->db = $db;
		$this->log = $phpbb_log;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		$this->phpbb_root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;

		// Add the posting lang file needed by BBCodes
		$this->user->add_lang(array('posting'));

		// Add the avatars ACP lang file
		$this->user->add_lang_ext('franckth/avatars', 'info_acp_avatars');

		// Load a template from adm/style for our ACP page
		$this->tpl_name = 'acp_avatars_config';

		// Set the page title for our ACP page
		$this->page_title = 'ACP_AVATARS_CONFIG';

		// Define the name of the form for use as a form key
		$form_name = 'acp_avatars_config';
		add_form_key($form_name);

		// Set an empty error string
		$error = '';

	  	// Include files needed for displaying BBCodes
		if (!function_exists('display_custom_bbcodes'))
		{
			include($this->phpbb_root_path . 'includes/functions_display.' . $this->php_ext);
		}

		// Get all avatars data from the config_text table in the database
		$data = $this->config_text->get_array(array(
			'news_avatars_text',
			'news_avatars_uid',
			'news_avatars_bitfield',
			'news_avatars_options',
			'news_avatars_speed',
		));

		$submit = $this->request->is_set_post('submit');

		if ($submit)
		{
			if (!check_form_key('acp_avatars_config'))
			{
				trigger_error('FORM_INVALID');
			}
			$this->config->set('avatars_activated', $this->request->variable('avatars_activated', 0));
			$this->config->set('avatars_index', $this->request->variable('avatars_index', 0));
			$this->config->set('avatars_member', $this->request->variable('avatars_member', 0));

			// Get new avatars text from the form
			$data['news_avatars_text'] = $this->request->variable('avatars_text', '', true);
			$data['news_avatars_speed'] = $this->request->variable('avatars_speed', '', true);

			// Prepare avatars text for storage
			generate_text_for_storage(
				$data['news_avatars_text'],
				$data['news_avatars_uid'],
				$data['news_avatars_bitfield'],
				$data['news_avatars_options'],
				!$this->request->variable('disable_bbcode', false),
				!$this->request->variable('disable_magic_url', false),
				!$this->request->variable('disable_smilies', false)
			);

			// Store the avatars settings to the config_table in the database
			$this->config_text->set_array(array(
				'news_avatars_text'			=> $data['news_avatars_text'],
				'news_avatars_uid'			=> $data['news_avatars_uid'],
				'news_avatars_bitfield'		=> $data['news_avatars_bitfield'],
				'news_avatars_options'		=> $data['news_avatars_options'],
				'news_avatars_speed'			=> $data['news_avatars_speed'],
			));

			trigger_error($this->user->lang['AVATARS_CONFIG_SAVED'] . adm_back_link($this->u_action));
		}

			// Get the avatars data for the preview
			$news_avatars_text_preview = generate_text_for_display($data['news_avatars_text'], $data['news_avatars_uid'], $data['news_avatars_bitfield'], $data['news_avatars_options']);

			// Prepare the avatars text for editing inside the textbox
			$news_avatars_text_edit = generate_text_for_edit($data['news_avatars_text'], $data['news_avatars_uid'], $data['news_avatars_options']);

			$template->assign_vars(array(
			'AVATARS_ACTIVATED'		=> (!empty($this->config['avatars_activated'])) ? true : false,
			'AVATARS_INDEX'			=> (!empty($this->config['avatars_index'])) ? true : false,
			'AVATARS_MEMBER'		=> (!empty($this->config['avatars_member'])) ? true : false,
			'S_ERROR'	 => (sizeof($error)) ? true : false,

			'AVATARS_TEXT'				=> $news_avatars_text_edit['text'],
			'AVATARS_PREVIEW'			=> $news_avatars_text_preview,
			'AVATARS_SPEED'				=> $data['news_avatars_speed'],

			'S_BBCODE_DISABLE_CHECKED'		=> !$news_avatars_text_edit['allow_bbcode'],
			'S_SMILIES_DISABLE_CHECKED'		=> !$news_avatars_text_edit['allow_smilies'],
			'S_MAGIC_URL_DISABLE_CHECKED'	=> !$news_avatars_text_edit['allow_urls'],

			'BBCODE_STATUS'			=> $this->user->lang('BBCODE_IS_ON', '<a href="' . append_sid("{$this->phpbb_root_path}faq.{$this->php_ext}", 'mode=bbcode') . '">', '</a>'),
			'SMILIES_STATUS'		=> $this->user->lang('SMILIES_ARE_ON'),
			'IMG_STATUS'			=> $this->user->lang('IMAGES_ARE_ON'),
			'FLASH_STATUS'			=> $this->user->lang('FLASH_IS_ON'),
			'URL_STATUS'			=> $this->user->lang('URL_IS_ON'),

			'S_BBCODE_ALLOWED'		=> true,
			'S_SMILIES_ALLOWED'		=> true,
			'S_BBCODE_IMG'			=> true,
			'S_BBCODE_FLASH'		=> true,
			'S_LINKS_ALLOWED'		=> true,
			'U_ACTION'               => $this->u_action,
		));

		// Build custom bbcodes array
		display_custom_bbcodes();
	}
}
