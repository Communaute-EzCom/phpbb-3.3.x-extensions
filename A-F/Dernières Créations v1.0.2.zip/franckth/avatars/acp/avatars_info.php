<?php
/**
*
* @package phpBB Extension - News Avatars
* @copyright (c) 2018 franckth
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace franckth\avatars\acp;

class avatars_info
{
	public function module()
	{
		return array(
		'filename'  => '\franckth\avatars\acp\avatars_module',
		'title'	 => 'ACP_AVATARS',
			'modes'		=> array(
				'settings'	=> array(
					'title' => 'ACP_AVATARS_CONFIG',
					'auth' => 'ext_franckth/avatars && acl_a_board',
					'cat' => array('ACP_AVATARS')
				),
			),
		);
	}
}
