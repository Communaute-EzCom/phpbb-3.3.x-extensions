<?php
/**
*
* @package phpBB Extension - News Avatars
* @copyright (c) 2018 franckth
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace franckth\avatars\event;

/**
* @ignore
*/
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/

class listener implements EventSubscriberInterface
{
	/** @var \phpbb\template\template */
	protected $template;

    /** @var \phpbb\config\config */
    protected $config;

	/** @var \phpbb\config\db_text */
	protected $config_text;

    static public function getSubscribedEvents()
    {
        return array(
            'core.page_header_after'   => 'add_page_header_link',
        );
    }

    public function __construct(\phpbb\template\template $template, \phpbb\config\config $config, \phpbb\config\db_text $config_text)
    {
        $this->template = $template;
        $this->config = $config;
		$this->config_text = $config_text;
    }

    public function add_page_header_link($event)
    {
		// Get avatars data from the config_text object
		$avatars_text_data = $this->config_text->get_array(array(
			'news_avatars_text',
			'news_avatars_uid',
			'news_avatars_bitfield',
			'news_avatars_options',
			'news_avatars_speed',
		));

		// Prepare avatars for display
		$avatars_message = generate_text_for_display(
			$avatars_text_data['news_avatars_text'],
			$avatars_text_data['news_avatars_uid'],
			$avatars_text_data['news_avatars_bitfield'],
			$avatars_text_data['news_avatars_options']
		);

        $this->template->assign_vars(array(
        'S_AVATARS_ACTIVATED'        => $this->config['avatars_activated'] ? true : false,
        'S_AVATARS_INDEX'            => $this->config['avatars_index'] ? true : false,
        'S_AVATARS_MEMBER'           => $this->config['avatars_member'] ? true : false,
        'S_AVATARS_TEXT'             => $avatars_message,
		'S_AVATARS_SPEED'			=> $avatars_text_data['news_avatars_speed'],
        ));
    }
}
