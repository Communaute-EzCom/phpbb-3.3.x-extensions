<?php
/**
*
* @package phpBB Extension - News Avatars
* @copyright (c) 2018 - franckth
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace franckth\avatars\migrations;

class avatars_1_0_0 extends \phpbb\db\migration\migration
{
	public function update_data()
	{
		return array(
			// Add configs
			array('config.add', array('avatars_activated', '0')),
			array('config.add', array('avatars_index', '0')),
			array('config.add', array('avatars_member', '0')),
			array('config_text.add', array('news_avatars_text', 'Scrolling Text')),
			array('config_text.add', array('news_avatars_uid', '')),
			array('config_text.add', array('news_avatars_bitfield', '')),
			array('config_text.add', array('news_avatars_options', OPTION_FLAG_BBCODE + OPTION_FLAG_SMILIES + OPTION_FLAG_LINKS)),

			// Add the ACP module
			array('module.add', array('acp', 'ACP_CAT_DOT_MODS', 'ACP_AVATARS')),
			array('module.add', array(
				'acp', 'ACP_AVATARS', array(
				'module_basename' => '\franckth\avatars\acp\avatars_module',
				'modes' => array('settings'),
				),
			)),
		);
	}
}
