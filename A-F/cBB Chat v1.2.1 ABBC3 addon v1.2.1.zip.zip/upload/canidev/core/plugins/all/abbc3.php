<?php

namespace canidev\core\plugins\all;

class abbc3 extends \canidev\core\plugins\base
{
	public $name = 'vse/abbc3';

	private $abbc3_icon_path = 'ext/vse/abbc3/images/icons/';
	
	protected $language;
	protected $path_helper;
	protected $routing;
	protected $template;

	public function __construct($container)
	{
		$this->container 		= $container;
		$this->language 		= $container->get('language');
		$this->path_helper 		= $container->get('path_helper');
		$this->routing 			= $container->get('routing.helper');
		$this->template			= \canidev\core\template::get_instance($container);
	}
	
	public function is_runnable()
	{
		return $this->container->get('ext.manager')->is_enabled($this->name);
	}
	
	public function core_events()
	{
		return array(
			'canidev.core.editor_bbcodes_modify_sql'	=> 'on_bbcodes_modify_sql',
			'canidev.core.editor_bbcodes_modify_row'	=> 'on_generate_bbcodes',
		);
	}
	
	public function on_bbcodes_modify_sql($event)
	{
		$sql_ary = $event['sql_ary'];
		$sql_ary['SELECT'] .= ', b.bbcode_group';
		$sql_ary['ORDER_BY'] = 'b.bbcode_order, b.bbcode_id';
		$event['sql_ary'] = $sql_ary;
	}
	
	public function on_generate_bbcodes($event)
	{
		$item 	= $event['custom_tag'];
		$tag 	= strtolower($item['BBCODE_TAG']);

		if($tag == 'font')
		{
			$item['BBCODE_CUSTOM_TEMPLATE'] = $this->font_template($item);
		}
		else
		{
			$imagename	= $this->abbc3_icon_path . $tag . '.gif';

			if(file_exists($this->path_helper->get_phpbb_root_path() . $imagename))
			{
				$item['BBCODE_ICON'] = '<img src="' . $this->path_helper->get_web_root_path() . $imagename . '" alt="" />';
			}
		}

		switch($tag)
		{
			case 'align':
				$item['BBCODE_CODE'] = 'align=center';
			break;

			case 'float':
			case 'marq':
				$item['BBCODE_CODE'] = $tag . '=left';
			break;

			case 'dir':
				$item['BBCODE_CODE'] = 'dir=rtl';
			break;

			case 'mod':
				$item['BBCODE_CODE'] = 'mod=' . $this->container->get('user')->data['username'];
			break;

			case 'highlight':
				$item['BBCODE_CODE'] = 'highlight=yellow';
			break;

			case 'glow':
				$item['BBCODE_CODE'] = 'glow=red';
			break;

			case 'shadow':
			case 'dropshadow':
			case 'blur':
				$item['BBCODE_CODE'] = $tag .  '=blue';
			break;

			case 'bbvideo':
				$item['BBCODE_CODE'] = strtolower($item['BBCODE_CODE']);
			break;
		}

		$event['custom_tag'] = $item;
	}

	protected function font_template($original)
	{
		return '<select data-code="font" class="cbb-inputbox" title="' . $original['BBCODE_HELPLINE'] . '">
			<option selected="selected" >' . $this->language->lang('ABBC3_FONT_BBCODE') . '</option>
			<optgroup label="' . $this->language->lang('ABBC3_FONT_SAFE') . '">
				<option style="font-family: Arial;" value="Arial">Arial</option>
				<option style="font-family: Arial Black;" value="Arial Black">Arial Black</option>
				<option style="font-family: Comic Sans MS;" value="Comic Sans MS">Comic Sans MS</option>
				<option style="font-family: Courier New;" value="Courier New">Courier New</option>
				<option style="font-family: Georgia;" value="Georgia">Georgia</option>
				<option style="font-family: Impact;" value="Impact">Impact</option>
				<option style="font-family: Times New Roman;" value="Times New Roman">Times New Roman</option>
				<option style="font-family: Trebuchet MS;" value="Trebuchet MS">Trebuchet MS</option>
				<option style="font-family: Verdana;" value="Verdana">Verdana</option>
			</optgroup>
			<optgroup label="' . $this->language->lang('ABBC3_FONT_FANCY') . '">
				<option style="font-family: Bradley Hand ITC;" value="Bradley Hand ITC" >Bradley Hand ITC</option>
				<option style="font-family: Century Gothic;" value="Century Gothic" >Century Gothic</option>
				<option style="font-family: Curlz MT;" value="Curlz MT">Curlz MT</option>
				<option style="font-family: cursive;" value="cursive">Cursive</option>
				<option style="font-family: fantasy;" value="fantasy">Fantasy</option>
				<option style="font-family: French Script MT;" value="French Script MT">French Script MT</option>
				<option style="font-family: Garamond;" value="Garamond">Garamond</option>
				<option style="font-family: Garamond Bold;" value="Garamond Bold">Garamond Bold</option>
				<option style="font-family: Goudy Stout;" value="Goudy Stout">Goudy Stout</option>
				<option style="font-family: Helvetica;" value="Helvetica">Helvetica</option>
				<option style="font-family: monospace;" value="monospace">Monospace</option>
				<option style="font-family: OCR A Extended;" value="OCR A Extended">OCR A Extended</option>
				<option style="font-family: Script MT Bold;" value="Script MT Bold">Script MT Bold</option>
			</optgroup>
			<optgroup label="' . $this->language->lang('ABBC3_FONT_WIN') . '">
				<option style="font-family: Lucida Console;" value="Lucida Console">Lucida Console</option>
				<option style="font-family: Lucida Sans Unicode;" value="Lucida Sans Unicode">Lucida Sans Unicode</option>
				<option style="font-family: Microsoft Sans Serif;" value="Microsoft Sans Serif">Microsoft Sans Serif</option>
				<option style="font-family: MS Mincho;" value="MS Mincho">MS Mincho</option>
				<option style="font-family: Palatino Linotype;" value="Palatino Linotype">Palatino Linotype</option>
				<option style="font-family: Symbol;" value="Symbol">Symbol</option>
				<option style="font-family: Tahoma;" value="Tahoma">Tahoma</option>
			</optgroup>
		</select>';
	}

	public function frontend_js_events()
	{
		return array(
			'core.editor.eventAfterAddButton' => "function(instance) {
				instance.registerToolbarBtn('font', function(caller) {
					caller.change(function(e) {
						e.preventDefault();

						var value = $(this).val();

						instance.insertBBcode('font', value);
						instance.triggerEvent('commandExec', 'font', value);
						$(this).children('option').eq(0).prop('selected', true);
					});
				});

				instance.registerToolbarBtn('bbvideo', function(caller) {
					caller
						.data('hasCustomListener', true)
						.click(function(e) {
							e.preventDefault();

							$.ajax({
								url: '" . $this->routing->route('vse_abbc3_bbcode_wizard', array('mode' => 'bbvideo')) . "',
								success: function(response) {
									var dialog = $('<div></div>');

									dialog
										.append(response)
										.cbbDialog({
											autoClean: false,
											destroyOnClose: true,
											width: 600,
											onOpen: function(data) {
												var self = this;

												this.find('#bbvideo_wizard_sites').change(function() {
													self.find('#bbvideo_wizard_example').val($(this).val());
												});

												this.find('#bbvideo_wizard_size_presets').change(function() {
													if($(this).val().length !== 0)
													{
														var dims = $(this).val().split(',');
														self.find('#bbvideo_wizard_width').val(dims[0]);
														self.find('#bbvideo_wizard_height').val(dims[1]);
													}
												});

												this.find('#bbcode_wizard_cancel').remove();

												this.find('#bbcode_wizard_submit').click(function(e) {
													e.preventDefault();

													var xdata = self.find('form').serializeObject();

													if(xdata.bbvideo_wizard_link)
													{
														instance.insertBBcode('bbvideo', {
															defaultAttr: xdata.bbvideo_wizard_width + ',' + xdata.bbvideo_wizard_height,
															inner: xdata.bbvideo_wizard_link
														});

														self.cbbDialog('close');
														instance.triggerEvent('commandExec', 'bbvideo', xdata);
													}
												});
											},
										});
								}
							});
						});
				});
			}",
		);
	}
}