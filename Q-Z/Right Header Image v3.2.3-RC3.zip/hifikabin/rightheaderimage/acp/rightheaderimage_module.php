<?php
/**
*
* @package phpBB Extension - Right Header Image
* @copyright (c) 2015 HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace hifikabin\rightheaderimage\acp;

class rightheaderimage_module
{
	var $u_action;
	var $page_title;
	var $tpl_name;

	function main($id, $mode)
	{
		global $user, $template, $request, $phpbb_log, $config;

		$this->tpl_name = 'acp_rightheaderimage_config';
		$this->page_title = $user->lang('RIGHTHEADERIMAGE_CONFIG');
		$form_name = 'acp_rightheaderimage_config';

		$user->add_lang_ext('hifikabin/rightheaderimage', 'common');

		add_form_key($form_name);

		$submit = $request->is_set_post('submit');
		if ($submit)
		{
			if (!check_form_key('acp_rightheaderimage_config'))
			{
				trigger_error('FORM_INVALID');
			}
			$config->set('rightheaderimage_enable', $request->variable('rightheaderimage_enable', 0));
			$config->set('rightheaderimage_search', $request->variable('rightheaderimage_search', 0));
			$config->set('rightheaderimage_navbar', $request->variable('rightheaderimage_navbar', 0));
			$config->set('rightheaderimage_image_url', $request->variable('rightheaderimage_image_url', ''));
			$config->set('rightheaderimage_image_link', $request->variable('rightheaderimage_image_link', ''));
			$config->set('rightheaderimage_target', $request->variable('rightheaderimage_target', 0));
			$config->set('rightheaderimage_resize', $request->variable('rightheaderimage_resize', 0));
			$config->set('rightheaderimage_image_alt', $request->variable('rightheaderimage_image_alt', ''));

			$user_id = $user->data['user_id'];
			$user_ip = $user->ip;

			$phpbb_log->add('admin', $user_id, $user_ip, 'LOG_RIGHTHEADERIMAGE_SAVE');
			trigger_error($user->lang('RIGHTHEADERIMAGE_CONFIG_SAVED') . adm_back_link($this->u_action));
		}
		$template->assign_vars(array(
			'RIGHTHEADERIMAGE_ENABLE'			=> $config['rightheaderimage_enable'],
			'RIGHTHEADERIMAGE_SEARCH'			=> $config['rightheaderimage_search'],
			'RIGHTHEADERIMAGE_NAVBAR'			=> $config['rightheaderimage_navbar'],
			'RIGHTHEADERIMAGE_IMAGE_URL'		=> $config['rightheaderimage_image_url'],
			'RIGHTHEADERIMAGE_IMAGE_LINK'		=> $config['rightheaderimage_image_link'],
			'RIGHTHEADERIMAGE_TARGET'			=> $config['rightheaderimage_target'],
			'RIGHTHEADERIMAGE_RESIZE'			=> $config['rightheaderimage_resize'],
			'RIGHTHEADERIMAGE_IMAGE_ALT'		=> $config['rightheaderimage_image_alt'],
			'U_ACTION'							=> $this->u_action,
		));
	}
}
