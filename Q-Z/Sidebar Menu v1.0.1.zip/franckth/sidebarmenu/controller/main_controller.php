<?php
/**
*
* @package phpBB Extension - Sidebar Menu
* @copyright (c) 2013 phpBB Group
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace franckth\sidebarmenu\controller;

use Symfony\Component\HttpFoundation\Response;

class main_controller
{
	protected $config;
	protected $db;
	protected $auth;
	protected $template;
	protected $user;
	protected $helper;
	protected $phpbb_root_path;
	protected $php_ext;

	public function __construct(\phpbb\config\config $config, \phpbb\request\request_interface $request, \phpbb\pagination $pagination, \phpbb\db\driver\driver_interface $db, \phpbb\auth\auth $auth, \phpbb\template\template $template, \phpbb\user $user, \phpbb\controller\helper $helper, $phpbb_root_path, $php_ext, $table_prefix)
	{
		$this->config = $config;
		$this->request = $request;
		$this->pagination = $pagination;
		$this->db = $db;
		$this->auth = $auth;
		$this->template = $template;
		$this->user = $user;
		$this->helper = $helper;
		$this->phpbb_root_path = $phpbb_root_path;
		$this->php_ext = $php_ext;
		$this->table_prefix = $table_prefix;
	}

	public function main()
	{
		// Output the page
		$this->template->assign_vars(array(
			'SIDEBARMENU'	=> $this->user->lang('SIDEBARMENU'),
			'SIDEBARMENU_TITLE'		=> $this->user->lang('SIDEBARMENU_TITLE'),
		));

		page_footer();
		return new Response($this->template->return_display('body'), 200);
	}
}