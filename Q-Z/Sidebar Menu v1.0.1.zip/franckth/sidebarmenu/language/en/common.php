<?php
/**
*
* @package phpBB Extension - Add Favorites
* @copyright (c) 2018 FranckTH
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!defined('IN_PHPBB'))
{
    exit;
}

if (empty($lang) || !is_array($lang))
{
    $lang = array();
}

$lang = array_merge($lang, array(
    'ADD_FAVORITES'    => 'Add',
    'FAVORITES'   => 'to my Favorites'
)); 