<?php
/**
*
* @package phpBB Extension - Sidebar Menu
* @copyright (c) 2018 FranckTH - http://www.graphogames.fr/Relax/
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace franckth\sidebarmenu\migrations;

class sidebarmenu_schema extends \phpbb\db\migration\migration
{
	public function update_data()
	{
		return array(

			array('config.add', array('sidebarmenu_version', '1.0.1')),
		);
	}

	public function revert_data()
	{
		return array(

			array('config.remove', array('sidebarmenu_version', '1.0.1')),
		);
	}
}
