<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\migrations;

use phpbb\db\migration\migration;

class v1_0_21 extends migration
{
	static public function depends_on()
	{
		return array('\teamrelax\relaxarcade\migrations\v1_0_20');
	}

	public function update_data()
	{
		return array(
			array('config.add', array('ra_last_upd_start', '0')),
			array('config.add', array('bloc_two_three', '0')),
			array('config.add', array('ra_der_index', '20')),			
			array('config.add', array('no_score_mchat', '0')),
			array('config.add', array('new_record_mchat', '0')),
			array('config.add', array('record_game_mchat', '0')),
			array('config.add', array('record_ultime_mchat', '0')),			
			array('config.add', array('ra_contribution', 'Contributeurs ayant participé à la création de la Relax : Ours, Polo, hawk88, kpc, kasimi, FranckTH, Scotty, anne, kyrien, BalHack')),
			array('config.add', array('ra_top_point', '15')),
			array('config.add', array('Styleaffichage', '0')),	
			array('config.add', array('equipe_tournoi', '0')),			
			array('config.update', array('ra_version', '1.0.21')),
		);
	
	}
		public function update_schema()
	{
		//Create the columns tables
		return array(
			'add_columns' => array(
								
				$this->table_prefix . 'users' => array(
					'user_relax_style' 			=> array('UINT', 1),
				),
			),
			
		);
	}
	
}
