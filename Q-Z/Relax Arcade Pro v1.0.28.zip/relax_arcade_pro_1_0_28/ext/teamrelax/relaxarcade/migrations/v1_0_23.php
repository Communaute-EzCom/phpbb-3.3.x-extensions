<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\migrations;

use phpbb\db\migration\migration;

class v1_0_23 extends migration
{
	static public function depends_on()
	{
		return array('\teamrelax\relaxarcade\migrations\v1_0_22');
	}
	
	public function update_data()
	{
		return array(
			array('config.update', array('ra_version', '1.0.23')),

			array('module.add', array(
				'acp',
				'ACP_CAT_RELAXARCADE',
				array(
					'module_basename'	=> '\teamrelax\relaxarcade\acp\acp_relaxarcade_module',
					'modes'             => array(
						'acp_championnat',
						
					),
				),
			)),
		);
	}


	
	
	
	
	
	
	

	
	
}
