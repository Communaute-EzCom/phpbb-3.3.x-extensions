<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\migrations;

use phpbb\db\migration\migration;

class v1_0_7 extends migration
{
	static public function depends_on()
	{
		return array('\teamrelax\relaxarcade\migrations\v1_0_6');
	}

	public function update_data()
	{
		return array(
			array('config.update', array('ra_version', '1.0.7')),
		);
	}
}