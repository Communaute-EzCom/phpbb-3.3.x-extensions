<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\migrations;

use phpbb\db\migration\migration;

class v1_0_19 extends migration
{
	static public function depends_on()
	{
		return array('\teamrelax\relaxarcade\migrations\v1_0_18');
	}

	public function update_data()
	{
		return array(
			array('config.add', array('active_defilement', '0')),
			array('config.add', array('nb_dernier_scoregames', '0')),
			array('config.add', array('nb_dernier_recordgames', '0')),
			array('config.add', array('nb_dernier_ultimegames', '0')),
			array('config.add', array('nb_dernier_games', '0')),
			array('config.add', array('ra_tournoi_text_fin', '0')),
			array('config.add', array('ra_tournoi_text_debut', '0')),
			array('config.add', array('not_classement', '0')),
			array('config.add', array('active_time', '0')),
			array('config.update', array('ra_version', '1.0.19')),
		);
	
	}
}
