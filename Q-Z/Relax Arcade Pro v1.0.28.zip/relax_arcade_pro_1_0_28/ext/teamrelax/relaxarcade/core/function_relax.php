<?php

/** 
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */
 
 namespace teamrelax\relaxarcade\core;

class function_relax
{

	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/** @var \phpbb\auth\auth */
	protected $auth;
	
		/** @var helper */
	protected $helper;

	/** @var \phpbb\db\driver\driver_interface */
	protected $db;

	/** @var \phpbb\request\request */
	protected $request;

	/** @var \phpbb\config\config */
	protected $config;

	/** @var \phpbb\extension\manager "Extension Manager" */
	protected $ext_manager;

	/** @var \phpbb\path_helper */
	protected $path_helper;

	/** @var string phpBB root path */
	protected $root_path;

	/** @var string php_ext */
	protected $php_ext;

	
	/**
	* Constructor
	*/
	public function __construct(		
		\phpbb\template\template $template,
		\phpbb\user $user,
		\phpbb\auth\auth $auth,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\config\config $config,
		\phpbb\extension\manager $ext_manager,
		\phpbb\path_helper $path_helper,
		$root_path,
		$php_ext
	)
	{
		$this->template 					= $template;
		$this->user 						= $user;
		$this->auth 						= $auth;
		$this->helper						= $helper;
		$this->db 							= $db;
		$this->request 						= $request;
		$this->config 						= $config;
		$this->ext_manager				 	= $ext_manager;
		$this->path_helper	 				= $path_helper;
		$this->root_path 					= $root_path;
		$this->php_ext 						= $php_ext;	
		$this->ext_path = $this->ext_manager->get_extension_path('teamrelax/relaxarcade', true);
		$this->ext_path_web = $this->path_helper->update_web_root_path($this->ext_path);
	}

	public function assign_display_defis()
	{
		

		
		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';

		$uname = array();
		$sql = 'SELECT user_id, username, user_colour, group_id	
		FROM ' . USERS_TABLE;
		$result = $this->db->sql_query($sql);
		while( $row = $this->db->sql_fetchrow($result))
		{
			$uname[$row['user_id']] = get_username_string('full', $row['user_id'], $row['username'], $row['user_colour'], $row['group_id']);
		}

		$games = array();	
		$sql_array = array(
			'SELECT'	=> 'g.game_id,g.game_name,g.game_scoretype, g.game_desc, g.game_pic, g.game_swf, g.us_score_game, g.us_user_id, g.us_score_date,g.game_html5 ,d.id, d.gid, d.user, d.users, d.actif, d.actif_index, d.timeend,d.user_score,d.users_score,u.username, u.user_id, u.user_colour',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g',
				RA_DEFIS_TABLE	=> 'd',
				USERS_TABLE => 'u'
			),
			
			'WHERE'      => 'd.actif_index = 1 and g.game_id = d.gid',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);		
		$result = $this->db->sql_query($sql);
		$games = $this->db->sql_fetchrow($result);
		$defis_actif_index = ($games['actif_index'] == 1) ? true : false ;
		$defis_actif = ($games['actif'] == 0) ? true : false ;
			
		
		$sql_array = array(
			'SELECT'	=> '(count(s2.user_id)+1) as position, s1.*, u.username,u.user_avatar_width,u.user_avatar_height, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, g.game_name',
			'FROM'		=> array(
				RA_SCORES_TABLE	=> 's1'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's2'),
					'ON'	=> ($games['game_scoretype'] == 0) ? '(s1.score_game < s2.score_game and s1.game_id = s2.game_id)'
													  : '(s1.score_game > s2.score_game and s1.game_id = s2.game_id)'
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 's1.user_id = u.user_id '
				),
				
					array(
					'FROM'	=> array(RA_GAMES_TABLE => 'g'),
					'ON'	=> 'g.game_id = s1.game_id'
				)
			
			),
			'WHERE'		=> 's1.game_id = ' . (int) $games['gid'] . ' and ' .$this->db->sql_in_set('s1.user_id', array( (int) $games['user'] , (int) $games['users'] )) ,
			'GROUP_BY'	=> 's1.user_id ',
			'ORDER_BY'	=> 'position ASC, s1.score_date ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$score_rowset = array();
		$score_rowset_defis = array();
		$gamename = '';
		$total_score = 0;

		while( false !== ($row = $this->db->sql_fetchrow($result)))
		{
			$score_rowset[] = $row;
			$score_rowset_defis[$row['user_id']] = $row;
		
			$total_score++;
		}
		$this->db->sql_freeresult($result);
			
			if( $games['game_html5'] == 0 || ! $games['game_html5']){
			$info = '<img src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
			}elseif( $games['game_html5'] == 1){
			$info = '<img src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
			}else{
			$info = '';
			}

		
			$this->template->assign_vars( array(					
				'DEFIS_GAME_NAME' => $info.'<br/><a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $games['game_id'])) . '">' . stripslashes($games['game_name']) . '</a>',
				'DEFIS_GAME_LINK' =>'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_usersdefis') . '">' . $this->user->lang('VIEW_DEFIS') . '</a>',
				'ICON_CHALLENGE_DAY' =>'<img src="' . $ra_theme_basepath . '/images/icon_challenge.png" alt="challenge" width="25" height="22" />',
				'DEFIS_GAMEDESC' => substr($games['game_desc'], 0, 70).'....',
				'DEFIS_IMG' => '<img src="' . $ra_theme_basepath . '/images/defis.png" alt="" />',
				'DEFIS_GAMEPIC' =>'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $games['game_id'])) . '"><img  class="imggrrelax" src="' . generate_board_url() . '/arcade/games/' . nom_sans_ext($games['game_swf']) . '/pics/' . $games['game_pic'] . '" width="80px" height="60px" alt="' . $games['game_name'] . '" title="' . $games['game_name'] . '" /></a>' ,
				));

		
			for($i = 0; $i < $total_score; $i++)
			{
				
				$display_avatar = $this->user->optionget('viewavatars');	
			
				$user_avatars[$score_rowset[$i]['user_id']] = !$display_avatar || !$score_rowset[$i]['user_avatar'] ? '' : phpbb_get_user_avatar(array(
					'avatar'		=> $score_rowset[$i]['user_avatar'],
					'avatar_type'	=> $score_rowset[$i]['user_avatar_type'],
					'avatar_width'	=> $score_rowset[$i]['user_avatar_width'] >= $score_rowset[$i]['user_avatar_height'] ? 40 : 0,
					'avatar_height'	=>$score_rowset[$i]['user_avatar_width'] >= $score_rowset[$i]['user_avatar_height'] ? 0 : 40,
				));
				
			

				$this->template->assign_block_vars('defis', array(
					'DEFISPOS' => $i + 1 ,
					'DEFISPOS_IMG' =>($games['timeend'] >= time()) ? '<img src="' . $ra_theme_basepath . '/images/icon_defi_'.($i + 1).'.png" alt=""  />' :	'<img src="' . $ra_theme_basepath . '/images/icon_defiend_'.($i + 1).'.png" alt=""  />',
								
					'DEFIS_CHAMPION_AVATAR' =>($score_rowset[$i]['user_avatar']) ? $user_avatars[$score_rowset[$i]['user_id']] : '<img src="'.generate_board_url() . '/styles/'.$this->user->style['style_path'].'/theme/images/no_avatar.gif" width="40" height="40" alt="' . ((!empty($this->user->lang['USER_AVATAR'])) ? $this->user->lang['USER_AVATAR'] : '') . '" />',
					
					'DEFIS_POINTS' =>$score_rowset[$i]['score_game']+ 0,
					'DEFIS_DATE' => date("d/m/Y H:i",$score_rowset[$i]['score_date']),
					'S_DEFIS_CHAMPION' => isset($score_rowset[$i]['user_id']) ?  true : false,
					'DEFIS_CHAMPION_NAME' => get_username_string('full',$score_rowset[$i]['user_id'],$score_rowset[$i]['username'],$score_rowset[$i]['user_colour'],$score_rowset[$i]['username']),
				));
				
				
				$is_first = (($games['game_scoretype'] == 0) && ($games['user_score'] > $games['users_score']))	|| (($games['game_scoretype'] == 1) && ($games['user_score'] < $games['users_score'])) ? $games['user_score'] : $games['users_score'];
				
				$users_first = (($games['game_scoretype'] == 0) && ($games['user_score'] > $games['users_score']))	|| (($games['game_scoretype'] == 1) && ($games['user_score'] < $games['users_score'])) ? $games['user'] : $games['users'];
		
				$is_first_egaux = ($games['user_score'] == $games['users_score']);
				
				
				$this->template->assign_block_vars('defiwin', array(
				'DEFISPOS' => $i + 1 ,						
				'DEFIS_WIN' =>$is_first_egaux ?  sprintf($this->user->lang['DEFIS_WIN_EGAUX'],$uname[$games['user']],$uname[$games['users']],$is_first ) : sprintf($this->user->lang['DEFIS_WIN'],$uname[$users_first],$is_first )  ,
			
				));

			}
			
				$this->template->assign_vars( array(
				'DEFIS_TER_DEFIS' =>($games['timeend'] > 0) ? (  ($games['timeend'] >= time()) ? sprintf($this->user->lang['INDEX_EN_DEFIS'],$uname[$games['user']],$uname[$games['users']],$this->user->format_date($games['timeend'])) : sprintf($this->user->lang['INDEX_TER_DEFIS'],$uname[$games['user']],$uname[$games['users']],$this->user->format_date($games['timeend']))) : '',
				'S_DEFIS_INDEX' => $defis_actif_index,
				'RADEFIS_DISABLE' => $this->config['radefis_disable_forum_id'] ? true : false,
				'S_ACTIF' =>$defis_actif,	
				));
				
		
				
			if(($games['timeend'] <= time()) && ($games['actif'] == 1))
				{
				
				$sql_ary = array();	
				$sql_ary['user_score'] =(!empty($score_rowset_defis[(int) $games['user']]['score_game']))  ? $score_rowset_defis[(int) $games['user']]['score_game'] : 0	;
				$sql_ary['users_score'] = (!empty($score_rowset_defis[(int) $games['users']]['score_game'])) ?  $score_rowset_defis[(int) $games['users']]['score_game'] : 0;	
				$sql_ary['actif'] = 0;	

				$sql = 'UPDATE ' . RA_DEFIS_TABLE . ' SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
				  WHERE id = '.(int)$games['id'];
				$this->db->sql_query($sql);
				}

		

	}
	
	function assign_display_challenge()
	{

		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';
		
		$games = array();				

		$sql_array = array(
			'SELECT'	=> 'g.game_id,g.game_name,g.game_scoretype, g.game_desc, g.game_pic, g.game_swf, g.us_score_game, g.us_user_id, g.us_score_date,g.game_html5,a.gamestat_set',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(

				array(
					'FROM' => array(RA_GAMESTAT_TABLE => 'a'),
					'ON' => 'g.game_id = a.game_id',
				)
			),
			
			'WHERE'      => 'g.game_id = ' . (int)$this->config['challenge_day'],
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);		
		$result = $this->db->sql_query($sql);
		$games = $this->db->sql_fetchrow($result);
		$challenge_day = (int)$this->config['challenge_day'];
		
		
		if ($challenge_day)
		{
		
		$sql_array = array(
			'SELECT'	=> '(count(s2.user_id)+1) as position, s1.*, u.username,u.user_avatar_width,u.user_avatar_height, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, g.game_name',
			'FROM'		=> array(
				RA_SCORES_TABLE	=> 's1'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's2'),
					'ON'	=> ($games['game_scoretype'] == 0) ? '(s1.score_game < s2.score_game and s1.game_id = s2.game_id)'
													  : '(s1.score_game > s2.score_game and s1.game_id = s2.game_id)'
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 's1.user_id = u.user_id'
				),
					array(
					'FROM'	=> array(RA_GAMES_TABLE => 'g'),
					'ON'	=> 'g.game_id = s1.game_id'
				)
			),
			'WHERE'		=> 's1.game_id = ' . (int) $challenge_day,
			'GROUP_BY'	=> 's1.user_id',
			'ORDER_BY'	=> 'position ASC, s1.score_date ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 5,  0);
		$score_rowset = array();
		$gamename = '';
		$total_score = 0;

		while( false !== ($row = $this->db->sql_fetchrow($result)))
		{
			$score_rowset[] = $row;
		
			$total_score++;
		}
		$this->db->sql_freeresult($result);
		if( $games['game_html5'] == 0 || ! $games['game_html5']){
			$info = '<img src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
			}elseif( $games['game_html5'] == 1){
			$info = '<img src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
			}else{
			$info = '';
			}
		
			$this->template->assign_vars( array(					
				'CHALLENGE_GAME_NAME' => $info.'<br/><a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $games['game_id'])) . '">' . stripslashes($games['game_name']) . '</a>',
				'CHALLENGE_GAME_LINK' =>'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_gamescores', array('gid' => $games['game_id'])) . '">' . $this->user->lang('SEE_SCORES') . '</a>',
				'ICON_CHALLENGE_DAY' =>'<img src="' . $ra_theme_basepath . '/images/icon_challenge.png" alt="challenge" width="25" height="22" />',
				'CHALLENGE_GAMEDESC' => $games['game_desc'],
				'CHALLENGE_PART' =>$games['gamestat_set'] != 0 ? $this->user->lang('GAME_NBSET') . ' : ' . $games['gamestat_set'] : '',
				
				'CHALLENGE_GAMEPIC' =>'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $games['game_id'])) . '"><img  class="imggrrelax" src="' . generate_board_url() . '/arcade/games/' . nom_sans_ext($games['game_swf']) . '/pics/' . $games['game_pic'] . '" width="80px" height="60px" alt="' . $games['game_name'] . '" title="' . $games['game_name'] . '" /></a>' ,
				));

		for($i = 0; $i < $total_score; $i++)
			{
				
				$display_avatar = $this->user->optionget('viewavatars');	
			
				$user_avatars[$score_rowset[$i]['user_id']] = !$display_avatar || !$score_rowset[$i]['user_avatar'] ? '' : phpbb_get_user_avatar(array(
					'avatar'		=> $score_rowset[$i]['user_avatar'],
					'avatar_type'	=> $score_rowset[$i]['user_avatar_type'],
					'avatar_width'	=> $score_rowset[$i]['user_avatar_width'] >= $score_rowset[$i]['user_avatar_height'] ? 40 : 0,
					'avatar_height'	=>$score_rowset[$i]['user_avatar_width'] >= $score_rowset[$i]['user_avatar_height'] ? 0 : 40,
				));
				
				
				$this->template->assign_block_vars('challenger', array(
					'POS' => '<img src="' . $ra_theme_basepath . '/images/icon_challenge.png" alt="challenge" width="23" height="20" />',					
					'CHALLENGE_DAY_CHAMPION_AVATAR' =>($score_rowset[$i]['user_avatar']) ? $user_avatars[$score_rowset[$i]['user_id']] : '<img src="'.generate_board_url() . '/styles/'.$this->user->style['style_path'].'/theme/images/no_avatar.gif" width="40" height="40" alt="' . ((!empty($this->user->lang['USER_AVATAR'])) ? $this->user->lang['USER_AVATAR'] : '') . '" />',
					
					'CHALLENGE_DAY_POINTS' =>$score_rowset[$i]['score_game']+ 0,
					'CHALLENGE_DATE' => date("d/m/Y H:i",$score_rowset[$i]['score_date']),
					'S_CHALLENGE_DAY_CHAMPION' => isset($score_rowset[$i]['user_id']) ?  true : false,
					'CHALLENGE_DAY_CHAMPION_NAME' => get_username_string('full',$score_rowset[$i]['user_id'],$score_rowset[$i]['username'],$score_rowset[$i]['user_colour'],$score_rowset[$i]['username']),
				));
		
			}	
		
		// Set 	
			
			
				$this->template->assign_vars( array(
				'S_CHALLENGE_DAY' => true,
						));
		
			}
			else
			{
				$this->template->assign_vars( array(
					'S_CHALLENGE_DAY' => false,					
				));
			}
				$this->template->assign_vars( array(
					'S_CHALLENGE_INDEX' =>(int)$this->config['active_challenge'] ? true : false,
				));
		
		
	}

	function point_equipecat($ra_cat_id)
	{
		
		include($this->ext_path . 'arcade/includes/constants.' . $this->php_ext);

		// equipe exclus ACP
		$exclude_equipe_config = '';
		if ( $this->config['mc_no_equipe'])
		{
			$exclude_equipe_config = ' AND ' . $this->db->sql_in_set('gr.group_id', explode(',',  $this->config['mc_no_equipe']), true);
		}
		// equipe exclus ACP
		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';
			//recuperation victory groupes
			$sql_array = array(
				'SELECT' => 'COUNT(s.game_id) AS nbvictories,u.group_id, s.user_id, u.username, u.user_colour',
				'FROM' => array(
					RA_SCORES_TABLE => 's',
					RA_GAMESTAT_TABLE => 'st',
					RA_GAMES_TABLE  => 'g',
					USERS_TABLE => 'u',
				),
				'WHERE' => 's.game_id = g.game_id AND st.game_id = s.game_id
					AND st.gamestat_highscore = s.score_game
					AND s.user_id = u.user_id AND g.ra_cat_id = ' . $ra_cat_id,
					'LEFT_JOIN' => array(
								array(
							'FROM' => array(GROUPS_TABLE => 'gr'),
							'ON' => 'gr.group_id = u.group_id')
					),
				'GROUP_BY' => 'gr.group_id',
				'ORDER_BY' => 'nbvictories DESC, gr.group_id ASC',
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
			$cup_tab = Array();	
			while ($row = $this->db->sql_fetchrow($result))
				{
				$cup_tab[$row['group_id']] = $row['nbvictories'] ;
				}
			$this->db->sql_freeresult($result);


					// Affichage de la liste des points equipe avec egalitée
			 $a = 0;  
			 $b = 0;
			 $c = 0;
						
			$sql_array = array(
				'SELECT'	=> 'u.user_id,u.group_id, u.username, u.user_colour, SUM(score_points) AS pts,count(DISTINCT u.group_id), gr.group_name, gr.group_id, gr.group_colour, gr.group_type',
					'FROM'		=> array(
					USERS_TABLE		=> 'u',
					RA_GAMES_TABLE	=> 'g',
					RA_SCORES_TABLE	=> 's',
					),
				'LEFT_JOIN' => array(
					array(
					'FROM' => array(GROUPS_TABLE => 'gr'),
					'ON' => 'gr.group_id = u.group_id')
					),
				'WHERE'		=>' u.user_id = s.user_id AND s.game_id = g.game_id'. $exclude_equipe_config.' AND g.ra_cat_id = ' . (int) $ra_cat_id,
				'GROUP_BY'	=> 'gr.group_id',
				'ORDER_BY'	=> 'pts DESC',
				);
				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);
				$equipe = array();
				while ($row = $this->db->sql_fetchrow($result))
				{
					$equipe[] = $row;
				}  
				
				$ptsNbr = sizeof($equipe);

				for ($i=0 ; $i< $ptsNbr; $i++)
				{
					if ($equipe[$i]['pts'] != $b){$a++;}
					$colour_text = ($equipe[$i]['group_colour']) ? ' style="color:#' . $equipe[$i]['group_colour'] . '"' : '';
					$group_name =  ($equipe[$i]['group_type'] == GROUP_SPECIAL) ? $this->user->lang['G_' . $equipe[$i]['group_name']] : $equipe[$i]['group_name'];
				
				
				   $this->template->assign_block_vars('equipe', array(
					  'POINT'      =>  $equipe[$i]['pts'],
					  'RANG'      =>   $a,
					  'ICON_CAM' =>'<img src="' . $ra_theme_basepath . '/images/cam.png" alt="Répartitions" width="16" height="14" />',
					   'UCAM' => $this->helper->route('teamrelax_relaxarcade_page_camembert', array('mode' =>'cat ','g' => $equipe[$i]['group_id'],'c' => (int) $ra_cat_id)),
					  'NBVICTORIES' =>empty($cup_tab[ $equipe[$i]['group_id']]) ? '0' : $cup_tab[ $equipe[$i]['group_id']],
					  'GROUPE'      =>'<a' . $colour_text . ' href="' . append_sid("{$this->root_path}memberlist.".$this->php_ext, 'mode=group&amp;g=' . $equipe[$i]['group_id']) . '">' . $group_name . '</a>'
				   ));
					   $b = $equipe[$i]['pts']; 
					  
				}

		}
	

	function point_equipe()
	{
		include($this->ext_path . 'arcade/includes/constants.' . $this->php_ext);
		// equipe exclus ACP
		$exclude_equipe_config = '';
		if ( $this->config['mc_no_equipe'])
		{
			$exclude_equipe_config = ' AND ' . $this->db->sql_in_set('gr.group_id', explode(',',  $this->config['mc_no_equipe']), true);
		}
		// equipe exclus ACP
			$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';
		//recuperation victory groupes
			$sql_array = array(
				'SELECT' => 'COUNT(s.game_id) AS nbvictories,u.group_id, s.user_id, u.username, u.user_colour',
				'FROM' => array(
					RA_SCORES_TABLE => 's',
					RA_GAMESTAT_TABLE => 'st',
					USERS_TABLE => 'u',
				),
				'WHERE' => 'st.game_id = s.game_id
					AND st.gamestat_highscore = s.score_game
					AND s.user_id = u.user_id',
					'LEFT_JOIN' => array(
								array(
							'FROM' => array(GROUPS_TABLE => 'gr'),
							'ON' => 'gr.group_id = u.group_id')
					),
				'GROUP_BY' => 'gr.group_id',
				'ORDER_BY' => 'nbvictories DESC, gr.group_id ASC',
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
			$cup_tab = Array();	
			while ($row = $this->db->sql_fetchrow($result))
				{
				$cup_tab[$row['group_id']] = $row['nbvictories'] ;
				}
			$this->db->sql_freeresult($result);

			// Affichage de la liste des points equipe avec egalitée
			 $a = 0;  
			 $b = 0;
			 $c = 0;		
				
				$sql_array = array(
				'SELECT'	=> 'u.user_id,u.group_id, u.username, u.user_colour, SUM(score_points) AS pts,count(DISTINCT u.group_id), gr.group_name, gr.group_id, gr.group_colour, gr.group_type',
					'FROM'		=> array(
					USERS_TABLE		=> 'u',
					RA_GAMES_TABLE	=> 'g',
					RA_SCORES_TABLE	=> 's',
					),
				'LEFT_JOIN' => array(
					array(
					'FROM' => array(GROUPS_TABLE => 'gr'),
					'ON' => 'gr.group_id = u.group_id')
					),
				'WHERE'		=> 'u.user_id = s.user_id AND s.game_id = g.game_id'. $exclude_equipe_config,
				'GROUP_BY'	=> 'gr.group_id',
				'ORDER_BY'	=> 'pts DESC',
					);
				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);
				$equipe = array();				
				while ($row = $this->db->sql_fetchrow($result))
				{
					$equipe[] = $row;
				}  
				
				$ptsNbr = sizeof($equipe);
				for ($i=0 ; $i< $ptsNbr; $i++)
				{

					if ($equipe[$i]['pts'] != $b){$a++;}
					$colour_text = ($equipe[$i]['group_colour']) ? ' style="color:#' . $equipe[$i]['group_colour'] . '"' : '';
					$group_name =  ($equipe[$i]['group_type'] == GROUP_SPECIAL) ? $this->user->lang['G_' . $equipe[$i]['group_name']] : $equipe[$i]['group_name'];

				   $this->template->assign_block_vars('equipe', array(
					  'POINT'      =>  $equipe[$i]['pts'],
					  'RANG'      =>   $a,
					  'ICON_CAM' =>'<img src="' . $ra_theme_basepath . '/images/cam.png" alt="Répartitions" width="16" height="14" />',
					   'UCAM' => $this->helper->route('teamrelax_relaxarcade_page_camembert', array('mode' =>'news','g' => $equipe[$i]['group_id'])),
					  'NBVICTORIES' =>empty($cup_tab[ $equipe[$i]['group_id']]) ? '0' : $cup_tab[ $equipe[$i]['group_id']],
					  'GROUPE'      =>'<a' . $colour_text . ' href="' . append_sid("{$this->root_path}memberlist.".$this->php_ext, 'mode=group&amp;g=' . $equipe[$i]['group_id']) . '">' . $group_name . '</a>'
				   ));
					   $b = $equipe[$i]['pts'];
				}

		}

	protected function display_avatars()
	{
		return $this->user->optionget('viewavatars');
	}

	
}
