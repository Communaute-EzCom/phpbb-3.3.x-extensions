<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

if (!defined('IN_PHPBB'))
{
	die('Hacking attempt');
}
//determine length of string
function getStringLength($str_data)
{
    if(!$length=strlen($str_data))
    {
    	return false;
    }
    return $length;
}

function nom_sans_ext( $filename ) {
    if (($pos = strrpos($filename, '.')) !== FALSE) {
        return substr($filename, 0, $pos);
    } else {
        return $filename;
    }
}

function size_hum_read($size)
{
   /*
   Fonction trouvée sur php.net
   Returns a human readable size
   Usage : size_hum_read(filesize($file));
   */
   $i=0;
   $iec = array("o", "Ko", "Mo", "Go", "To", "Po", "Eo", "Zo", "Yo");
   while (($size/1024)>1)
   {
      $size=$size/1024;
      $i++;
   }
   return substr($size,0,strpos($size,'.')+4).' '.$iec[$i];
}

// Quote variable to make safe
function quote_smart($value)
{
   // Stripslashes
   if (get_magic_quotes_gpc()) {
       $value = stripslashes($value);
   }
   // Quote if not a number or a numeric string
   if (!is_numeric($value)) {
       $value = "'" . mysql_real_escape_string($value) . "'";
   }
   return $value;
}

// Fonction adaptée à partir du fonction trouvée sur php.net
// Permet de convertir une durée en affichage année mois semaine jour heure ...
function arcade_time($timestamp = 0){

  global $lang, $user;
  $nb_items = $number = $val = $new_time = 0;
  $periods = $lengths = array();
  $text = null;

  // Set the periods of time
  $periods = array($user->lang['ARCADE_SECOND'], $user->lang['ARCADE_MINUTE'], $user->lang['ARCADE_HOUR'], $user->lang['ARCADE_DAY'], $user->lang['ARCADE_WEEK'], $user->lang['ARCADE_MONTH'], $user->lang['ARCADE_YEAR'], $user->lang['ARCADE_DECADE']);

  // Set the number of seconds per period
  $lengths = array(1, 60, 3600, 86400, 604800, 2630880, 31570560, 315705600);
  $nb_items = sizeof($lengths)-1;

  for ($val = $nb_items; ($val >= 0) && (($number = $timestamp / $lengths[$val]) <= 1); $val--);

  // Ensure the script has found a match
  if ($val < 0) $val = 0;

  // Determine the minor value, to recurse through
  $new_time = $timestamp % $lengths[$val];

  // Set the current value to be floored
  $number = floor($number);

  // If required create a plural
  if($number != 1) $periods[$val].= "s";

  // Return text
  $text = sprintf("%d %s ", $number, $periods[$val]);

  //Ensure there is still something to recurse through, and we have not found 1 minute and 0 seconds.
  if (($val >= 1) && ($new_time > 0)){
      $text .= arcade_time($new_time);
  }

  return $text;
}

function arcade_points($position = 0)
{
    /* Retourne les points pour une position donnée */
    /* Affectation des points comme pour la F1      */
    switch($position)
    {
        case 1:
            $points = 20;
            break;
        case 2:
            $points = 19;
            break;
        case 3:
            $points = 18;
            break;
        case 4:
            $points = 17;
            break;
        case 5:
            $points = 16;
            break;
        case 6:
            $points = 15;
            break;
        case 7:
            $points = 14;
            break;
        case 8:
            $points = 13;
            break;
		case 9:
            $points = 12;
            break;
		case 10:
            $points = 11;
            break;
		case 11:
            $points = 10;
            break;
        case 12:
            $points = 9;
            break;
        case 13:
            $points = 8;
            break;
        case 14:
            $points = 7;
            break;
        case 15:
            $points = 6;
            break;
        case 16:
            $points = 5;
            break;
        case 17:
            $points = 4;
            break;
        case 18:
            $points = 3;
            break;
		case 19:
            $points = 2;
            break;
		case 20:
            $points = 1;
            break;	
        default:
            $points = 0;
            break;
    }
    return $points;
}
