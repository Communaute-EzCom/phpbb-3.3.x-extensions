
	     Calendar.setup({
           inputField     :    "ra_active_zero",      // id of the input field
           ifFormat       :    "%Y/%m/%d %H:%M:00",       // format of the input field
           showsTime      :    true,            // will display a time selector
         button         :    "f_trigger_d",   // trigger for the calendar (button ID)
           singleClick    :    false,           // double-click mode
           step           :    1                // show all years in drop-down boxes (instead of every other year as default)
       });