<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_CAT_RELAXARCADE' 		=> 'Relax Arcade Pro',
	'ACP_RELAXARCADE'			=> 'Relax Arcade Pro',
	'ACP_GAMES_INSTALL' 		=> 'Installation of games',
	'ACP_RELAXARCADE_SETTINGS'	=> 'Configuration of Relax Arcade',
	'ACP_GENRALRELAXARCADE_SETTINGS' => 'General Configuration of Relax Arcade',
	'ACP_CHALENGE_SETTINGS' 	=> 'Configuration of the relax challenge',
	'ACP_RELAXINDEX_SETTINGS' 	=> 'Block configuration on the index',
	'ACP_RELAXSCORE_SETTINGS'	=> 'Global Statistics Block Configuration',
	'ACP_RELAXTOURNOI_SETTINGS' => 'Championship configuration',
	'ACP_SETTING_GROUPS'		=> 'Groups permissions',
	'ACP_SETTING_CATEGORY'		=> 'Categories permissions',
	'ACP_CATEGORY_MANAGE'		=> 'Categories Management',
	'ACP_CHEATERS_MANAGE'		=> 'Cheating management',
	'RA_VERSION'				=> 'Version',

	//Log Relax Arcade
	'LOG_RELAXARCADE_SETTINGS'			=> '<strong> Relax Arcade general settings has been modified</strong>',
	'LOG_GAMES_MANAGE'					=> '<strong>Game management done</strong>',
	'LOG_RACAT_ADD'						=> '<strong>Create a new arcade category</strong><br />» %s',
	'LOG_RACAT_EDIT'					=> '<strong>Edit an arcade category</strong><br />» %s',
	'LOG_RACAT_DEL'						=> '<strong>Delete an arcade category</strong><br />» %s',
	'LOG_RACAT_SYNC'					=> '<strong>Resynchronize an arcade category</strong><br />» %s',
	'LOG_RAGAME_ADD'					=> '<strong>Add a Relax Arcade game</strong><br />» %s',
	'LOG_GAME_EDIT'						=> '<strong>Edit a Relax Arcade game</strong><br />» %s',
));
