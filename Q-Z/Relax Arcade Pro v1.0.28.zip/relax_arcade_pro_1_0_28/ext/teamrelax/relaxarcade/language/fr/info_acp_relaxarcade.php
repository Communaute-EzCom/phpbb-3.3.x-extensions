<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_CAT_RELAXARCADE'		=> 'Relax Arcade Pro',
	'ACP_RELAXARCADE'			=> 'Relax Arcade Pro',
	'ACP_GAMES_INSTALL'			=> 'Installation de jeux',
	'ACP_RELAXARCADE_SETTINGS'	=> 'Configuration de Relax Arcade',
	'ACP_GENRALRELAXARCADE_SETTINGS'	=> 'Configuration Général de Relax Arcade',
	'ACP_CHALENGE_SETTINGS'	=> 'Configuration du challenge relax',
	'ACP_RELAXINDEX_SETTINGS'	=> 'Configuration des blocs sur l’index',
	'ACP_RELAXSCORE_SETTINGS'	=> 'Configuration du bloc Statistiques Globales',
	'ACP_RELAXTOURNOI_SETTINGS'	=> 'Configuration du Championnat',
	'ACP_SETTING_GROUPS'		=> 'Permissions des groupes',
	'ACP_SETTING_CATEGORY'		=> 'Permissions des catégories',
	'ACP_CATEGORY_MANAGE'		=> 'Gestion des catégories',
	'ACP_CHEATERS_MANAGE'		=> 'Gestion des triches',
	'RA_VERSION'				=> 'Version',

	//Log Relax Arcade
	'LOG_RELAXARCADE_SETTINGS'			=> '<strong>La configuration générale de Relax Arcade a été modifiée</strong>',
	'LOG_GAMES_MANAGE'					=> '<strong>Gestion des jeu effectuée</strong>',
	'LOG_RACAT_ADD'						=> '<strong>Création d’une nouvelle catégorie arcade</strong><br />» %s',
	'LOG_RACAT_EDIT'					=> '<strong>Modification d’une catégorie arcade</strong><br />» %s',
	'LOG_RACAT_DEL'						=> '<strong>Suppression d’une catégorie arcade</strong><br />» %s',
	'LOG_RACAT_SYNC'					=> '<strong>Resynchronisation d’une catégorie arcade</strong><br />» %s',
	'LOG_RAGAME_ADD'					=> '<strong>Ajout d’un jeu Relax Arcade</strong><br />» %s',
	'LOG_GAME_EDIT'						=> '<strong>Modification d’un jeu Relax Arcade</strong><br />» %s',
));
