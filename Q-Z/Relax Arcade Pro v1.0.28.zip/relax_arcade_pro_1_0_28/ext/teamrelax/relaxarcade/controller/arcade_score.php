<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;

class arcade_score
{
	/** @var user */
	protected $user;

	/** @var config */
	protected $config;

	/** @var request_interface */
	protected $request;

	/** @var db_interface */
	protected $db;

	/** @var template */
	protected $template;

	/** @var helper */
	protected $helper;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

		/** @var bool */
	public $is_phpbb32;
	/** @var bool */
	public $is_phpbb31;
	
	
	
	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->user = $user;
		$this->config = $config;
		$this->request = $request;
		$this->db = $db;
		$this->template = $template;
		$this->helper = $helper;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->is_phpbb31	= phpbb_version_compare($config['version'], '3.1.0@dev', '>=') && phpbb_version_compare($config['version'], '3.2.0@dev', '<');
		$this->is_phpbb32	= phpbb_version_compare($config['version'], '3.2.0@dev', '>=') && phpbb_version_compare($config['version'], '3.3.0@dev', '<');
	}

	public function handle()
	{
		$time_end = time();

		$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

		include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		include($ext_path . 'arcade/includes/functions_arcade.' . $this->php_ext);
		include($ext_path . 'arcade/includes/arcade_auth.' . $this->php_ext);

		$gamescorevar = null;
		$gamekey = $gid = $gameflashtime = $gamescore = $gamescorefake = $gamenbparties = $gamerealtime = $score_condition = 0;
		$gamecheattype = $gameframerate = $game_scoretype = $first_score = $game_fps = $gkey = $test_fps = $arcade_cat_id = 0;

	

		// Arcade fermé ?
		if ( ($this->config['arcade_close']) && ($this->user->data['user_type'] != USER_FOUNDER) )
		{
			$message = $this->user->lang('INFO_ARCADE_CLOSE') . '<br /><br />' . $this->user->lang('RETURN_INDEX', '<a href="' . append_sid($this->root_path . "index." . $this->php_ext) . '">', '</a>');			trigger_error($message);
		}

		//Récupération valeurs action et scoreprep
		$action   = $this->request->variable('action', '');
		$scoreprep = $this->request->variable('scoreprep', '');

		if ($action === 'arcade' && $scoreprep === 'prepascore')
		{
			$gamekey = ra_sess_start();
			$RAKEY = $this->config['gamesKey'];

			if (!isset($gamekey))
			{
				trigger_error($this->user->lang('RA_SESS_INIT_ERROR'));
			}

			$this->template->assign_var('RA_SCORE', utf8_encode("myscorekey=$gamekey&raOK=1&myRAKEY=$RAKEY&myRAKEYoK=1"));

			return $this->helper->render('arcadelist_score.html');
		}

		$route_arcade_list = $this->helper->route('teamrelax_relaxarcade_page_list');

		//Récupération valeurs arcade et newscore
		$arcade = $this->request->variable('act', '');
		$newscore = $this->request->variable('do', '');
		if ($arcade === 'Arcade' && $newscore === 'newscore')
		{
			$gsubmitscore = html_entity_decode($this->request->variable('gsubmitscore', '', true));
			if (!$gsubmitscore)
			{
				$message = $this->user->lang('RA_SESS_NO_SCORE') . '<br /><br />' . $this->user->lang('CLICK_RETURN_ARCADE', '<a href="' . $route_arcade_list . '">', '</a>');
				trigger_error($message);
			}

			$ra_session = ra_sess_submit();

			$len_submit = strlen($gsubmitscore);
			if ($len_submit >= 200)
			{
				$message = $this->user->lang('RA_SESS_TOO_LONG');
				trigger_error($message);
			}

			$gkey = $ra_session['gamekey'];
			$decrypt_submit = $this->decrypt_string($gsubmitscore, $gkey);
			$resul_submit = explode(";", $decrypt_submit);

			//Game ID
			$gid = $ra_session['gid'];

			//Variable
			$gamescorevar = str_replace("\'", "''", $resul_submit[0]);
			$gamescorevar = preg_replace(array('#&(?!(\#[0-9]+;))#', '#<#', '#>#'), array('&amp;', '&lt;', '&gt;'), $gamescorevar);

			//Temps php de la partie
			if (isset($ra_session['date_deb']))
			{
				$gamerealtime = $time_end - $ra_session['date_deb'];
			}
			else
			{
				//Erreur lors de la sélection des valeurs du jeu !
				$message = $this->user->lang('RA_SESS_INC_CONNECT') . '<br /><br />' . $this->user->lang('CLICK_RETURN_ARCADE ' . $gamekey, '<a href="' . $route_arcade_list . '">', '</a>');
				trigger_error($message);
			}

			if ($ra_session['ra_session_id'] != $this->user->data['session_id'])
			{
				$message = $this->user->lang('RA_SESS_INC_CONNECT') . '<br /><br />' . $this->user->lang('CLICK_RETURN_ARCADE ' . $gamekey, '<a href="' . $route_arcade_list . '">', '</a>');
				trigger_error($message);
			}

			//Score
			$gamescore = isset($resul_submit[3]) ? intval($resul_submit[3]) : 0;
			$gamenbparties = isset($resul_submit[4]) ? intval($resul_submit[4]) : 1;
			$gameflashtime = isset($resul_submit[2]) ? intval($resul_submit[2]) : 0;
			$gamecheattype = isset($resul_submit[7]) ? intval($resul_submit[7]) : 0;
			$gameframerate = isset($resul_submit[1]) ? intval($resul_submit[1]) : 0;
			if (isset($resul_submit[5]))
			{
				$gamescorefake = intval($resul_submit[5]);
				if ($gamescorefake == $gamescore)
				{
					$message = $this->user->lang('RA_SESS_INC') . '<br /><br />' . $this->user->lang('CLICK_RETURN_ARCADE', '<a href="' . $route_arcade_list . '">', '</a>');
					trigger_error($message);
				}
			}
			else
			{
				$gamescorefake = 0;
				$message = $this->user->lang('RA_SESS_INC_KEY') . '<br /><br />' . $this->user->lang('CLICK_RETURN_ARCADE', '<a href="' . $route_arcade_list . '">', '</a>');
				trigger_error($message);
			}
		}

		//Vérification score modifié dans le postdata
		if (($gamescorefake - $gamescore) != $gkey)
		{
		   $message = $this->user->lang('RA_SESS_MODI_SCORE') . '<br /><br />' . $this->user->lang('CLICK_RETURN_ARCADE', '<a href="' . $route_arcade_list . '">', '</a>');
		   trigger_error($message);
		}
		
		
		

		$first_score = false;
		$score_prec = 0;
		$highscore = null;
		//Vérification présence du jeu, le joueur a déjà un score ?
		$sql_array = array(
			'SELECT'	=> '*',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's'),
					'ON'	=> 'g.game_id = s.game_id
								AND s.user_id = ' . $this->user->data['user_id']
				),
				array(
					'FROM'	=> array(RA_GAMESTAT_TABLE => 'a'),
					'ON'	=> 'a.game_id = g.game_id'
				)
			),
			'WHERE'		=> 'g.game_id = '.$gid
		);
		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		if ( !( $row = $this->db->sql_fetchrow($result) ) )
		{
		   trigger_error($this->user->lang('RA_NO_GAME')) ;
		}

		//Vérifier la variable score du jeu
		if ($gamescorevar !== $row['game_scorevar'])
		{
		   trigger_error($this->user->lang('RA_SCOREVAR_INC')) ;
		}

		$arcade_cat_id = $row['ra_cat_id'];
		//Catégorie avec submit ?
		if (!arcade_cat_submit($arcade_cat_id))
		{
			$message = $this->user->lang('INFO_ARCADECAT_NO_SUBMIT') . '<br /><br />' . $this->user->lang('CLICK_RETURN_ARCADE', '<a href="' . $route_arcade_list . '">', '</a>');
			trigger_error($message);
		}
		//
		// Start auth check
		//
		$is_auth = arcade_auth(AUTH_SUBMIT, $arcade_cat_id);
		if( !$is_auth['ra_cat_auth_submit'] )
		{
			trigger_error($this->user->lang('NOT_AUTHORISED'));
		}
		//
		// End auth check
		//

		//Vérification écart temps de jeu serveur vs temps de jeu client
		if ($row['game_cheat_control'] && ($row['game_html5'] == false))
		{
			$games_tolerance = (float) $this->config['game_time_tolerance'];
			$gamenotrealtime = array(-1, 0, 1, 2, 3);
			if (!in_array($gamerealtime, $gamenotrealtime, TRUE))
			{
				//Si triche archivage des valeurs temps php, temps flash, jeu, joueur, date, score
				if ( ( ($gameflashtime > ($gamerealtime + $games_tolerance)) || ($gameflashtime < ($gamerealtime - $games_tolerance)) ) || ($gamecheattype) )
				{
					$sql_array = array(
						'user_id'				=> $this->user->data['user_id'],
						'game_id'				=> $gid,
						'score_game'			=> $gamescore,
						'cheater_date'			=> time(),
						'cheater_flashtime'		=> $gameflashtime,
						'cheater_realtime'		=> $gamerealtime,
						'cheater_type'			=> $gamecheattype
					);
					$this->db->sql_query('INSERT INTO ' . RA_CHEATERS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_array));
					if (!$this->config['cheater_submit'])
					{
						//Envoyer un message au joueur indiquant la tentative de triche
						$message = $this->user->lang('INFO_ARCADE_CHEATER', $gamescore, $row['game_name']);
						trigger_error($message);
					}
				}
			}
		}

		//Mise en forme du score, virgule ?
		if ($row['game_nbdecimal'] > 0)
		{
			$gamescore = $gamescore / $this->puissance(10, $row['game_nbdecimal']);
		}
		if (is_null ($row['score_game']) && ($gamescore > 0))
		{
			$first_score = true;
			$game_scoretype = $row['game_scoretype'];
		}
		else
		{
			$score_prec = $row['score_game'];
			$game_scoretype = $row['game_scoretype'];
		}
		$this->db->sql_freeresult($result);

		$highuser = $row['gamestat_user_id'];
		$highscore = is_null($row['gamestat_highscore']) ? null : $row['gamestat_highscore'];
		$game_fps = $row['game_fps'];

		// Contrôle des fps de la partie
		if ($this->config['game_fps_tolerance'] >= 0)
		{
		  $test_fps = $gameframerate + ((float) $this->config['game_fps_tolerance'] * $game_fps * 0.01);
		  // Vérification des fps sur le jeu
		  if ( $test_fps < $game_fps )
		  {
			 //Envoyer un message au joueur indiquant que son score ne sera pas sauvegardé
			 $message = $this->user->lang('INFO_ARCADE_ERREUR_FPS', $gamescore, $row['game_name'], $gameframerate);
			 trigger_error($message);
		  }
		}
		else
		{
			$gameframerate = 0;
		}
		
	// START RA records mChat
if ($gamescore == 0)
{
    // Afficher le score égal à 0 dans le mChat.
    $this->arcade_scores_mchat($this->user->lang['MCHAT_NO_SCORE'], $this->user->lang['MCHAT_NO_SCORE_TXT'], $gamescore, $row['game_name'], $gid, $this->config['no_score_mchat']);
}
// END RA records mChat

		// Enregistrement du score
		if (($first_score == true) && ($gamescore > 0))
		{
			// Si l'utilisateur n'a encore aucun score pour ce jeu'
			$sql_array = array(
				'game_id'		=> $gid,
				'user_id'		=> $this->user->data['user_id'],
				'score_game'	=> $gamescore,
				'score_date'	=> $time_end,
				'score_time'	=> $gamerealtime,
				'score_set'		=> $gamenbparties,
				'score_comment'		=> '',
				'score_fps'		=> $gameframerate
			);
			$this->db->sql_query('INSERT INTO ' . RA_SCORES_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_array));

			if ($gamescore > 0)
			{
			
			 // Meilleur Score
			  $sqlr = 'SELECT us_user_id, us_score_game, us_score_date
				FROM ' . RA_GAMES_TABLE . '
				WHERE game_id = ' . (int)$gid;
			   
			  $resultr =$this->db->sql_query($sqlr);
			  if ( !( $rowr = $this->db->sql_fetchrow($resultr) ) )
			  {
				trigger_error($this->user->lang['RA_NOPOINTS']) ;
			  }
			  $mscore = $rowr['us_score_game'];
			  $muserid = $rowr['us_user_id'];
			  $this->db->sql_freeresult($resultr);
			 
			 if ( (($game_scoretype == 0) && ($gamescore > $mscore))
				|| (($game_scoretype == 1) && ($gamescore < $mscore))
				|| (is_null($mscore)) || ($muserid == 0) ) //Mise à jour du meilleur score
			  {
				   // START RA records mChat
	// Afficher le premier score d'un jeu.
	$this->arcade_scores_mchat($this->user->lang['MCHAT_NEW_SCORE'], $this->user->lang['MCHAT_NEW_SCORE_TXT'], $gamescore, $row['game_name'], $gid, $this->config['new_record_mchat']);
    // END RA records mChat

				$sql = 'UPDATE ' . RA_GAMES_TABLE . '
				  SET us_user_id = ' . $this->user->data['user_id'] . ', us_score_game = '. $gamescore .',  us_score_date = '. $time_end .'
				  WHERE game_id = ' . (int)$gid;
				$result = $this->db->sql_query($sql);
			  }
			  // Meilleur Score
			}
	
			
		

			
		}
		else
		{
			
			
			// Si l'utilisateur a amélioré son score
			if ($game_scoretype == 0) //DéCroissant ?
			{
				$score_condition = ($gamescore > $score_prec) ? true : false;
			}
			else
			{
				$score_condition = ($gamescore < $score_prec) ? true : false;
			}
			if ($gamescore > 0)
			{


			$sql_array = array(
				'score_set'		=> $gamenbparties,
				'score_time'	=> $gamerealtime
			);
			
			
			
			if ($score_condition)
			{
				$sql_array = array_merge($sql_array, array(
					'score_game'	=> $gamescore,
					'score_date'	=> $time_end,
					'score_fps'		=> $gameframerate
				));
			}

			$sql = 'UPDATE ' . RA_SCORES_TABLE . '
				SET ' . $this->db->sql_build_array('UPDATE', $sql_array) . '
				WHERE game_id = ' . (int)$gid . '
				AND user_id = ' . (int)$this->user->data['user_id'];
			$this->db->sql_query($sql);

			
			// Meilleur Score
			  $sqlr = 'SELECT us_user_id, us_score_game, us_score_date
				FROM ' . RA_GAMES_TABLE . '
				WHERE game_id = ' . (int)$gid;
			   
			  $resultr =$this->db->sql_query($sqlr);
			  if ( !( $rowr = $this->db->sql_fetchrow($resultr) ) )
			  {
				trigger_error($this->user->lang['RA_NOPOINTS']) ;
			  }
			  $mscore = $rowr['us_score_game'];
			  $muserid = $rowr['us_user_id'];
			  $this->db->sql_freeresult($resultr);
			  if ( (($game_scoretype == 0) && ($gamescore > $mscore))
				|| (($game_scoretype == 1) && ($gamescore < $mscore))
				|| (is_null($mscore)) || ($muserid == 0) ) //Mise à jour du meilleur score
			  {
				   // START RA records mChat
	// Afficher le nouveau record ultime du jeu.
	$this->arcade_scores_mchat($this->user->lang['MCHAT_NEW_URECORD'], $this->user->lang['MCHAT_NEW_URECORD_TXT'], $gamescore, $row['game_name'], $gid, $this->config['record_ultime_mchat']);
    // END RA records mChat

				$sql = 'UPDATE ' . RA_GAMES_TABLE . '
				  SET us_user_id = ' . $this->user->data['user_id'] . ', us_score_game = '. $gamescore .',  us_score_date = '. $time_end .'
				  WHERE game_id = ' . (int)$gid;
				$result = $this->db->sql_query($sql);
			  }
			}
			  // Meilleur Score
			  
		}

			$sql_array = array();
		$sql_sep = '';
		// Si le joueur devient le nouveau champion du jeu
		
		if ( (($game_scoretype == 0) && ($gamescore > $highscore))	|| (($game_scoretype == 1) && ($gamescore < $highscore)) || (is_null($highscore)) )
		{
			 // START RA records mChat
	// Afficher le nouveau record du jeu.
	$this->arcade_scores_mchat($this->user->lang['MCHAT_NEW_RECORD'], $this->user->lang['MCHAT_NEW_RECORD_TXT'], $gamescore, $row['game_name'], $gid, $this->config['record_game_mchat']);
    // END RA records mChat

			/* Envoie un mp à l'ancien champion si option activée */
			if ($this->config['allow_privmsg'] && $this->config['ra_allow_privmsg'] && (!is_null($highscore)))
			{
				// Recherche de la liste des users ayant le highscore (plusieurs n°1 possible dans RA)
				// et souhaitant être prévenu
				$sql_array = array(
					'SELECT'	=> 'u.user_id',
					'FROM'		=> array(
						RA_SCORES_TABLE	=> 's',
						USERS_TABLE		=> 'u'
					),
					'WHERE'		=> 's.user_id = u.user_id AND s.game_id = ' . $gid
									. ' AND s.score_game = ' . $highscore
									. ' AND u.user_allow_rapm = 1 AND u.user_id <> ' . $this->user->data['user_id']
				);
				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);
				$address_list = array();
				while ($tab_old_champ_id = $this->db->sql_fetchrow($result))
				{
					$address_list['u'][$tab_old_champ_id['user_id']] = 'to';
				}
				$this->db->sql_freeresult($result);

				if (sizeof($address_list) > 0)
				{
					$ra_pm_subject = $this->user->lang('RA_PM_SUBJECT', $this->user->data['username'], $row['game_name']);
					
					
					if ($this->is_phpbb31)
					{						
					$ra_pm_message = $this->user->lang('RA_PM_DATA', $row['game_name'], $this->user->data['username'], $gamescore, $highscore, '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '">' . $row['game_name'] . '</a>');
					}					
					if ($this->is_phpbb32)
					{						
					$ra_pm_message = $this->user->lang('RA_PM_DATA', $row['game_name'], $this->user->data['username'], $gamescore, $highscore, '[URL=' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . ']' . $row['game_name'] . '[/URL]');
					}
					include_once($this->root_path . 'includes/functions_privmsgs.' . $this->php_ext);
					include_once($this->root_path . 'includes/message_parser.' . $this->php_ext);
					$message_parser = new \parse_message();
					$message_parser->message = utf8_normalize_nfc($ra_pm_message);
					$subject = utf8_normalize_nfc($ra_pm_subject);
					$message_parser->parse(true, true, true, false, false, true, true);

					$pm_data = array(
						'from_user_id'			=> $this->user->data['user_id'],
						'from_user_ip'			=> $this->user->ip,
						'from_username'			=> $this->user->data['username'],
						'enable_sig'			=> false,
						'enable_bbcode'			=> true,
						'enable_smilies'		=> true,
						'enable_urls'			=> false,
						'icon_id'				=> 0,
						'bbcode_bitfield'		=> $message_parser->bbcode_bitfield,
						'bbcode_uid'			=> $message_parser->bbcode_uid,
						'message'				=> $message_parser->message,
						'address_list'			=> $address_list,
					);
					unset($message_parser);
					submit_pm('post', $subject, $pm_data, true);
				}
			}

			$sql_array = array(
		'gamestat_user_id'		=> $this->user->data['user_id'],
		'gamestat_highscore'	=> $gamescore,
		'gamestat_highdate'		=> $time_end
			);
			$sql_sep = ',';
					

		}
		$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . ' 
			SET ' . $this->db->sql_build_array('UPDATE', $sql_array) . $sql_sep . '
			gamestat_set = gamestat_set - 1 + ' . (int)$gamenbparties . ' 
			WHERE game_id = ' . (int)$gid;
		$this->db->sql_query($sql);
		
					
		
		// Calcul des points des 8 premières positions ?
		// Prise en compte des scores égaux
		// Voir plus tard si optimisation possible
		if ($first_score || $score_condition)
		{
			$position = 0;
			if ($game_scoretype == 0)
			{
			$sql = 'SELECT (count(*)+1) pos_user
					FROM ' . RA_SCORES_TABLE . '
					WHERE game_id = ' . (int)$gid . '
					AND score_game >  ' . (float)$gamescore;
			}
			else
			{
			$sql = 'SELECT (count(*)+1) pos_user
					FROM ' . RA_SCORES_TABLE . '
					WHERE game_id = ' . (int)$gid . '
					AND score_game <  ' . (float)$gamescore;
			}
			$result = $this->db->sql_query($sql);
			if ( !( $row = $this->db->sql_fetchrow($result) ) )
			{
				trigger_error($this->user->lang('RA_NOPOINTS')) ;
			}
			$position = $row['pos_user'];
			$this->db->sql_freeresult($result);
			if ($position <= 21) //Mise à jour des points nécessaires
			{
				//Liste des joueurs ayant un score <= au nouveau score
				$sql_array = array(
					'SELECT'	=> 's1.user_id, (count(s2.user_id)+1) position',
					'FROM'		=> array(
						RA_SCORES_TABLE	=> 's1'
					),
					'LEFT_JOIN'	=> array(
						array(
							'FROM'	=> array(RA_SCORES_TABLE => 's2'),
							'ON'	=> ($game_scoretype == 0) ? '(s1.game_id = s2.game_id AND s1.score_game < s2.score_game)' :
																'(s1.game_id = s2.game_id AND s1.score_game > s2.score_game)' 
						)
					),
					'WHERE'		=> 's1.game_id = ' . $gid,
					'GROUP_BY'	=> 's1.user_id HAVING position between ' . $position . ' and 21',
					'ORDER_BY'	=> 'position'
				);
				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);

				while ( false !== ($row = $this->db->sql_fetchrow($result)) )
				{
					$points = arcade_points($row['position']);
					$sql = 'UPDATE ' . RA_SCORES_TABLE . '
							SET score_points = ' . $points . '
							WHERE game_id 	= ' . (int)$gid . '
							AND user_id		= ' . (int)$row['user_id'];
					$this->db->sql_query($sql);
				}
				$this->db->sql_freeresult($result);
			}
		}

		// Detect flash
      if ($gameframerate == 'javascript') {
         // Detect HTML5 / JS
         $this->template->assign_var('RA_SCORE', utf8_encode("/arcade/scores?gid=" . $gid . "&mode=entercomment"));
         return $this->helper->render('arcadelist_score.html');
      }
      else {
         $redirect = $this->helper->route('teamrelax_relaxarcade_page_gamescores', array('gid' => $gid, 'mode' => 'entercomment'));
          redirect($redirect);
         return null;
      }
   }



	function arcade_scores_mchat($message_new = '', $message_new_txt = '', $scoregame = 0, $gamename = '', $gid = 0, $type = false)
	{
	  global $phpbb_container,$table_prefix;

	
	if (($phpbb_container->has('dmzx.mchat.settings'))  && ($type == true))
		{
				
		
		$mchat_new_record = $message_new;	
		
		
								
			$urlgame =  '[url='. generate_board_url().'/arcade/play?gid='. $gid .']'.$gamename.'[/url]';
			
		$message_new_record_txt = utf8_normalize_nfc($mchat_new_record . ': ' . sprintf($message_new_txt,  $scoregame, $urlgame), true);
		$uid = $bitfield = $options = '';
		generate_text_for_storage($message_new_record_txt, $uid, $bitfield, $options, true, false, false);
		$sql_ary = array(
			'user_id'			=> $this->user->data['user_id'],
			'user_ip'			=> $this->user->data['session_ip'],
			'message'			=> $message_new_record_txt,
			'bbcode_bitfield'	=> $bitfield,
			'bbcode_uid'		=> $uid,
			'bbcode_options'	=> $options,
			'message_time'		=> time()
		);
	   
		$this->db->sql_query('INSERT INTO ' . $table_prefix . 'mchat'	. ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
		
		}
	 
	}

			

   
   
   
   
   
	protected function decrypt_string($gsubmit, $gkey)
	{
	  $gresult = '';
	  $i = $j = $char = 0;
	  $l_gsubmit = STRLEN($gsubmit);
	  $l_gkey = STRLEN($gkey);
	  while ($i < $l_gsubmit) {
			if ($j >= $l_gkey) $j = 0;
			$char = intval(SUBSTR($gkey,$j,1)) ^ ord(SUBSTR($gsubmit, $i, 1));
			$gresult .= CHR($char);
			$i++;
			$j++;
	  }
	  return $gresult;
	}

	protected function puissance($x=0,$y=0)
	{
		$resultat=1;
		for ($i=0;$i<$y;$i++)
		{
			$resultat *= $x;
		}
		return $resultat;
	}
}
