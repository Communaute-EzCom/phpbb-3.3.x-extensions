<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;

class game_file_redirect
{
	/** @var string */
	protected $root_path;

	public function __construct(
		$root_path
	)
	{
		$this->root_path = $root_path;
	}

	public function handle($path, $file)
	{
		redirect($this->root_path . 'arcade/games/' . $path . '/' . $file);
	}
}
