<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class arcade_list
{
	protected $function_relax;
	/** @var config */
	protected $config;
	
	/** @var helper */
	protected $helper;	

	/** @var db_interface */
	protected $db;

	/** @var pagination */
	protected $pagination;

	/** @var request_interface */
	protected $request;
	
	/** @var template */
	protected $template;

	/** @var user */
	protected $user;
	
	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var string */
	protected $ext_path;

	public function __construct(
		\teamrelax\relaxarcade\core\function_relax $function_relax,
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\pagination $pagination,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->function_relax		= $function_relax;
		$this->config 		= $config;
		$this->helper 		= $helper;
		$this->db 			= $db;
		$this->pagination	= $pagination;
		$this->request 		= $request;
		$this->template 	= $template;		
		$this->user 		= $user;
		$this->root_path 	= $root_path;
		$this->php_ext 		= $php_ext;
	}

	public function handle()
	{
		$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

		include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		include($ext_path . 'arcade/includes/functions_arcade.' . $this->php_ext);
		include($ext_path . 'arcade/includes/arcade_auth.' . $this->php_ext);

	
		$arcade_cat_title = $username = '';

		// Arcade fermé ?
		// Accès fondateur quand même autorisé
		if (($this->config['arcade_close']) && ($this->user->data['user_type'] != USER_FOUNDER))
		{
			$message = $this->user->lang('INFO_ARCADE_CLOSE') . '<br /><br />' . $this->user->lang('RETURN_INDEX', '<a href="' . append_sid($this->root_path . "index." . $this->php_ext) . '">', '</a>');
			trigger_error($message);
		}

		//Récupération des valeurs
		$arcade_catid = $this->request->variable('cid', 0);
		$start = $this->request->variable('start', 0);
		$start = ($start < 0) ? 0 : $start;
		$mode = $this->request->variable('mode', '');
		$gid = $this->request->variable('gid', 0);

		$sql = 'SELECT *
				FROM ' . RA_CAT_TABLE . '
				ORDER BY ra_cat_order';
		$result = $this->db->sql_query($sql);

		$liste_cat = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$nbcat = count($liste_cat);

		if ($nbcat == 0)
		{
			trigger_error($this->user->lang('RA_NO_CAT'));
		}

		//
		// Recherche des catégories visibles pour l'utilisateur
		//
		$liste_cat_id_auth = array();
		$is_auth_ary = arcade_auth(AUTH_VIEW, AUTH_LIST_ALL, $liste_cat);
		$j = 0;
		$liste_cat_auth = array();
		for ($i = 0; $i < $nbcat; $i++)
		{
			$arcade_cid = (int)$liste_cat[$i]['ra_cat_id'];
			if ($is_auth_ary[$arcade_cid]['ra_cat_auth_view'])
			{
				$liste_cat_auth[$j] = $liste_cat[$i];
				$liste_cat_id_auth[$j] = $liste_cat[$i]['ra_cat_id'];
				if ($arcade_catid === intval($liste_cat_auth[$j]['ra_cat_id']))
				{
					$arcade_cat_title = $liste_cat_auth[$j]['ra_cat_title'];
				}
				$j++;
			}
		}
		$nbcat_auth = count($liste_cat_auth);
			
			if ($mode == 'bookmark' && $gid)
			{
						
			$ret = ra_bookmark($gid, $liste_cat_id_auth);
			$errors = isset($ret['errors']) ? $ret['errors'] : array();

			$view_page_ra = $this->helper->route('teamrelax_relaxarcade_page_list', array('cid' => $arcade_catid, 'start' => $start));
			
				
			
			if (sizeof($errors) > 0)
			{
				$message = implode('<br />', $errors);
			}
			else
			{
				$bookmarked = $ret['message'][0]['bookmarked'];

				$view_page_ra = $bookmarked ? $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark', 'start' => $start)) : $this->helper->route('teamrelax_relaxarcade_page_list', array('cid' => $arcade_catid, 'start' => $start));
				$message = (($bookmarked) ? $this->user->lang('RA_BOOKMARK_REMOVED') : $this->user->lang('RA_BOOKMARK_ADDED')) . '<br /><br />' . $this->user->lang('RA_RETURN_LIST', '<a href="' . $view_page_ra . '">', '</a>');
			}
			meta_refresh(3, $view_page_ra);
			trigger_error($message);
		}

		// Catagorie activée ?
		// Accès fondateur quand même autorisé
		if (!$nbcat_auth)
		{
			$message = $this->user->lang('SORRY_ARCADE_CAT_NOACCESS');
			trigger_error($message);
		}

		
		$arcade_catidchp = $this->config['ra_top_classement_points_category'];
		$arcade_catid = ($arcade_catid > 0) ? $arcade_catid : intval($liste_cat_auth[0]['ra_cat_id']);
		if ($arcade_cat_title == '')
		{
			$arcade_cat_title = $liste_cat_auth[0]['ra_cat_title'];
		}

		for ($i = 0; $i < $nbcat; $i++)
		{
			if ($arcade_catid === intval($liste_cat[$i]['ra_cat_id']))
			{
				if ((intval($liste_cat[$i]['ra_cat_active']) === 0) && ($this->user->data['user_type'] != USER_FOUNDER))
				{
					$message = $this->user->lang('INFO_ARCADECAT_NOT_ACTIVATED') . '<br /><br />' . $this->user->lang('RETURN_INDEX', '<a href="' . append_sid($this->root_path . "index." . $this->php_ext) . '">', '</a>');
					trigger_error($message);
				
				}	
				
				if (($arcade_catidchp == $arcade_catid) && (intval($liste_cat[$i]['ra_cat_active']) === 0) && ($this->user->data['user_type'] != USER_FOUNDER))
				{
					
					$message = $this->user->lang('RA_TOURNOI_CLOSE') . '<br /><br />' . $this->user->lang('CLICK_RETURN_ARCADE', '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_list') . '">', '</a>');
					trigger_error($message);
					
					
					
				}
				
				
			}
		}
			$sql = 'SELECT user_id
			FROM ' . RA_BOOKMARKS_TABLE . '
			WHERE user_id = ' . (int)$this->user->data['user_id'];
			$result = $this->db->sql_query($sql);
			$favories = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);
			global $phpbb_container;
		if ($this->config['ra_mchat_list'] && $phpbb_container->has('dmzx.mchat.settings'))
		{
			
			if ($phpbb_container->has('dmzx.mchat.settings'))
			{
			   // We use the page_index() method to render mChat so we need
			   // to enable mChat on the index page only for this request
			   $this->user->data['user_mchat_index'] = 1;
			   $phpbb_container->get('dmzx.mchat.settings')->set_cfg('mchat_index', 1, true);
			   $phpbb_container->get('dmzx.mchat.core')->page_index();
			   $this->template->assign_var('MCHAT_PAGE', 'mchat_on_arcade_page_games');
			}
		}

		$this->template->assign_vars(array(
			'S_RA_MCHAT_LIST' =>$this->config['ra_mchat_list'] ? true : false,
			'L_LIST_CAT' => $this->user->lang('LIST_ARCADE_CAT'),
			'L_TOP_PLAYERS' => $this->user->lang('ARCADE_BEST_PLAYERS'),
			'U_TOP_PLAYERS' => $this->helper->route('teamrelax_relaxarcade_page_topplayers'),
			'L_FAV_GAMES' => $this->user->lang('RA_FAV_GAMES'),
			'NB_DERGAMES' =>$this->config['nb_dernier_games'],			
			'NB_SCOREGAMES' => (!empty($this->config['active_defilement'])) ? $this->config['nb_dernier_scoregames'] : 5,
			'NB_RECORDGAMES' => (!empty($this->config['active_defilement'])) ? $this->config['nb_dernier_recordgames'] : 5,
			'NB_ULTIMEGAMES' =>  (!empty($this->config['active_defilement'])) ? $this->config['nb_dernier_ultimegames'] : 5,
			'L_STAT_GLOB' => $this->user->lang('ARCADE_STAT_GLOB'),
			'L_QUANTIFY' => $this->user->lang('ARCADE_QUANTIFY'),
			'L_GAMES_BESTNOTED' => $this->user->lang('ARCADE_GAMES_BESTNOTED'),
			'L_NB_GAMES' => $this->user->lang('ARCADE_NB_GAMES'),
			'L_NB_PARTS' => $this->user->lang('ARCADE_NB_PARTS'),
			'L_PLAYED_TIME' => $this->user->lang('ARCADE_PLAYED_TIME'),
			'L_OLDER_CHAMPION' => $this->user->lang('ARCADE_OLDER_CHAMPION'),
			'L_WITH_SCORE' => $this->user->lang('ARCADE_WITH_SCORE'),
			'L_SINCE' => $this->user->lang('ARCADE_SINCE'),
			'IS_RELAX' =>true,
			'IS_RELAXINDEX' =>false,
			'GAME_LIBCHAMPION_OF' => $this->user->lang('GAME_CHAMPION_OF'),
			///
			'S_STYLEAFFICHAGE' => (!empty($this->config['Styleaffichage'])) ? true : false,
			'U_SEARCH_GAMES' => $this->helper->route('teamrelax_relaxarcade_page_search'),
			'FAV_GAMES' => ($favories) ? true : false,
			'U_FAV_GAMES' => $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark')),
			'U_NEW_GAMES' => $this->config['ra_last_installed'] ? $this->helper->route('teamrelax_relaxarcade_page_games_new') : '',
			'L_NEW_GAMES' => $this->user->lang('LAST_GAMES'),
			'S_ACTIVE_DEFILEMENT' => (!empty($this->config['active_defilement'])) ? true : false,
			'S_ACTIVE_TIME' => (!empty($this->config['active_time'])) ? true : false,
			'S_ENABLE_TOURNOI' => $this->config['enable_tournoi'] ? true : false,
			'S_STYLE_TOURNOI' => $this->config['not_classement'] ? true : false,
			'S_EQUIPE_TOURNOI' => $this->config['equipe_tournoi'] ? true : false,
			
		));
		

		//
		// Start auth check
		//
		if (!$is_auth_ary[$arcade_catid]['ra_cat_auth_view'])
		{
			trigger_error($this->user->lang('NOT_AUTHORISED'));
		}
		//
		// End auth check
		//
		
		
		//Affichage par groupe de $arcade_nbcol catégories

		$arcade_nbcolmini = intval($this->config['nb_cat_per_row'] <= 5 ) ? intval($this->config['nb_cat_per_row']): 5 ;

		$arcade_nbcol = ((!empty($this->config['Styleaffichage'])) ?  (!(int)$this->user->data['user_relax_style'] ? intval($this->config['nb_cat_per_row']) : $arcade_nbcolmini ) : $arcade_nbcolmini);
		if ($arcade_nbcol == 0)
		{
			$arcade_nbcol = 1;
		}
		$this->template->assign_vars(array(
			'L_NB_COL' => $arcade_nbcol,
			'RA_W_COL' => (100 / $arcade_nbcol)
		));
		$i = 0;
		while ($i < $nbcat_auth)
		{
			$this->template->assign_block_vars('arcadecatrow', array());
			for ($j = 0; $j < $arcade_nbcol && $i < $nbcat_auth; $j++)
			{
				
				$cat_href = isset($liste_cat_auth[$i]['ra_cat_id']) ? $this->helper->route('teamrelax_relaxarcade_page_list', array('cid' => $liste_cat_auth[$i]['ra_cat_id'])) : false;
				if(!empty($liste_cat_auth[$i]['ra_cat_nbgames']))
				{	
				
					$this->template->assign_block_vars('arcadecatrow.arcadecatcol', array(
				   'ARCADE_CAT_PIC'   => !empty($liste_cat_auth[$i]['ra_cat_pic']) ? '<a href="' . $cat_href . '#cat">' . '<img src="' . generate_board_url() . '/arcade/pics_cat/' . $liste_cat_auth[$i]['ra_cat_pic'] . '" title="' . $liste_cat_auth[$i]['ra_cat_title'] . '" alt="' . $liste_cat_auth[$i]['ra_cat_title'] . '" /></a>' : '',
				   'CAT_CHAMP'   =>($this->displaycat_champ($liste_cat_auth[$i]['ra_cat_id']))  ?  $this->displaycat_champ($liste_cat_auth[$i]['ra_cat_id'])  :     $this->user->lang['RA_NOCHAMP_CATSLIST'] ,
				   'CAT'            => $cat_href ? '<a href="' . $cat_href . '#cat">' . $liste_cat_auth[$i]['ra_cat_title'] . '</a>' : '',
				   'NB_GAMES'         => !empty($liste_cat_auth[$i]['ra_cat_nbgames']) ? '(' . $liste_cat_auth[$i]['ra_cat_nbgames'] . ')' : '',
				   'CAT_CLASS'       => $liste_cat_auth[$i]['ra_cat_class'] ? ('<br /><a href="' . $this->helper->route('teamrelax_relaxarcade_page_topplayers_category', array('cid' => $liste_cat_auth[$i]['ra_cat_id'])) . '">' . $this->user->lang('RA_CLASS_CAT') . '</a>') : '',
					));				
				}
				else
				{
					$this->template->assign_block_vars('arcadecatrow.arcadecatcol', array(
				   'ARCADE_CAT_PIC'   => !empty($liste_cat_auth[$i]['ra_cat_pic']) ? '<img src="' . generate_board_url() . '/arcade/pics_cat/' . $liste_cat_auth[$i]['ra_cat_pic'] . '" title="' . $liste_cat_auth[$i]['ra_cat_title'] . '" alt="' . $liste_cat_auth[$i]['ra_cat_title'] . '" />' : '',
				   'CAT_CHAMP'   =>($this->displaycat_champ($liste_cat_auth[$i]['ra_cat_id']))  ?  $this->displaycat_champ($liste_cat_auth[$i]['ra_cat_id'])  :     $this->user->lang['RA_NOCHAMP_CATSLIST'] ,
				   'CAT'            => $liste_cat_auth[$i]['ra_cat_title'],
				   'NB_GAMES'         =>'(0)',
				   'CAT_CLASS'       => $liste_cat_auth[$i]['ra_cat_class'] ? ('<br /><a href="' . $this->helper->route('teamrelax_relaxarcade_page_topplayers_category', array('cid' => $liste_cat_auth[$i]['ra_cat_id'])) . '">' . $this->user->lang('RA_CLASS_CAT') . '</a>') : '',
					));	
				}
				
				if($liste_cat_auth[$i]['ra_cat_id'] == $this->config['ra_top_classement_points_category'])
				{	
					
						$chp_date_start='';
						$this->tournoi_auto();			
						if (!empty($this->config['ra_last_upd_start'])){
						list($startDate,$startTime) = explode(' ', $this->config['ra_last_upd_start']);
						list($startYear,$startMonth,$startDay) = explode('/',$startDate);
						list($startHrs,$startMin,$startSec) = explode(':',$startTime);
						$chp_date_start = strtotime("$startYear/$startMonth/$startDay $startHrs:$startMin:$startSec"); 
						
						list($finDate,$finTime) = explode(' ', $this->config['ra_last_upd']);
						list($finYear,$finMonth,$finDay) = explode('/',$finDate);
						list($finHrs,$finMin,$finSec) = explode(':',$finTime);
						$chp_date_end = strtotime("$finYear/$finMonth/$finDay $finHrs:$finMin:$finSec"); 
						}
						
						$chp_relax_open = '<br /><span>'.$this->user->lang('RA_TOURNOI_OPEN').'</span><br /><span>'.$this->user->lang('RA_TOURNOI_MESSAGE').'</span><br /><span>'.$this->user->lang('CATEGORIE_TOURNOI').'</span>';
						$chp_relax_close = '<br /><span>'.$this->user->lang('RA_TOURNOI_CLOSE').'</span>';
						$chp_relax_open_list = (($this->config['active_time']) === 1 )? '' : '<span>'.$this->user->lang('RA_TOURNOI_OPEN').'</span><br />';
						$chp_relax_close_list = (($this->config['active_time']) === 1)? '' : '<span>'.$this->user->lang('RA_TOURNOI_CLOSE').'</span><br />';
						
						
						
						
					
					if($chp_date_start > time() )
					{

						$this->template->assign_vars( array(
							'INFO_START' =>true,
							'INFO_DATE_START' =>$this->user->lang('RA_CHP_OPEN'). date('d/m/Y H:i',$chp_date_start),
							'TOPCHP' =>(!empty($this->config['enable_tournoi'])) ? $this->user->lang('RA_TOP_CHP') : $this->user->lang('CHAMPIONSHIP_POINTS'),
							'INFO_DATE_START_BLOC' =>'<br /><span>'.$this->user->lang('RA_CHP_OPEN').'</span><br /><span>'. date('d/m/Y H:i',$chp_date_start).'</span><br /><span>'.$this->user->lang('CATEGORIE_TOURNOI').'</span><br /><span>'.$liste_cat_auth[$i]['ra_cat_title'].'</span>',
							'INFO_DATE_START_BLOC_LIST' =>'<span>'.$this->user->lang('CATEGORIE_TOURNOI').'</span><br /><span>'.$liste_cat_auth[$i]['ra_cat_title'].'</span>'
						
						));
						
					}			
					else
					{					
					
						$chp_end_date = (empty($chp_date_end)) ? $this->user->lang('RA_INSDISPONIBLE') :date('d/m/Y H:i', $chp_date_end);
						$this->template->assign_vars( array(
							'INFO_START' => false,
							'TOPCHP' =>(!empty($this->config['enable_tournoi'])) ? $this->user->lang('RA_TOP_CHP') : $this->user->lang('CHAMPIONSHIP_POINTS'),
							'INFO_DATE_END' =>$this->user->lang('RA_CHP_END').$chp_end_date
						));
					}
					
					if($chp_date_start < time() )
					{
						$this->template->assign_vars(array(
						'TOURNOI_CHP' =>(intval($liste_cat[$i]['ra_cat_active']) === 0) ? $chp_relax_close : $chp_relax_open,
						'TOURNOI_CHP_LIST' =>(($this->config['active_time']) === 1) ? (intval($liste_cat[$i]['ra_cat_active']) === 0) ? $chp_relax_close_list : $chp_relax_open_list : '',
						'CATEGORIECHP' => '<a href="' . $cat_href . '">' . $liste_cat_auth[$i]['ra_cat_title'] . '</a> ~',
						'CAT_CLASSCHP' =>$liste_cat_auth[$i]['ra_cat_class'] ? ('<a href="' . $this->helper->route('teamrelax_relaxarcade_page_topplayers_category', array('cid' => $this->config['ra_top_classement_points_category'])) . '">' . $this->user->lang('RA_CLASS_CAT') . '</a>') : '',
						'TIMETOURNOICHP' =>$this->config['ra_last_upd'],
						'L_TOURNOI_COMPLETE' =>$this->config['ra_tournoi_text_fin'],				
						'TOURNOI_TEXT' =>(!empty($this->config['ra_tournoi_text_debut'])) ? $this->config['ra_tournoi_text_debut'] : '' ,
						'L_ARCADE_YEAR' =>$this->user->lang('ARCADE_YEAR'),
						'L_ARCADE_MONTH' =>$this->user->lang('ARCADE_MONTH'),
						'L_ARCADE_DAY' =>$this->user->lang('ARCADE_DAY'),
						'L_ARCADE_HOUR' =>$this->user->lang('ARCADE_HOUR'),
						'L_ARCADE_MINUTE' =>$this->user->lang('ARCADE_MINUTE'),
						'L_ARCADE_SECOND' =>$this->user->lang('ARCADE_SECOND'),
						));
					}
				}				
		
			
				$i++;
				
				
			}
		}
		//Se servir du tableau liste_cat_auth pour les # top 5
		//unset($liste_cat_auth);
		// Créer une condition sql à partir du tableau liste_cat_auth
		$liste_sql_cat_auth = '';
		if ($nbcat_auth > 0)
		{
			$liste_sql_cat_auth = '(';
			for ($i = 0; $i < $nbcat_auth; $i++)
			{
				if ($i == 0)
				{
					$liste_sql_cat_auth .= (int) $liste_cat_auth[$i]['ra_cat_id'];
				}
				else
				{
					$liste_sql_cat_auth .= ',' . (int) $liste_cat_auth[$i]['ra_cat_id'];
				}
			}
			$liste_sql_cat_auth .= ')';
		}
		unset($liste_cat_auth);

		

		// Affichage de la liste de jeux
		$games_per_page = $this->config['games_per_page'];
		$order_by = 'game_id DESC';

		if ($this->config['games_order'] == 'RA_GAMES_ORDER_ALPHA')
		{
			$order_by = 'game_name ASC ';
		}
		else if ($this->config['games_order'] == 'RA_GAMES_ORDER_POPULAR')
		{
			$order_by = 'gamestat_set DESC ';
		}
		else if ($this->config['games_order'] == 'RA_GAMES_ORDER_FIXED')
		{
			$order_by = 'game_order ASC ';
		}
		else if ($this->config['games_order'] == 'RA_GAMES_ORDER_NEWS')
		{
			$order_by = 'game_id DESC ';
		}

		if ($mode == 'bookmark')
		{
			$sql = 'SELECT COUNT(*) AS nbgames
					FROM ' . RA_BOOKMARKS_TABLE . '
					WHERE user_id = ' . (int) $this->user->data['user_id'];
			$mode_key = 'mode';
			$mode_value = 'bookmark';
		}
		else
		{
			$sql = 'SELECT COUNT(*) AS nbgames
					FROM ' . RA_GAMES_TABLE . '
					WHERE ra_cat_id = ' . (int) $arcade_catid;
			$mode_key = 'cid';
			$mode_value = $arcade_catid;
		}

		$result = $this->db->sql_query($sql);
		$total_games = (int) $this->db->sql_fetchfield('nbgames');
		$this->db->sql_freeresult($result);
		
		if (($mode == 'bookmark') && ($total_games < 1))
		{
			$message = $this->user->lang('RA_NOT_BOOKMARK') . '<br /><br />' . $this->user->lang('RA_RETURN_LIST', '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_list') . '">', '</a>');
			trigger_error($message);
		}
				
		$this->template->assign_block_vars('navlinks', array(
			'FORUM_NAME' => $this->user->lang('ARCADE_PAGE'),
			'U_VIEW_FORUM' => $this->helper->route('teamrelax_relaxarcade_page_list'),
		));

		$this->template->assign_block_vars('navlinks', array(
			'FORUM_NAME' => ($mode != 'bookmark') ? $arcade_cat_title : $this->user->lang('RA_FAV_GAMES'),
			'U_VIEW_FORUM' => ($mode != 'bookmark') ? $this->helper->route('teamrelax_relaxarcade_page_list', array('cid' => $arcade_catid)) : $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark')),
		));
			
		
			$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';

			
		$this->template->assign_vars(array(
			'L_CAT' => ($mode != 'bookmark') ? $arcade_cat_title : $this->user->lang('RA_FAV_GAMES'),
			'TOTAL_GAMES' => $total_games,
			'PAGE_NUMBER' 	=> ($total_games > 0) ? $this->pagination->get_on_page($total_games, $games_per_page, $start): '', 
			'PAGINATION' 	=> ($total_games > 0) ? $this->pagination->generate_template_pagination($this->helper->route('teamrelax_relaxarcade_page_list', array($mode_key => $mode_value)), 'pagination', 'start', $total_games, $games_per_page, $start, true): '', 

			'LAYOUT_CONTENT' =>	'<img src="' .  generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme/images/layout_content.png" title="' . $this->user->lang('STYLE_ARCADE') . '" alt="' . $this->user->lang('STYLE_ARCADE') . '" />',
			'DOWNTHEME' => generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme/images/down.gif',		
			'AJAXTHEME' => generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme/images/ajaxloading.gif',		
			'L_GAME' => $this->user->lang('GAMES'),
			'L_HIGHSCORE' => $this->user->lang('ARCADE_HIGHSCORE'),
			'L_YOURSCORE' => $this->user->lang('ARCADE_YOURSCORE'),
			/*debut additionnal img championnship*/
			'IMGCHAMPIONSHIP' =>'<img src="' . $ra_theme_basepath . '/images/championship.png" alt="championnat" />',
			'TOURNOI_LARGE_MAXSIZE' =>$this->config['tournoi_large_maxsize'].'px',
			'TOURNOI_AVATAR_MAXSIZE' =>$this->config['tournoi_avatar_maxsize'].'px',
			'CATCLASSCHP'       => ($this->config['ra_top_classement_points_category'] == -1) ? '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_topplayers') . '">' . $this->user->lang('CHCATEGORIE') . '</a>' : '' ,
			'TOURNOICHP' =>($this->config['ra_top_classement_points_category'] == -1) ?'<br /><span>'.$this->user->lang('RA_TOURNOI_OPEN').'</span><br /><span>'.$this->user->lang('RA_TOURNOI_MESSAGE').'</span><br /><span>'.$this->user->lang('CATEGORIE_TOURNOI').'</span>' :'',
			/*fin additionnal img championnship*/
			'L_DESC' => $this->user->lang('DESC_GAME'),
			'L_NOTE' => $this->user->lang('GAME_NOTE'),
			'L_LIST_GAMES' => $this->user->lang('ARCADE_LIST'),
			'LAST_RECORDS' => $this->user->lang('ARCADE_LAST_RECORDS'),
			'FIVE_LAST_RECORDS' => $this->user->lang('FIVE_LAST_RECORDS'),
			'FIVE_LAST_SCORES' => $this->user->lang('FIVE_LAST_SCORES'),
			'FIVE_GAMES_POP' => $this->user->lang('FIVE_GAMES_POP'),
			'BY' => $this->user->lang('ARCADE_BY'),
			'ON' => $this->user->lang('ARCADE_ON'),
			'PARTY' => $this->user->lang('PARTY'),
			'L_ARCADE_PLAYING' => $this->user->lang('ARCADEPLAYING'),
		));
		
		$topultime =array();
		// Meilleur de score de tous les temps
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.ra_cat_id, g.us_score_game, g.us_user_id, g.us_score_date, u.username, u.user_id, u.user_colour',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'g.us_user_id = u.user_id'
				)
			),
			'WHERE' => 'g.us_score_game',
			'ORDER_BY'	=> 'g.us_score_date DESC',
		);
		$result = $this->db->sql_query($this->db->sql_build_query('SELECT', $sql_array));	
		while( $row = $this->db->sql_fetchrow($result) )
		{	
			$topultime[$row['game_id']]['us_user_id'] = '(' . get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']).')';
		}
		//Liste des jeux avec catégories
		$sql_array = array(
			'SELECT' => 'c.* , g.* , u.username , u.user_id, u.user_colour , s.score_game , s.score_date , a.gamestat_highscore ,
							a.gamestat_highdate , a.gamestat_set, a.gamestat_rating , a.gamestat_rating_set, r.game_rating_val, b.game_id as fav',
			'FROM' => array(
				RA_CAT_TABLE => 'c',
				RA_GAMES_TABLE => 'g'
			),
			'LEFT_JOIN' => array(
				array(
					'FROM' => array(RA_GAMESTAT_TABLE => 'a'),
					'ON' => 'g.game_id = a.game_id',
				),
				array(
					'FROM' => array(RA_GAME_RATING_TABLE => 'r'),
					'ON' => 'g.game_id = r.game_id AND r.user_id = ' . (int) $this->user->data['user_id'],
				),
				array(
					'FROM' => array(RA_SCORES_TABLE => 's'),
					'ON' => 'g.game_id = s.game_id AND s.user_id = ' . (int) $this->user->data['user_id'],
				),
				array(
					'FROM' => array(RA_BOOKMARKS_TABLE => 'b'),
					'ON' => 'g.game_id = b.game_id AND b.user_id = ' . (int) $this->user->data['user_id'],
				),
				array(
					'FROM' => array(USERS_TABLE => 'u'),
					'ON' => 'a.gamestat_user_id = u.user_id',
				),
			),
			'WHERE' => $mode == 'bookmark' ? 'c.ra_cat_id = g.ra_cat_id AND b.user_id = ' . (int) $this->user->data['user_id'] : 'c.ra_cat_id = g.ra_cat_id AND g.ra_cat_id = ' . (int) $arcade_catid,
			'ORDER_BY' => $order_by,
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, $games_per_page, $start);

		while (false !== ($row = $this->db->sql_fetchrow($result)))
		{
			$gamename = $row['game_name'];

			if (is_null($row['gamestat_rating']))
			{
				$gamenote = 0;
			}
			else
			{
				$gamenote = $row['gamestat_rating'];
			}
			if($row['game_cont'] == 0 || !$row['game_cont']){
			$bulle_info = $this->user->lang['CONTROLES_INCONNUS'];
			}elseif($row['game_cont'] == 1){
				$bulle_info = $this->user->lang['CLAVIER_UNIQUEMENT'];
			}elseif($row['game_cont'] == 2){
				$bulle_info = $this->user->lang['SOURIS_UNIQUEMENT'];
			}elseif($row['game_cont'] == 3){
				$bulle_info = $this->user->lang['CLAVIER_SOURIS'];
			}else{
				$bulle_info = '';
			}

			if($row['game_html5'] == 0 || !$row['game_html5']){
			$info = '<img src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
			}elseif($row['game_html5'] == 1){
			$info = '<img src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
			}else{
			$info = '';
			}
			
		
			$username =  ($row['gamestat_highscore']== 0) ?  '' : '(' . get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']).')';
			
			$bookmark_href = $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark', 'cid' => $arcade_catid, 'start' => $start, 'gid' => $row['game_id']));
			$this->template->assign_block_vars('gamerow', array(
				'GAMENAME' => $gamename,
				'GAMELINKRA' => $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])),
				'GAMENAMERA' => $row['game_name'],
				'GAMEPIC' => $row['game_pic'] != '' ? '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '"><img  class="imggrrelax"  src="' . generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_swf']) . '/pics/' . $row['game_pic'] . '"  alt="' . $gamename . '" title="' . $gamename . '" /></a>' : '',
		 		
				'GAMEPICRA' =>generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_swf']) . '/pics/' . $row['game_pic'] . '" alt="' . $gamename . '" title="' . $gamename . '"',
				'GAMEPICRALINK' =>$this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])),
				'GAMEPICWAT' => $ra_theme_basepath . '/images/Hint.png" alt=""',
				'U_MOD' => '<a href="' . append_sid($this->root_path . 'adm/index.' . $this->php_ext . '?i=-teamrelax-relaxarcade-acp-acp_relaxarcade_module&amp;mode=manage&amp;action=game&amp;gaction=gameedit&amp;c=' . $arcade_catid . '&amp;gid=' . $row['game_id'] . '&amp;sid=' . $this->user->data["session_id"]) . '">' . $this->user->lang('MOD_SCORE') . '</a>',
				'GAMESET' => $row['gamestat_set'] != 0 ? $this->user->lang('GAME_NBSET') . ' : ' . $row['gamestat_set'] : '',
				'GAMEDESC' => htmlspecialchars_decode($row['game_desc']),
				'GAME_TYPE'	=>$info,
				'DISPLAY_POS' =>($row['score_game']== 0)  ?  '' : $this->display_pos($row['game_id'],$row['game_scoretype']) ,
				'ULHIGHSCORE' =>($row['us_score_game']== 0) ? $this->user->lang('NO_RECORD') : $row['us_score_game'] + 0,
				'ULHIGHUSER' => ($row['us_user_id'] != 0) ?  $topultime[$row['game_id']]['us_user_id']  : '',
				'ULDATEHIGH' => ($row['us_score_game']== 0) ? '' :  date("d/m/Y H:i",$row['us_score_date']).'<br />'.
				'<a href="javascript:void(0)"title="' . $this->user->lang('SEE_SCORES') . '" onclick="ModalBox(\''. $this->helper->route('teamrelax_relaxarcade_page_viewscores', array('gid' => $row['game_id'])) .'\'); return false;">' . $this->user->lang('SEE_SCORES') . '</a>',
		 		
				'GAMECONT' => '<img src="' . generate_board_url() . '/arcade/pics_controle/' . $row['game_cont'] . '.png" title="' . $bulle_info . '" alt="' . $bulle_info . '" />',
				'HIGHSCORE' =>($row['gamestat_highscore']== 0) ? $this->user->lang('NO_MSCORE') : $row['gamestat_highscore'] + 0,
				'YOURHIGHSCORE' =>($row['score_game']== 0) ? '<br/>'.$this->user->lang('NO_SCORE') : ($row['user_id'] == $this->user->data['user_id'] ? '<img src="' . $ra_theme_basepath . '/images/couronne.png" alt="first" /><br/>' : '') . ($row['score_game'] + 0),
				'GAMENOTE' => $gamenote == 0 ? $this->user->lang('NO_GAME_NOTE') : $gamenote + 0 . '/10', 'GAMERATING' => $gamenote * 10,
				'L_GAME_NBVOTE' => $gamenote == 0 ? '' : (($row['gamestat_rating_set'] > 1) ? $this->user->lang('GAMENBVOTES') . ']' : $this->user->lang('GAMEVOTE') . ']'),
				'GAME_NBVOTE' => $gamenote == 0 ? '' : '[' . $row['gamestat_rating_set'],
				'HIGHUSER' => ($row['user_id'] != 0) ?   $username  : '',
				'GAMEID' => $row['game_id'], 'GAMEFPS' => ($row['game_fps'] != 0) ? $this->user->lang('GAME_FPS') . ' : ' . $row['game_fps'] : '',
				'GAMESIZE' => ($row['game_size'] != 0) ? $this->user->lang('GAME_SIZE') . ' : ' . size_hum_read($row['game_size']) : '',
				'DATEHIGH' => ($row['gamestat_highscore']== 0) ? '' : date("d/m/Y H:i",$row['gamestat_highdate']).'<br />'.'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_gamescores', array('gid' => $row['game_id'])) . '">' . $this->user->lang('SEE_SCORES') . '</a>',
				'YOURDATEHIGH' => ($row['score_date'] == 0) ? '' : date("d/m/Y H:i",$row['score_date']),
				'IMGRATING' => !is_null($row['game_rating_val']) ? '<img src="' . $ra_theme_basepath . '/images/arcade_rating_check.png" title="' . $this->user->lang('GAME_YOUR_NOTE') . ' : ' . $row['game_rating_val'] . '" alt="' . $this->user->lang('GAME_YOUR_NOTE') . ' : ' . $row['game_rating_val'] . '" />' : '',
				'IMGBOOKMARK' => is_null($row['fav']) ? '<a href="' . $bookmark_href . '"><img src="' . $ra_theme_basepath . '/images/ra_favoris.png" title="' . $this->user->lang('RA_FAV_ADD_GAME') . '" alt="' . $this->user->lang('RA_FAV_ADD_GAME') . '" /></a>' : '<a href="' . $bookmark_href . '"><img src="' . $ra_theme_basepath . '/images/ra_fav_del.png" title="' . $this->user->lang('RA_FAV_DEL_GAME') . '" alt="' . $this->user->lang('RA_FAV_DEL_GAME') . '" /></a>',
				'GAMELINK' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '">' . $row['game_name'] . '</a>',
				
			));

			
		}
		$this->db->sql_freeresult($result);
		$this->function_relax->assign_display_challenge();
		$this->function_relax->assign_display_defis();
	
		$this->statistique($liste_sql_cat_auth);
		// Affichage du qui joue
		$tab_player = arcade_view_playing($is_auth_ary);
		if (($tab_player !== false) && (isset($tab_player[0])))
		{
			$nb_players = count($tab_player);
			for ($i = 0; $i < $nb_players; $i++)
			{
				$is_admin = (($this->user->data['session_admin'] && $this->user->data['is_registered']) && ($this->user->data['user_id'] != ANONYMOUS)) ? TRUE : 0;
				if ($tab_player[$i]['user_allow_viewonline'] || $is_admin)
				{
					$this->template->assign_block_vars('arcadeplaying_row', array(
						'GAMENAME' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('mode' => 'bookmark', 'cid' => $arcade_catid, 'start' => $start, 'gid' => $tab_player[$i]['gid'])) . '">' . $tab_player[$i]['gamename'] . '</a>' . ' : ', 'PLAYERLIST' => $tab_player[$i]['playerlist']
					));
				}
			}
		}
		else
		{
			$this->template->assign_block_vars('arcadeplaying_row', array(
				'GAMENAME' => $this->user->lang('ARCADE_NOPLAYING')
			));
		}

		// Cat select
		$sql = 'SELECT ra_cat_id, ra_cat_title, ra_cat_nbgames
				FROM ' . RA_CAT_TABLE . '
		  		WHERE ra_cat_nbgames > 0
					AND ra_cat_id IN ' . $liste_sql_cat_auth . '
				ORDER BY ra_cat_order';
		$result = $this->db->sql_query($sql);

		$this->template->assign_var('L_CAT_BOOKMARK', $mode != 'bookmark' ? '' : '<option value="' . $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark')) . '">' . $this->user->lang('RA_FAV_GAMES') . '</option>');

		while ($row = $this->db->sql_fetchrow($result))
		{
			$selected = $row['ra_cat_id'] == $arcade_catid && $mode != 'bookmark' ? ' selected="selected"' : '';
			$cat_url = '<option value="' . $this->helper->route('teamrelax_relaxarcade_page_list', array('cid' => $row['ra_cat_id'])) . '"' . $selected . '>&#9654; '. $row['ra_cat_title'] . ' (' . $row['ra_cat_nbgames'] . ")</option>";
			$this->template->assign_block_vars('arcade_categories_select', array(
				'U_CATEGORIES_PLAY'	=> $cat_url,
			));
			
			
			$this->template->assign_vars(array(
			'L_SELECT_CAT_BOOK' => '<option value="' . $this->helper->route('teamrelax_relaxarcade_page_list', array('cid' => $arcade_catid)) . '">'.$this->user->lang('CAT_BOOK').'</option>',
		));
			
		}
		$this->db->sql_freeresult($result);

		// Games cat select
		$sql_array = array(
			'SELECT'	=> 'g.game_id , g.game_name ',
			'FROM'		=> array(
				RA_CAT_TABLE => 'c',
				RA_GAMES_TABLE => 'g',
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_BOOKMARKS_TABLE => 'b'),
					'ON'	=> 'g.game_id = b.game_id AND b.user_id = ' . $this->user->data['user_id'],
				),
			),
			'WHERE'		=>	$mode == 'bookmark' ? 'c.ra_cat_id = g.ra_cat_id AND b.user_id = ' . (int) $this->user->data['user_id'] : 'c.ra_cat_id = g.ra_cat_id AND g.ra_cat_id = ' . (int) $arcade_catid,
			'ORDER_BY'	=> 'g.game_name ASC',
		);
		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);

		$this->template->assign_vars(array(
			'L_SELECT_CAT_RA' => ($mode != 'bookmark') ? $this->user->lang('SELECT_GAMES_RA') : $this->user->lang('SELECT_BOOKMARK_RA'),
		));

		while ($row = $this->db->sql_fetchrow($result))
		{
			$game_url2 = '<option value="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '">&#9654; ' . $row['game_name'] . "</option>";
			$this->template->assign_block_vars('arcade_cat_select', array(
				'U_GAME_CAT_PLAY'	=> $game_url2,
			));
		}
		$this->db->sql_freeresult($result);

		// Games select
		$sql = 'SELECT g.game_id , g.game_name
			FROM ' . RA_CAT_TABLE	. ' c
			LEFT JOIN ' . RA_GAMES_TABLE	. ' g ON g.ra_cat_id = c.ra_cat_id
			WHERE g.ra_cat_id IN ' . $liste_sql_cat_auth . '
			ORDER BY g.game_name ASC';
		$result = $this->db->sql_query($sql);

		while ($row = $this->db->sql_fetchrow($result))
		{
			$game_url = '<option value="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '">&#9654; ' . $row['game_name'] . "</option>";
			$this->template->assign_block_vars('arcade_select', array(
				'U_GAME_PLAY'	=> $game_url,
			));
		}
		$this->db->sql_freeresult($result);

		
	if ($mode == 'relax_style')
			{
				
			$sql_ary = array(
				'user_relax_style'			=>$this->request->variable('relax_style', $this->user->data['user_relax_style']),
							);

			$sql = 'UPDATE ' . USERS_TABLE . '
				SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
				WHERE user_id = ' . $this->user->data['user_id'];
			$this->db->sql_query($sql);
            $redirect = $this->helper->route('teamrelax_relaxarcade_page_list');
			redirect($redirect);

		}
		
		$this->template->assign_vars(array(
			'S_UCP_ACTION'			=>$this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'relax_style')),
			'S_ARCADE_STYLE'	=> ((int)$this->user->data['user_relax_style'] == 0) ? true : false,
			'S_ARCADE_CHALL'	=> $this->user->data['user_relax_style'] ? true : false,

		));
		
		page_header( $this->user->lang['ARCADE_PAGE'] );
		
		$this->template->set_filenames(array(
			'body' =>((!empty($this->config['Styleaffichage'])) ?  (!(int)$this->user->data['user_relax_style'] ? 'arcadelist_body.html' :'arcadelistrelax_body.html') : 'arcadelistrelax_body.html')));
				
		page_footer();
	
	}
	 
	
	
	
	
	
	
	function tournoi_auto()
	{
			
			
			 if ( ($this->config['active_time']) && (!empty($this->config['ra_last_upd_start'])) && (!empty($this->config['ra_last_upd'])))
			{
				$timestart = time();
				
				list($starDate,$starTime) = explode(' ', $this->config['ra_last_upd_start']);
				list($starYear,$starMonth,$starDay) = explode('/',$starDate);
				list($starHrs,$starMin,$starSec) = explode(':',$starTime);
				$temps_start = strtotime("now");
				$chp_start = strtotime("$starYear/$starMonth/$starDay $starHrs:$starMin:$starSec"); 
			
				
				
				if ($chp_start < $timestart)
				{
					$sqlary = array(
							'ra_cat_active'	=> 1,
							'ra_cat_submit'	=> 1,
							'ra_cat_class'	=> 1,		
					);
					$sql = "UPDATE " . RA_CAT_TABLE . " SET " . $this->db->sql_build_array('UPDATE', $sqlary) . "
								  WHERE ra_cat_id = ".$this->config['ra_top_classement_points_category'];
					$this->db->sql_query($sql);
			
					
									
				}	

			
				list($finDate,$finTime) = explode(' ', $this->config['ra_last_upd']);
				list($finYear,$finMonth,$finDay) = explode('/',$finDate);
				list($finHrs,$finMin,$finSec) = explode(':',$finTime);
				$temps_end = strtotime("now");				
				$chp_end = strtotime("$finYear/$finMonth/$finDay $finHrs:$finMin:$finSec"); 
				$timestart = time();
				
				
				if($temps_end > $chp_end)
				{
					$sqlary = array(
							'ra_cat_active'	=> 0,
							'ra_cat_submit'	=> 0,
					);
					$sql = "UPDATE " . RA_CAT_TABLE . " SET " . $this->db->sql_build_array('UPDATE', $sqlary) . "
								  WHERE ra_cat_id = ".$this->config['ra_top_classement_points_category'];
					$this->db->sql_query($sql);
					
								
			
				
							
				}	

		
			
					
			}
			
			
			
			
	}
	
	function display_pos($gid,$highscore_type)
	{
	
	$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';

	$sql_array = array(
			'SELECT'	=> '(count(s2.user_id)+1) as position, s1.score_game, s1.score_date, u.username, u.user_id, u.user_colour',
			'FROM'		=> array(
				RA_SCORES_TABLE	=> 's1'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's2'),
					'ON'	=> ($highscore_type == 0) ? '(s1.score_game < s2.score_game and s1.game_id = s2.game_id)'
													  : '(s1.score_game > s2.score_game and s1.game_id = s2.game_id)'
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 's1.user_id = u.user_id '
				)
			),
			'WHERE'		=> 's1.game_id = ' . $gid .' and s1.user_id = '.(int) $this->user->data['user_id'] ,
			'GROUP_BY'	=> 's1.user_id ',
			'ORDER_BY'	=> 'position ASC, s1.score_date ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$position = '';
		while ($row = $this->db->sql_fetchrow($result))
		{
			$position = $row['position'];
			
		}
		$this->db->sql_freeresult($result);

		$img = '<img src="' . $ra_theme_basepath . '/images/pos.png" alt="'.$this->user->lang['ARCADE_POSITION'].'" />';
		if($position == 1)$position = $img." <b>".$position."</b>".$this->user->lang['RA_POS'];
		elseif($position == 2)$position = $img." <b>".$position."</b>".$this->user->lang['RA_POS_D'];
		elseif($position == 3)$position = $img." <b>".$position."</b>".$this->user->lang['RA_POS_T'];
		else $position = $img. " <b>".$position."</b>".$this->user->lang['RA_POS_L'];
		
		return $position;
	
	
	
	}
	
	
	
	
	function statistique($liste_sql_cat_auth)

	{
			// Affichage de la liste des derniers jeu
		$limite  = $this->config['nb_dernier_games'];
		$nb_dernier_scoregames = (!empty($this->config['active_defilement'])) ? $this->config['nb_dernier_scoregames'] : 5;
		$nb_dernier_recordgames = (!empty($this->config['active_defilement'])) ? $this->config['nb_dernier_recordgames'] : 5;
		$nb_dernier_ultimegames =  (!empty($this->config['active_defilement'])) ? $this->config['nb_dernier_ultimegames'] : 5;
		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';

		
		
		$sql_array = array(
			'SELECT' => ' g.game_id, g.game_name, g.game_pic, g.game_html5',
			'FROM' => array(RA_GAMES_TABLE => 'g'),
			
			'WHERE' => 'g.ra_cat_id IN ' . $liste_sql_cat_auth,
			'ORDER_BY' => 'g.game_id DESC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql,$limite, 0);

		
		while (false !== ($row = $this->db->sql_fetchrow($result)))
		{
			if($row['game_html5'] == 0 || !$row['game_html5']){
			$infos = '<img style="text-align: center;margin-top:5px;display: inline-block;"  width="15px" height="15px" src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
			}elseif($row['game_html5'] == 1){
			$infos = '<img style="text-align: center;margin-top:5px;display: inline-block;"  width="15px" height="15px" src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
			}else{
			$infos = '';
			}
			$this->template->assign_block_vars('newgames', array(
				'GAME_TYPES'	=>'<a style="margin-top:5px" href="'.$this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])).'" >'.$row['game_name'].'<br/>'.$infos.'</a>',
				'GAMEPIC' => generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_pic']) . '/pics/' . $row['game_pic'],
	
			));
		}
		
		
		
		// Affichage de la liste des derniers scores
		$sql_array = array(
			'SELECT' => 'u.username, u.user_id, u.user_colour, g.game_id, g.game_name, g.game_pic, s.score_game, s.score_date',
			'FROM' => array(RA_SCORES_TABLE => 's'),
			'LEFT_JOIN' => array(
				array(
					'FROM' => array(RA_GAMES_TABLE => 'g'),
					'ON' => 's.game_id = g.game_id'
				), array(
					'FROM' => array(USERS_TABLE => 'u'),
					'ON' => 's.user_id = u.user_id'
				)
			),
			'WHERE' => 'g.ra_cat_id IN ' . $liste_sql_cat_auth,
			'ORDER_BY' => 's.score_date DESC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, $nb_dernier_scoregames, 0);

		while (false !== ($row = $this->db->sql_fetchrow($result)))
		{
			$this->template->assign_block_vars('scorerow', array(
				'DERSCORE' => $row['score_game'] + 0,
				'DERGAME' => $row['game_name'],
				'DERPLAYER' => get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
				'GAMEPIC' => generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_pic']) . '/pics/' . $row['game_pic'],
				'GAMELINK' => $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])),
				'DERDATE' => $this->user->format_date($row['score_date']),
			));
		}
		$this->db->sql_freeresult($result);

		// Affichage de la liste des derniers records
		$sql_array = array(
			'SELECT' => 'u.username, u.user_id, u.user_colour, g.game_id, g.game_name, g.game_pic, s.gamestat_highscore, s.gamestat_highdate',
			'FROM' => array(
				RA_GAMESTAT_TABLE => 's',
				RA_GAMES_TABLE => 'g',
				USERS_TABLE => 'u',
			),
			'WHERE' => 's.game_id = g.game_id
					AND s.gamestat_user_id = u.user_id
					AND g.ra_cat_id IN ' . $liste_sql_cat_auth,
			'ORDER_BY' => 's.gamestat_highdate DESC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, $nb_dernier_recordgames, 0);

		while (false !== ($row = $this->db->sql_fetchrow($result)))
		{
			$this->template->assign_block_vars('recordrow', array(
				'RECSCORE' => $row['gamestat_highscore'] + 0,
				'RECGAME' => $row['game_name'],
				'RECPLAYER' => get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
				'GAMEPIC' => generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_pic']) . '/pics/' . $row['game_pic'],
				'GAMELINK' => $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])),
				'RECDATE' => $this->user->format_date($row['gamestat_highdate']),
			));
		}
		$this->db->sql_freeresult($result);

		// Affichage de la liste des jeux les plus joués
		$sql_array = array(
			'SELECT' => 'g.game_id, g.game_name, g.game_pic, s.gamestat_set',
			'FROM' => array(RA_GAMESTAT_TABLE => 's'),
			'LEFT_JOIN' => array(
				array(
					'FROM' => array(RA_GAMES_TABLE => 'g'),
					'ON' => 's.game_id = g.game_id',
				),
			),
			'WHERE' => 's.gamestat_set > 0 AND g.ra_cat_id IN ' . $liste_sql_cat_auth,
			'ORDER_BY' => 's.gamestat_set DESC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 5, 0);

		while (false !== ($row = $this->db->sql_fetchrow($result)))
		{
			$this->template->assign_block_vars('playrow', array(
				'PLAYGAME' => $row['game_name'],
				'GAMEPIC' => generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_pic']) . '/pics/' . $row['game_pic'],
				'GAMELINK' => $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])),
				'PLAYNB' => $row['gamestat_set'],
			));
		}
		$this->db->sql_freeresult($result);

		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';

		// top ultime
		// Meilleur de score de tous les temps
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.ra_cat_id, g.game_name, g.game_desc, g.game_pic, g.game_swf, g.game_scoretype, g.game_width, g.game_height, g.game_bgcolor, g.us_score_game, g.us_user_id, g.us_score_date,
							u.username, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'g.us_user_id = u.user_id'
				)
			),
			'WHERE' => 'g.us_score_game AND g.ra_cat_id IN ' . $liste_sql_cat_auth,
			'ORDER_BY'	=> 'g.us_score_date DESC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, $nb_dernier_ultimegames, 0);

		while (false !== ($row = $this->db->sql_fetchrow($result)))
		{
				
			$this->template->assign_block_vars('ultirow', array(
				'ULGAME' => $row['game_name'],
				'GAMEPIC' => generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_pic']) . '/pics/' . $row['game_pic'],
				'ULGAMELINK' => $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])),
				'ULDATE' => $this->user->format_date($row['us_score_date']),
				'ULSCORES' => ($row['us_score_game'] + 0),
				'ULPLAYER' => get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
			));
		
		}
		$this->db->sql_freeresult($result);
		//fin
		// Addon top class points categorie
		$ra_cat_id = $this->config['ra_top_classement_points_category'];
		// equipe exclus ACP
		$exclude_equipe_config = '';
		if ( $this->config['mc_no_equipe'])
		{
			$exclude_equipe_config = ' AND ' . $this->db->sql_in_set('u.group_id', explode(',',  $this->config['mc_no_equipe']), true);
		}
		$sql_array = array(
			'SELECT' => 'COUNT(s.game_id) AS nbvictories, s.user_id, u.username, u.user_colour',
			'FROM' => array(
				RA_SCORES_TABLE => 's',
				RA_GAMESTAT_TABLE => 'st',
				USERS_TABLE => 'u',
			),
			'WHERE' => 'st.game_id = s.game_id
    			AND st.gamestat_highscore = s.score_game
    			AND s.user_id = u.user_id',
			'GROUP_BY' => 's.user_id, u.username',
			'ORDER_BY' => 'nbvictories DESC, s.user_id ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$cup_tab = Array();	
		while ($row = $this->db->sql_fetchrow($result))
			{
				
				$cup_tab[$row['user_id']] = $row['nbvictories'] ;
			}
			$this->db->sql_freeresult($result);
		if( $ra_cat_id == -1 )
				{
					$sql_array = array(
						'SELECT'	=> 'u.group_id, u.user_id, u.username, u.user_colour, SUM(score_points) AS total_points',
						'FROM'		=> array(
							USERS_TABLE		=> 'u',
							RA_GAMES_TABLE	=> 'g',
							RA_SCORES_TABLE	=> 's',
						),
						'WHERE'		=> 'u.user_id = s.user_id AND s.game_id = g.game_id'.$exclude_equipe_config,
						'GROUP_BY'	=> 's.user_id HAVING total_points > 0',
						'ORDER_BY'	=> 'total_points DESC',
					);
						$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query_limit($sql, 10);

			$tovict_imgs = array(
				1 => '1st.gif',
				2 => '2nd.gif',
				3 => '3rd.gif',
				4 => '4th.gif',
				5 => '5th.gif',
				6 => '6rd.gif',
				7 => '7rd.gif',
				8 => '8rd.gif',
				9 => '9rd.gif',
				10 => '10rd.gif',
				11 => '11rd.gif',
				12 => '12rd.gif',
				13 => '13rd.gif',
				14 => '14rd.gif',
				15 => '15rd.gif',
			);

			$placetemp3 = 0;
			$nbpointsprec3 = 0;
			$place_toppoints3 = 0;
			while ($row = $this->db->sql_fetchrow($result))
			{
				$placetemp3++;

				if ($nbpointsprec3 <> $row['total_points'])
				{
					$place_toppoints3 = $placetemp3;
					$nbpointsprec3 = $row['total_points'];
				}

				$this->template->assign_block_vars('categorie_row', array(
					'CLASSEMENT' => $place_toppoints3,
					'PLAYER' => get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
					'IMG' => isset($tovict_imgs[$placetemp3]) ? ($ra_theme_basepath . '/images/' . $tovict_imgs[$placetemp3]) : '',
					'TOTALPOINTS' => $row['total_points'],
					'NBVICTORIES' =>empty( $cup_tab[$row['user_id']]) ? '0' : $cup_tab[$row['user_id']],
				));
			}
			$this->db->sql_freeresult($result);
			
			if ($this->config['equipe_tournoi'])
			{
			$this->function_relax->point_equipe();
			}
			$this->template->assign_vars(array(
				'TOUTECATEGORIE' =>  $this->user->lang('TOUTE_CATEGORIE'),
				'S_TOUTECATEGORIE' => true,
				'U_TOP_CLASSEMENT_CAT' => true,
			));
		}
		if ($ra_cat_id)
		{
			$sql_array = array(
			'SELECT'	=> 'COUNT(s.game_id) AS nbvictories, s.user_id, u.username, u.user_colour',
			'FROM'		=> array(
				RA_SCORES_TABLE		=> 's',
				RA_GAMESTAT_TABLE	=> 'st',
				RA_GAMES_TABLE  => 'g',
				USERS_TABLE			=> 'u'
			),
			'WHERE'		=> 's.game_id = g.game_id AND st.game_id = s.game_id
							AND st.gamestat_highscore = s.score_game
							AND s.user_id = u.user_id AND g.ra_cat_id = ' . (int) $ra_cat_id,
			'GROUP_BY'	=> 's.user_id, u.username',
			'ORDER_BY'	=> 'nbvictories DESC, s.user_id ASC'
		);

	$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$cup_tab = Array();	
		while ($row = $this->db->sql_fetchrow($result))
			{
				
				$cup_tab[$row['user_id']] = $row['nbvictories'] ;
			}
			$sql_array = array(
				'SELECT'	=> 'u.group_id, u.user_id, u.username, u.user_colour, SUM(score_points) AS total_points',
				'FROM'		=> array(
					USERS_TABLE		=> 'u',
					RA_GAMES_TABLE	=> 'g',
					RA_SCORES_TABLE	=> 's',
				),
				'WHERE'		=> 'u.user_id = s.user_id AND s.game_id = g.game_id'.$exclude_equipe_config.' AND g.ra_cat_id = ' . (int) $ra_cat_id,
				'GROUP_BY'	=> 's.user_id HAVING total_points > 0',
				'ORDER_BY'	=> 'total_points DESC',
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query_limit($sql, 10);

			$tovict_imgs = array(
				1 => '1st.gif',
				2 => '2nd.gif',
				3 => '3rd.gif',
				4 => '4th.gif',
				5 => '5th.gif',
				6 => '6rd.gif',
				7 => '7rd.gif',
				8 => '8rd.gif',
				9 => '9rd.gif',
				10 => '10rd.gif',
				11 => '11rd.gif',
				12 => '12rd.gif',
				13 => '13rd.gif',
				14 => '14rd.gif',
				15 => '15rd.gif',
			);

			$placetemp3 = 0;
			$nbpointsprec3 = 0;
			$place_toppoints3 = 0;
			while ($row = $this->db->sql_fetchrow($result))
			{
				$placetemp3++;

				if ($nbpointsprec3 <> $row['total_points'])
				{
					$place_toppoints3 = $placetemp3;
					$nbpointsprec3 = $row['total_points'];
				}

				$this->template->assign_block_vars('categorie_row', array(
					'CLASSEMENT' => $place_toppoints3,
					'PLAYER' => get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
					'IMG' => isset($tovict_imgs[$placetemp3]) ? ($ra_theme_basepath . '/images/' . $tovict_imgs[$placetemp3]) : '',
					'TOTALPOINTS' => $row['total_points'],
					'NBVICTORIES' =>empty( $cup_tab[$row['user_id']]) ? '0' : $cup_tab[$row['user_id']],
				));
			}
			$this->db->sql_freeresult($result);
			if ($this->config['equipe_tournoi'])
			{
			$this->function_relax->point_equipecat($ra_cat_id);	
			}
			$this->template->assign_vars(array(
				'U_TOP_CLASSEMENT_CAT' => $this->helper->route('teamrelax_relaxarcade_page_topplayers_category', array('cid' => $ra_cat_id)),
			));
		}
		// Addon top class points categorie
	// victory
	$sql_array = array(
			'SELECT' => 'COUNT(s.game_id) AS nbvictories, s.user_id, u.username, u.user_colour, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height',
			'FROM' => array(
				RA_SCORES_TABLE => 's',
				RA_GAMESTAT_TABLE => 'st',
				USERS_TABLE => 'u',
			),
			'WHERE' => 'st.game_id = s.game_id
    			AND st.gamestat_highscore = s.score_game
    			AND s.user_id = u.user_id',
			'GROUP_BY' => 's.user_id, u.username',
			'ORDER_BY' => 'nbvictories DESC, s.user_id ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 5);
			$place = 0;
			$nbpointsprec = 0;
			$place_topvict = 0;
			while ($row = $this->db->sql_fetchrow($result))
			{
				$place++;

				if ($nbpointsprec <> $row['nbvictories'])
				{
					$place_topvict = $place;
					$nbpointsprec = $row['nbvictories'];
				}

				$display_avatar = $this->user->optionget('viewavatars');	
			
				$user_avatars[$row['user_id']] = !$display_avatar || !$row['user_avatar'] ? '' : phpbb_get_user_avatar(array(
					'avatar'		=> $row['user_avatar'],
					'avatar_type'	=> $row['user_avatar_type'],
					'avatar_width'	=> $row['user_avatar_width'] >= $row['user_avatar_height'] ? 25 : 0,
					'avatar_height'	=> $row['user_avatar_width'] >= $row['user_avatar_height'] ? 0 : 25,
				));	
				
					$this->template->assign_block_vars('victories_row', array(
					'VICT_CHAMPION_AVATAR' =>($row['user_avatar']) ? $user_avatars[$row['user_id']] : '<img src="'.generate_board_url() . '/styles/'.$this->user->style['style_path'].'/theme/images/no_avatar.gif" width="25" height="25" alt="' . ((!empty($this->user->lang['USER_AVATAR'])) ? $this->user->lang['USER_AVATAR'] : '') . '" />',
					'CLASSEMENT'	=> $place,
					'UID' => $row['user_id'],
					'PLAYER'		=> get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
					
					'NBVICTORIES'	=> $row['nbvictories'],
					'U_RA_PRIZE' => $this->helper->route('teamrelax_relaxarcade_page_prize'),
				));
				if ($place >= $this->config['ra_top_leader'])
				{
				break;
				}
			}
			$this->db->sql_freeresult($result);
	//

	 $total_games =  $total_parts =	 $played_total_times = $older_champion ='';
		
	//Nombre total de jeux
		$sql = 'SELECT SUM(ra_cat_nbgames) as total_games
				FROM ' . RA_CAT_TABLE;
		$result = $this->db->sql_query($sql);
		if ($row = $this->db->sql_fetchrow($result))
		{
			if (!is_null($row['total_games']))
			{
				$total_games = $row['total_games'];
			}
			$this->db->sql_freeresult($result);
		}

		//Nombre total de parties jouées
		$sql = 'SELECT SUM(gamestat_set) as total_parts
				FROM ' . RA_GAMESTAT_TABLE;
		$result = $this->db->sql_query($sql);
		if ($row = $this->db->sql_fetchrow($result))
		{
			if (!is_null($row['total_parts']))
			{
				$total_parts = $row['total_parts'];
			}
			$this->db->sql_freeresult($result);
		}

		//Temps total de parties jouées
		$sql = 'SELECT SUM(score_time) as played_total_times
				FROM ' . RA_SCORES_TABLE;
		$result = $this->db->sql_query($sql);
		if ($row = $this->db->sql_fetchrow($result))
		{
			if (!is_null($row['played_total_times']))
			{
				$played_total_times = arcade_time($row['played_total_times']);
			}
			$this->db->sql_freeresult($result);
		}

		//Champion le plus ancien à un jeu
		$sql_array = array(
			'SELECT'	=> 'g.game_id, u.username, u.user_id, u.user_colour, gs.gamestat_highdate, g.game_name, gs.gamestat_highscore',
			'FROM'		=> array(
				RA_GAMESTAT_TABLE	=> 'gs',
				RA_GAMES_TABLE		=> 'g',
				USERS_TABLE			=> 'u'
			),
			'WHERE'		=> 'gs.game_id = g.game_id
							AND gs.gamestat_user_id = u.user_id',
			'ORDER_BY'	=> 'gs.gamestat_highdate ASC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 1, 0);
		
		
		if ($row = $this->db->sql_fetchrow($result))
		{
			if (!is_null($row['username']))
			{
				$older_champion = get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']);
			}
			
		}
		$this->db->sql_freeresult($result);
		$this->template->assign_block_vars('arcade_quantify', array(
			'TOTAL_GAMES' => $total_games,
			'TOTAL_PARTS' => $total_parts,
			'PLAYED_TIME' => $played_total_times,
			'OLDER_CHAMPION' => $older_champion,
			'GAME_NAME' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '" >' .$row['game_name'] . '</a>',
			'CHAMP_SCORE' => $row['gamestat_highscore'] + 0,
			'CHAMP_DATE' => $this->user->format_date($row['gamestat_highdate']),
		));
	
		// Top 5 des jeux les mieux notés
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.game_name, g.game_pic, gs.gamestat_rating, gs.gamestat_rating_set',
			'FROM'		=> array(
				RA_GAMESTAT_TABLE	=> 'gs'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_GAMES_TABLE => 'g'),
					'ON'	=> 'gs.game_id = g.game_id'
				)
			),
			'WHERE'		=> 'gs.gamestat_rating > 0
							AND g.ra_cat_id IN ' . $liste_sql_cat_auth,
			'ORDER_BY'	=> 'gs.gamestat_rating DESC, gs.gamestat_rating_set DESC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 5, 0);

		while ( $row = $this->db->sql_fetchrow($result) )
		{
			$this->template->assign_block_vars('games_bestnoted_row', array(
				'GAME' => $row['game_name'],
				'GAMEPIC' => generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_pic']) . '/pics/' . $row['game_pic'],
				'GAMELINK' => $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])),
				'NOTE' => $row['gamestat_rating'] + 0 . '/10',
				'L_GAME_NBVOTE' => $row['gamestat_rating_set'] > 1 ? $this->user->lang('GAMENBVOTES') : $this->user->lang('GAMEVOTE'),
				'GAME_NBVOTE' => $row['gamestat_rating_set'],
			));
		}
		$this->db->sql_freeresult($result);

		return;
}


		function displaycat_champ($cat)
	{
	
	
		// Compte du nombre de premières places par joueur (prise en compte des égalités)
		$sql_array = array(
			'SELECT'	=> 'COUNT(s.game_id) AS nbvictories, s.user_id, u.username, u.user_colour,s.score_date',
			'FROM'		=> array(
				RA_SCORES_TABLE		=> 's',
				RA_GAMESTAT_TABLE	=> 'st',
				RA_GAMES_TABLE  => 'g',
				USERS_TABLE			=> 'u'
			),
			'WHERE'		=> 's.game_id = g.game_id AND st.game_id = s.game_id
							AND st.gamestat_highscore = s.score_game
							AND s.user_id = u.user_id AND g.ra_cat_id = ' . $cat,
			'GROUP_BY'	=> 's.user_id, u.username',
			'ORDER_BY'	=> 'nbvictories DESC, s.user_id ASC, s.score_date ASC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 1, 0);
		$champion = '';

		
	

	while ($row = $this->db->sql_fetchrow($result))
		{
			
			$champion =	 $this->user->lang['RA_CHAMP_CATS'] .'<br/>'.   get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']) .'<a href="#"  onclick="showModalBox(\''.$this->helper->route('teamrelax_relaxarcade_page_prizecat', array('c' => $cat)).'\','. $row['user_id'].'); return false;">&nbsp;('.$row['nbvictories'].')</a>';
				
		}
		$this->db->sql_freeresult($result);
	
	
		
		return $champion;

	
	}

		


	

	
		
		
	


	
}

