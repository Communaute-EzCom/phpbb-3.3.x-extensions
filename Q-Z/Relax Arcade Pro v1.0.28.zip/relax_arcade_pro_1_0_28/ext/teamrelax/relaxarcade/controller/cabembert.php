<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class cabembert
{
	/** @var config */
	protected $config;
	
	/** @var helper */
	protected $helper;	

	/** @var db_interface */
	protected $db;


	/** @var request_interface */
	protected $request;
	
	/** @var template */
	protected $template;

	/** @var user */
	protected $user;
	
	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var string */
	protected $ext_path;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->config 		= $config;
		$this->helper 		= $helper;
		$this->db 			= $db;
		$this->request 		= $request;
		$this->template 	= $template;		
		$this->user 		= $user;
		$this->root_path 	= $root_path;
		$this->php_ext 		= $php_ext;
	}

	public function handle()
	{
		
			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

			$group_id	= $this->request->variable('g', 0);
			$ra_cat_id	= $this->request->variable('c', 0);
			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
			$mode = $this->request->variable('mode', '');


			require_once ($ext_path . 'arcade/jpgraph/jpgraph.' . $this->php_ext);
			require_once ($ext_path .'arcade/jpgraph/jpgraph_pie.' . $this->php_ext);
			require_once( $ext_path .'arcade/jpgraph/jpgraph_pie3d.' . $this->php_ext);
			
			$graph = new\PieGraph(800,450);
			$xdata = array();
			$ydata = array();
		
			// Switch the mode
		switch ($mode)
		{
			
			case 'cat':
			$sql_array = array(
							'SELECT'	=> 'u.user_id,u.group_id, u.username, u.user_colour, SUM(s.score_points) AS score_points ,count(DISTINCT u.group_id), gr.group_name, gr.group_id, gr.group_colour, gr.group_type',
							'FROM'		=> array(
								RA_GAMES_TABLE	=> 'g',
								RA_SCORES_TABLE	=> 's',
							),
							
							'WHERE'		=> 's.game_id = g.game_id AND u.group_id = '.$group_id .' AND g.ra_cat_id = ' . (int) $ra_cat_id,
							'LEFT_JOIN' => array(
											array(
									'FROM' => array(USERS_TABLE => 'u'),
									'ON' => 'u.user_id = s.user_id'),
									array(
									'FROM' => array(GROUPS_TABLE => 'gr'),
									'ON' => 'gr.group_id = u.group_id') 
							),
							'GROUP_BY' 	=> 'u.user_id',
							
							'ORDER_BY'	=> ' s.score_points DESC',
						);
					
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
		
			while ($row = $this->db->sql_fetchrow($result))
				{
					
				$group_name =  ($row['group_type'] == GROUP_SPECIAL) ? $this->user->lang['G_' . $row['group_name']] : $row['group_name'];	
					
				$xdata[] =   $row['score_points'];			
				$titre = $this->user->lang['PTSEQUIPE'].' ' .$group_name;
				$ydata[] =  $row['username'];
				}
				break;

			case 'news':
			$sql_array = array(
							'SELECT'	=> 'u.user_id,u.group_id, u.username, u.user_colour, SUM(s.score_points) AS score_points ,count(DISTINCT u.group_id), gr.group_name, gr.group_id, gr.group_colour, gr.group_type',
							'FROM'		=> array(
								RA_GAMES_TABLE	=> 'g',
								RA_SCORES_TABLE	=> 's',
							),
							
							'WHERE'		=> 's.game_id = g.game_id AND u.group_id = '.$group_id,
							'LEFT_JOIN' => array(
											array(
									'FROM' => array(USERS_TABLE => 'u'),
									'ON' => 'u.user_id = s.user_id'),
									array(
									'FROM' => array(GROUPS_TABLE => 'gr'),
									'ON' => 'gr.group_id = u.group_id') 
							),
							'GROUP_BY' 	=> 'u.user_id',
							
							'ORDER_BY'	=> ' s.score_points DESC',
						);
					
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
		
			while ($row = $this->db->sql_fetchrow($result))
				{
					
				$group_name =  ($row['group_type'] == GROUP_SPECIAL) ? $this->user->lang['G_' . $row['group_name']] : $row['group_name'];	
					
				$xdata[] =   $row['score_points'];			
				$titre = $this->user->lang['PTSEQUIPE'].' ' .$group_name;
				$ydata[] =  $row['username'];
				}

			break;
		}		
	
			
	 
function array_concat_values($t1, $t2) {
	$i = 0;
	foreach ($t1 as $v1) {
		$t1[$i] = "$v1 ($t2[$i])";
		$i ++;
	}
	return $t1;
}
 
$leg = array_concat_values($ydata, $xdata);


$theme_class= new\SoftyTheme;
$graph->SetTheme($theme_class);

// Set A title for the plot
$graph->title->Set($titre);

$p1 = new\PiePlot3D($xdata);
$p1->SetSize(0.5);
$p1->SetCenter(0.45);

$p1->SetLegends($leg);

$graph->legend->Pos(0.01,0.20);
$p1->SetLabelType(PIE_VALUE_ABS);
$p1->ExplodeAll(10);
$graph->SetShadow();
// Display each label with postfix 'kr', e.g. each label will
// look like (for example) 23.5 kr
$p1->value->SetFormat('%d pts');

$p1->value->Show(); 
$graph->Add($p1);
$p1->ShowBorder();

$p1->SetCenter(0.4);
$p1->SetColor('black');

$graph->Stroke();		
			
			
			

	
	}
	


	
}

