<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;



class arcade_viewscores
{

	/** @var user */
	protected $user;

	/** @var config */
	protected $config;

	/** @var request_interface */
	protected $request;

	/** @var db_interface */
	protected $db;

	/** @var template */
	protected $template;

	/** @var pagination */
	protected $pagination;

	/** @var helper */
	protected $helper;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\pagination $pagination,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->config 		= $config;
		$this->helper 		= $helper;
		$this->db 			= $db;
		$this->pagination	= $pagination;
		$this->request 		= $request;
		$this->template 	= $template;		
		$this->user 		= $user;
		$this->root_path 	= $root_path;
		$this->php_ext 		= $php_ext;
	}

	public function handle()
	{
			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

		include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		include($ext_path . 'arcade/includes/functions_arcade.' . $this->php_ext);
		include($ext_path . 'arcade/includes/arcade_auth.' . $this->php_ext);
		include($this->root_path . 'includes/functions_display.' . $this->php_ext);
		include($this->root_path . 'includes/bbcode.' . $this->php_ext);

		
		$auth_vote = true;
		$gid = $this->request->variable('gid', 0);
		$mode = $this->request->variable('mode', '');
		$start = $this->request->variable('start', 0);
		$start = $start < 0 ? 0 : $start;

		// Arcade fermé ?
		if ($this->config['arcade_close'] && $this->user->data['user_type'] != USER_FOUNDER)
		{
			$message = $this->user->lang('INFO_ARCADE_CLOSE') . '<br /><br />' . $this->user->lang('RETURN_INDEX', '<a href="' . append_sid($this->root_path . "index." . $this->php_ext) . '">', '</a>');
			trigger_error($message);
		}

		//Infos sur le jeu
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.game_name, g.game_desc, g.game_pic, g.game_swf, g.game_scoretype, g.ra_cat_id,
							u.username, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height, st.gamestat_highscore, st.gamestat_highdate, st.gamestat_rating',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g',
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_GAMESTAT_TABLE => 'st'),
					'ON'	=> 'g.game_id = st.game_id',
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'st.gamestat_user_id = u.user_id',
				)
			),
			'WHERE'		=> 'g.game_id = ' . (int) $gid,
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			trigger_error($this->user->lang('RA_NO_GAME'));
		}

		$highscore_type = $row['game_scoretype'];
		$arcade_cat_id = $row['ra_cat_id'];
		$display_avatar = $this->user->optionget('viewavatars');	
		
		
				// Affichage du champion
		$sql_array = array(
			'SELECT'	=> '(count(s2.user_id)+1) as position, s1.score_game, s1.score_date, u.username, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height',
			'FROM'		=> array(
				RA_SCORES_TABLE	=> 's1'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's2'),
					'ON'	=> ($highscore_type == 0) ? '(s1.score_game < s2.score_game and s1.game_id = s2.game_id)'
													  : '(s1.score_game > s2.score_game and s1.game_id = s2.game_id)'
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 's1.user_id = u.user_id'
				)
			),
			'WHERE'		=> 's1.game_id = ' . $gid,
			'GROUP_BY'	=> 's1.user_id',
			'ORDER_BY'	=> 'position ASC, s1.score_date ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 1);
		$rowtop = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);
		
		$username = get_username_string('full',$rowtop['user_id'], $rowtop['username'], $rowtop['user_colour']);
		$gamestat_highscore = ($rowtop['score_game']+0);
		$gamestat_highdate = $rowtop['score_date'];
		
		$user_avatars[$rowtop['user_id']] = !$display_avatar || !$rowtop['user_avatar'] ? '' : phpbb_get_user_avatar(array(
			'avatar'		=> $rowtop['user_avatar'],
			'avatar_type'	=> $rowtop['user_avatar_type'],
			'avatar_width'	=> $rowtop['user_avatar_width'] >= $rowtop['user_avatar_height'] ? 40 : 0,
			'avatar_height'	=> $rowtop['user_avatar_width'] >= $rowtop['user_avatar_height'] ? 0 : 40,
			));
		// Meilleur de score de tous les temps
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.us_score_game, g.us_user_id, g.us_score_date, u.username, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'g.us_user_id = u.user_id'
				)
			),
			'WHERE'      => 'g.game_id = ' . (int) $gid,
			'ORDER_BY'	=> 'g.us_score_date DESC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 1,  0);
		$rowgame_us = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$rowgame_us)
		{
			trigger_error($this->user->lang('RA_NO_GAME'));
		}

		$ulusernames = get_username_string('full', $rowgame_us['user_id'], $rowgame_us['username'], $rowgame_us['user_colour']);
		$ulhighscore = ($rowgame_us['us_score_game']+0);
		$ulhighdate = $rowgame_us['us_score_date'];
					
		$user_avatars[$rowgame_us['user_id']] = !$display_avatar || !$rowgame_us['user_avatar'] ? '' : phpbb_get_user_avatar(array(
			'avatar'		=> $rowgame_us['user_avatar'],
			'avatar_type'	=> $rowgame_us['user_avatar_type'],
			'avatar_width'	=> $rowgame_us['user_avatar_width'] >= $rowgame_us['user_avatar_height'] ? 40 : 0,
			'avatar_height'	=> $rowgame_us['user_avatar_width'] >= $rowgame_us['user_avatar_height'] ? 0 : 40,
			));

		// Meilleur de score de tous les temps
	
		
		$sql = 'SELECT *
				FROM ' . RA_CAT_TABLE . '
				WHERE ra_cat_id = ' . (int) $arcade_cat_id;
		$result = $this->db->sql_query($sql);
		$arcade_cat_row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$arcade_cat_row)
		{
			trigger_error($this->user->lang('RA_GID_CAT_INC'));
		}

		//
		// Start auth check
		//
		$is_auth = arcade_auth(AUTH_VIEW, $arcade_cat_id);
		if( !$is_auth['ra_cat_auth_view'] )
		{
			trigger_error($this->user->lang('NOT_AUTHORISED'));
		}
		//
		// End auth check
		//


		$this->template->assign_vars(array(
			'L_ARCADE' => $this->user->lang('ARCADE_PAGE'),
			'GAME_NAME_NOLINK' => $row['game_name'],
			'GAME_LIBCHAMPION' => $this->user->lang('GAME_CHAMPION'),
			'GAME_LIBCHAMPION_OF' => $this->user->lang('GAME_CHAMPION_OF'),
			'L_BESTSCORES' => $this->user->lang('BESTSCORES'),
			'AVATAR_CHAMPION_SU' =>($rowgame_us['user_avatar']) ? $user_avatars[$rowgame_us['user_id']] : '<img src="'.generate_board_url() . '/styles/'.$this->user->style['style_path'].'/theme/images/no_avatar.gif" width="40" height="40" alt="' . ((!empty($this->user->lang['USER_AVATAR'])) ? $this->user->lang['USER_AVATAR'] : '') . '" />',        	
			'CHAMPION_UL_SCORE' =>	($ulhighscore== 0) ? $this->user->lang('NO_RECORD') : $ulusernames .'&nbsp;'.$this->user->lang['ARCADE_WITH_SCORE'].'&nbsp;'.$ulhighscore.'&nbsp;'.$this->user->lang['ARCADE_SINCE'].'&nbsp;'.$this->user->format_date($ulhighdate),
			'CHAMP_SCORE' =>	($gamestat_highscore == 0) ? $this->user->lang('NO_MSCORE') : $username .'&nbsp;'.$this->user->lang['ARCADE_WITH_SCORE'].'&nbsp;'.$gamestat_highscore.'&nbsp;'.$this->user->lang['ARCADE_SINCE'].'&nbsp;'. $this->user->format_date($gamestat_highdate),	
			'L_CHAMPION_UL_NAME' => $rowgame_us['username'],
			'AVATAR_CHAMPION' =>($rowtop['user_avatar']) ? $user_avatars[$rowtop['user_id']] : '<img src="'.generate_board_url() . '/styles/'.$this->user->style['style_path'].'/theme/images/no_avatar.gif" width="40" height="40" alt="' . ((!empty($this->user->lang['USER_AVATAR'])) ? $this->user->lang['USER_AVATAR'] : '') . '" />',
			'L_GAME_CHAMPION' => $row['username'],
			'L_GAMENOTE' => $this->user->lang('GAME_CURRENT_NOTE'),
			'MAXSIZE_AVATAR' => $this->config['avatar_maxsize'],
			'CHAMP_DATE' => $this->user->format_date($gamestat_highdate),
		));

		//Liste des meilleurs scores


		$sql_array = array(
			'SELECT'	=> '(count(s2.user_id)+1) as position, s1.*, u.username, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, g.game_name',
			'FROM'		=> array(
				RA_SCORES_TABLE	=> 's1'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's2'),
					'ON'	=> ($highscore_type == 0) ? '(s1.score_game < s2.score_game and s1.game_id = s2.game_id)'
													  : '(s1.score_game > s2.score_game and s1.game_id = s2.game_id)'
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 's1.user_id = u.user_id'
				),
				array(
					'FROM'	=> array(RA_GAMES_TABLE => 'g'),
					'ON'	=> 'g.game_id = s1.game_id'
				)
			),
			'WHERE'		=> 's1.game_id = ' . (int) $gid,
			'GROUP_BY'	=> 's1.user_id',
				'ORDER_BY'	=> 'position ASC, s1.score_date ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$score_rowset = array();
		$gamename = '';
		$total_score = 0;

		while( false !== ($row = $this->db->sql_fetchrow($result)))
		{
			$score_rowset[] = $row;
			$gamename = $row['game_name'] ;
			$total_score++;
		}
		$this->db->sql_freeresult($result);

		$this->template->assign_vars(array(
			'L_POS' => $this->user->lang('BOARDRANK'),
			'L_SCORE' => $this->user->lang('BOARDSCORE'),
			'L_SCORE_FPS' => $this->user->lang('BOARDSCOREFPS'),
			'L_DATE' => $this->user->lang('BOARDDATE'),
			'L_USER' => $this->user->lang('BOARDPLAYER'),
			'L_COMMENTS' => $this->user->lang('COMMENTS'),
			'L_POINTS' => $this->user->lang('BOARDPLAYERPOINT'),
			'GAME_NAME' => '<a class="nav" href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $gid)) . '">' . $gamename . '</a>',
			'U_GAMESCORE_RATE' => $this->helper->route('teamrelax_relaxarcade_page_gamescores', array('gid' => $gid)),
		));

		$uid = $bitfield = $options = '';
		$allowed_bbcode = $allowed_smilies = $allowed_urls = true;
		// Tableau des scores du jeu
		if ($total_score > 0)
		{
			for($i = 0; $i < $total_score; $i++)
			{
					$username = get_username_string('full', $score_rowset[$i]['user_id'], $score_rowset[$i]['username'], $score_rowset[$i]['user_colour']);

				$this->template->assign_block_vars('scorerow', array(
					'POS' => $score_rowset[$i]['position'],
					'SCORE' => $score_rowset[$i]['score_game'] + 0,
					'SCORE_FPS' => $score_rowset[$i]['score_fps'] == 0 ? '-' : $score_rowset[$i]['score_fps'],
					'PLAYER' => $username,
					'POINTS' => $score_rowset[$i]['score_points'],
					'COMMENTS' => $score_rowset[$i]['score_comment'],
					'DATE' => $this->user->format_date($score_rowset[$i]['score_date']))
				);
			}
		}



		

			return $this->helper->render('arcade_viewscoresbody.html', $this->user->lang('PAGE_SCOREGAME'));
	}
}
