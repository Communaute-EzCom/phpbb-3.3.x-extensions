<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class arcade_defis_game
{
	/** @var config */
	protected $config;
	
	/** @var helper */
	protected $helper;	

	/** @var db_interface */
	protected $db;

	/** @var request_interface */
	protected $request;
	
	/** @var template */
	protected $template;

	/** @var user */
	protected $user;
	
	protected $auth;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var string */
	protected $ext_path;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		\phpbb\auth\auth $auth,
		$root_path,
		$php_ext
	)
	{
		$this->config 		= $config;
		$this->helper 		= $helper;
		$this->db 			= $db;
		$this->request 		= $request;
		$this->template 	= $template;		
		$this->user 		= $user;
		$this->auth 				= $auth;
		$this->root_path 	= $root_path;
		$this->php_ext 		= $php_ext;
	}

	public function handle()
	{

			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		
			include($this->root_path . 'includes/message_parser.' . $this->php_ext);
			$ra_img = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme/images/arms.png';
			$name 			= $this->request->variable('name', '', true);
			$userdefis 			= $this->request->variable('u', '', true);
			$gid   	=  $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $this->request->variable('gid', '', true)));
			$submit 		= $this->request->is_set_post('post');
			$sujet 			= utf8_normalize_nfc(sprintf($this->user->lang['DEFIS'],$userdefis,$name));
			$message 		= '[img]' . $ra_img . '[/img]' ."\n\n". '[list][b]' . $this->user->lang['PLAYNAMEDEFI'] . '[/b][URL='.$gid.']' . $name . '[/URL][/list]' ."\n\n".'[list]' . sprintf($this->user->lang['DEMANDEDEFIS'],$userdefis, $name) . ''. utf8_normalize_nfc( $this->request->variable('message', '', true))  .'[/list]';

			$forum_id = $this->config['radefis_forum_id']; 	

					
			add_form_key('posting');
				$this->template->assign_vars(array(
					'S_POST_ACTION' 	=> append_sid("{$this->root_path}posting.".$this->php_ext, 'mode=post&f=' . $forum_id),
					'SUJET' 			=> $sujet,
					'SUJETS' 			=> $name,
					'PLAYUSERSNAME' 			=> $userdefis,
					'DEMANDEDEFIS' 			=> $message));
		
					$defis_data = array(
						'user'		=> $this->user->data['user_id'],
						'users'		=> $this->request->variable('ui', '', true),
						'gid'		=> $this->request->variable('gid', '', true),
						'actif'		=> 0,
						'actif_index'		=>0,
						'timestart'		=>time(),
						
						);
						
						$sql = 'INSERT INTO ' . RA_DEFIS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $defis_data);
						$this->db->sql_query($sql);
			
				if ($submit)
				{
					
					$message_parser = new \parse_message();
					
					// check form
					if (!check_form_key('posting'))
					{
						$error[] = $this->user->lang['FORM_INVALID'];
					}	
					

					$message_parser->message = $message;

					
						// variables to hold the parameters for submit_post
						$poll = $uid = $bitfield = $options = '';
						
						generate_text_for_storage($message, $uid, $bitfield, $options, true, true, true);

						$data = array(
							'forum_id'			=> $forum_id,
							'icon_id'			=> false,
							'enable_bbcode'		=> true,
							'enable_smilies'	=> true,
							'enable_urls'		=> true,
							'enable_sig'		=> (!$this->config['allow_sig']) ? false : true,
							'message'			=> $message,
							'message_md5'		=> md5($message),
							'attachment_data'	=> 0,
							'bbcode_bitfield'	=> $bitfield,
							'bbcode_uid'		=> $uid,
							'post_edit_locked'	=> 0,
							'topic_title'		=> $sujet,
							'notify_set'		=> false,
							'notify'			=> true,
							'forum_name'		=> '',
							'enable_indexing'	=> true,
						);
					
						submit_post('post', $sujet, '', POST_NORMAL, $poll, $data);
				}
			
						
				
				page_header('', false);

				$this->template->set_filenames(array(
			   'body' => 'arcade_defis_body.html',
				));

				page_footer();

	}
	
}	
?>