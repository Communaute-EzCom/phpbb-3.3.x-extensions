<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class arcade_users_defis
{
	/** @var config */
	protected $config;
	
	/** @var helper */
	protected $helper;	

	/** @var db_interface */
	protected $db;

	/** @var request_interface */
	protected $request;
	
	/** @var template */
	protected $template;
	
	/** @var pagination */
	protected $pagination;

	/** @var user */
	protected $user;
	
	protected $auth;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var string */
	protected $ext_path;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\pagination $pagination,
		\phpbb\user $user,
		\phpbb\auth\auth $auth,
		$root_path,
		$php_ext
	)
	{
		$this->config 		= $config;
		$this->helper 		= $helper;
		$this->db 			= $db;
		$this->request 		= $request;
		$this->template 	= $template;
		$this->pagination	= $pagination;
		$this->user 		= $user;
		$this->auth 				= $auth;
		$this->root_path 	= $root_path;
		$this->php_ext 		= $php_ext;
	}

	public function handle()
	{

			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
			$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';

			// logged users
			if (!$this->user->data['is_registered'])
			{
				if ($this->user->data['is_bot'])
				{
					redirect(append_sid("{$this->root_path}index.$this->php_ext"));
				}

				login_box('', $this->user->lang['LOGIN_INFO']);
			}


			$start	= $this->request->variable('start', 0);	
			
			$uname = array();
			$sql = 'SELECT user_id, username, user_colour, group_id	
			FROM ' . USERS_TABLE;
			$result = $this->db->sql_query($sql);
			while( $row = $this->db->sql_fetchrow($result))
			{
				$uname[$row['user_id']] = get_username_string('full', $row['user_id'], $row['username'], $row['user_colour'], $row['group_id']);
			}
			
		
			$sql_array = array(
				'SELECT'	=> 'd.*, g.* ',
						
				'FROM'		=> array(
					RA_DEFIS_TABLE	=> 'd'
				),
				'LEFT_JOIN'	=> array(

				array(
					'FROM'	=> array(RA_GAMES_TABLE => 'g'),
					'ON'	=> 'g.game_id = d.gid'
				)
			),

				'WHERE'		=> 'd.actif = 0 and d.timeend NOT IN ( d.timeend >= '.time() . ')',
				'ORDER_BY' => 'd.id DESC'
			);
						
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query_limit($sql,20, $start);
			while( $row = $this->db->sql_fetchrow($result) )
			{	
				if( $row['game_html5'] == 0 || ! $row['game_html5']){
				$info = '<img src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
				}elseif( $row['game_html5'] == 1){
				$info = '<img src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
				}else{
				$info = '';
				}
	
				$is_first = (($row['game_scoretype'] == 0) && ($row['user_score'] > $row['users_score']))	|| (($row['game_scoretype'] == 1) && ($row['user_score'] < $row['users_score'])) ? $row['user_score'] : $row['users_score'];
				
				$users_first = (($row['game_scoretype'] == 0) && ($row['user_score'] > $row['users_score']))	|| (($row['game_scoretype'] == 1) && ($row['user_score'] < $row['users_score'])) ? $row['user'] : $row['users'];
		
				$is_first_egaux = ($row['user_score'] == $row['users_score']);
				
		
		
		
				$this->template->assign_block_vars('defiwin', array(
					'DEFIS_WIN' =>$is_first_egaux ?  sprintf($this->user->lang['DEFIS_WIN_EGAUX'],$uname[$row['user']],$uname[$row['users']],$is_first ) : sprintf($this->user->lang['DEFIS_WIN'],$uname[$users_first],$is_first )  ,
					'ID' =>$row['id'],
					'GAME_NAME' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '">' . stripslashes($row['game_name']) . '</a>',
					'INFO' => $info,
					'DATE_END' => $this->user->format_date($row['timeend']),
					'USER' => $uname[$row['user']],
					'USERS' =>$uname[$row['users']],
					'USER_SCORE' => $row['user_score'],
					'USERS_SCORE' =>$row['users_score'],
					'GID' => $row['game_name'], 
			
					));			
			}
	
				$sql = 'SELECT COUNT(d.id) AS total_defis
				FROM (' . RA_DEFIS_TABLE. ' d)
				WHERE d.timeend NOT IN ( d.timeend >= '.time() . ')
				ORDER BY id';
				$result = $this->db->sql_query($sql);
				$totaldefis = (int) $this->db->sql_fetchfield('total_defis');
				$this->db->sql_freeresult($result);
				$total_defi  = ($totaldefis) ? $totaldefis : 1;
				$pagination_url = $this->helper->route('teamrelax_relaxarcade_page_usersdefis');
				
			$this->template->assign_vars( array(
				'PAGINATION'		=> $this->pagination->generate_template_pagination($pagination_url, 'pagination', 'start', $total_defi, 20, $start),
				'S_ON_PAGE'			=>$this->pagination->get_on_page($total_defi, 20, $start),
				'TOTAL_DEFIS'			=>$total_defi,
				'L_TOTALDEFIS'			=>($total_defi > 1) ? $this->user->lang['TOTALDEFIS'] : $this->user->lang['TOTALDEFI']

			));

				
				// Build navigation links
				$this->template->assign_block_vars('navlinks', array(
					'FORUM_NAME'		=> $this->user->lang('ARCADE_PAGE'),
					'U_VIEW_FORUM'	=> $this->helper->route('teamrelax_relaxarcade_page_list'),
				));
				$this->template->assign_block_vars('navlinks', array(
					'FORUM_NAME'		=> $this->user->lang('RA_DEFI_GAGNE'),
					'U_VIEW_FORUM'	=> $this->helper->route('teamrelax_relaxarcade_page_usersdefis'),
				));
				
				
				page_header($this->user->lang('RA_DEFI_GAGNE'));

				$this->template->set_filenames(array(
			   'body' => 'arcade_users_defis_body.html',
				));

				page_footer();

	}
	
}	
?>