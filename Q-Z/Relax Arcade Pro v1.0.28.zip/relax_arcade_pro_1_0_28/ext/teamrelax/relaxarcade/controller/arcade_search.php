<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class arcade_search
{
	/** @var user */
	protected $user;

	/** @var config */
	protected $config;

	/** @var request_interface */
	protected $request;

	/** @var db_interface */
	protected $db;

	/** @var template */
	protected $template;

	/** @var pagination */
	protected $pagination;

	/** @var helper */
	protected $helper;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var string */
	protected $ext_path;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\pagination $pagination,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->user = $user;
		$this->config = $config;
		$this->request = $request;
		$this->db = $db;
		$this->template = $template;
		$this->pagination = $pagination;
		$this->helper = $helper;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function handle()
	{
		$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

		include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		include($ext_path . 'arcade/includes/functions_arcade.' . $this->php_ext);
		include($ext_path . 'arcade/includes/arcade_auth.' . $this->php_ext);

		

		// Arcade ferm� ?
		// Acc�s fondateur quand m�me autoris�
		if ($this->config['arcade_close'] && $this->user->data['user_type'] != USER_FOUNDER)
		{
			$message = $this->user->lang('INFO_ARCADE_CLOSE') . '<br /><br />' . $this->user->lang('CLICK_RETURN_INDEX', '<a href="' . append_sid('index.' . $this->php_ext) . '">', '</a>');
			trigger_error($message);
		}

		$min_char = 3;
		$games_per_page = $this->config['games_per_page'];
		$start = $this->request->variable('start', 0);
		$mot_clef = $this->request->variable('recherche', '', true);
		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';

		$sql = 'SELECT *
				FROM ' . RA_CAT_TABLE . '
				ORDER BY ra_cat_order';
		$result = $this->db->sql_query($sql);

		$liste_cat = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$nbcat = count($liste_cat);

		if ($nbcat == 0)
		{
			trigger_error('RA_NO_CAT');
		}

		$is_auth_ary = arcade_auth(AUTH_VIEW, AUTH_LIST_ALL, $liste_cat);
		$j = 0;
		$liste_cat_auth = array();
		$total_games = $arcade_cid = $nbcat_auth = 0;
		for ($i = 0; $i < $nbcat; $i++)
		{
			$arcade_cid = (int)$liste_cat[$i]['ra_cat_id'];
			if ($is_auth_ary[$arcade_cid]['ra_cat_auth_view'])
			{
				$liste_cat_auth[$j] = $liste_cat[$i];
				$liste_cat_id_auth[$j] = $liste_cat[$i]['ra_cat_id'];
				$j++;
			}
		}
		$nbcat_auth = count($liste_cat_auth);

		// Cr�er une condition sql � partir du tableau liste_cat_auth
		$liste_sql_cat_auth = '';
		$i = 0;
		if ($nbcat_auth > 0)
		{
			$liste_sql_cat_auth = '(';
			for ($i = 0; $i < $nbcat_auth; $i++)
			{
				if ($i == 0)
				{
					$liste_sql_cat_auth .= $liste_cat_auth[$i]['ra_cat_id'];
				} else
				{
					$liste_sql_cat_auth .= ',' . $liste_cat_auth[$i]['ra_cat_id'];
				}
			}
			$liste_sql_cat_auth .= ')';
		}
		unset($liste_cat_auth);

		// On nettoie les caract�res invisibles avant et apr�s le mot clef
		$mot_clef = trim(strtolower($mot_clef));
		if ($mot_clef !== '')
		{
			// On compte les caract�res du mot clef
			$longueur_mot_clef = strlen($mot_clef);
			// si il  y a moins de 3 caracteres on cherche pas..
			if ($longueur_mot_clef < $min_char)
			{
				$this->template->assign_block_vars('trop_court', array(
					'COURT' => $this->user->lang('RECAP_SEARCH_MIN_CHAR', $min_char),
				));
			}
			else
			{
				$sql_where = 'g.ra_cat_id IN ' . $liste_sql_cat_auth . '
					AND (LCASE(g.game_name) ' . $this->db->sql_like_expression($this->db->get_any_char() . $mot_clef . $this->db->get_any_char()) . '
						OR LCASE(g.game_desc) ' . $this->db->sql_like_expression($this->db->get_any_char() . $mot_clef . $this->db->get_any_char()) . ')';

				$sql = 'SELECT COUNT(game_id) AS num_games
					FROM ' . RA_GAMES_TABLE . ' g
					WHERE ' . $sql_where;
				$result = $this->db->sql_query($sql);
				$total_games = (int) $this->db->sql_fetchfield('num_games');
				$this->db->sql_freeresult($result);

			

		$topultime =array();
		// Meilleur de score de tous les temps
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.ra_cat_id, g.us_score_game, g.us_user_id, g.us_score_date, u.username, u.user_id, u.user_colour',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'g.us_user_id = u.user_id'
				)
			),
			'WHERE' => 'g.us_score_game',
			'ORDER_BY'	=> 'g.us_score_date DESC',
		);
		$result = $this->db->sql_query($this->db->sql_build_query('SELECT', $sql_array));	
		while( $row = $this->db->sql_fetchrow($result) )
		{	
			$topultime[$row['game_id']]['us_user_id'] = '(' . get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']).')';
		}
		//Liste des jeux avec catégories
		$sql_array = array(
			'SELECT' => 'c.* , g.* , u.username , u.user_id, u.user_colour , s.score_game , s.score_date , a.gamestat_highscore ,
							a.gamestat_highdate , a.gamestat_set, a.gamestat_rating , a.gamestat_rating_set, r.game_rating_val, b.game_id as fav',
			'FROM' => array(
				RA_GAMES_TABLE => 'g'
			),
			'LEFT_JOIN' => array(
				array(
					'FROM' => array(RA_GAMESTAT_TABLE => 'a'),
					'ON' => 'g.game_id = a.game_id',
				),
				array(
					'FROM' => array(RA_GAME_RATING_TABLE => 'r'),
					'ON' => 'g.game_id = r.game_id AND r.user_id = ' . (int) $this->user->data['user_id'],
				),
				array(
					'FROM' => array(RA_SCORES_TABLE => 's'),
					'ON' => 'g.game_id = s.game_id AND s.user_id = ' . (int) $this->user->data['user_id'],
				),
				array(
					'FROM' => array(RA_BOOKMARKS_TABLE => 'b'),
					'ON' => 'g.game_id = b.game_id AND b.user_id = ' . (int) $this->user->data['user_id'],
				),
				array(
					'FROM' => array(USERS_TABLE => 'u'),
					'ON' => 'a.gamestat_user_id = u.user_id',
				),
				array(
							'FROM' => array(RA_CAT_TABLE => 'c'),
							'ON' => 'g.ra_cat_id = c.ra_cat_id',
						),
			),
			'WHERE' => $sql_where,
			'ORDER_BY' => $order_by,
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, $games_per_page, $start);

		

				while (false !== ($row = $this->db->sql_fetchrow($result)))
				{
					$mot_clef = strtolower($mot_clef);
					if (substr($mot_clef, strlen($mot_clef) - 1, strlen($mot_clef)) == "s")
					{
						$mot_clef = substr($mot_clef, 0, strlen($mot_clef) - 1);
					}
					if ($this->similar($mot_clef, strtolower($row['game_name'])) >= 60 || strstr(strtolower($row['game_desc']), $mot_clef) || strstr(strtolower($row['game_name']), $mot_clef))
					{
						$gamename = $row['game_name'];

						if (is_null($row['gamestat_rating']))
			{
				$gamenote = 0;
			}
			else
			{
				$gamenote = $row['gamestat_rating'];
			}
			if($row['game_cont'] == 0 || !$row['game_cont']){
			$bulle_info = $this->user->lang['CONTROLES_INCONNUS'];
			}elseif($row['game_cont'] == 1){
				$bulle_info = $this->user->lang['CLAVIER_UNIQUEMENT'];
			}elseif($row['game_cont'] == 2){
				$bulle_info = $this->user->lang['SOURIS_UNIQUEMENT'];
			}elseif($row['game_cont'] == 3){
				$bulle_info = $this->user->lang['CLAVIER_SOURIS'];
			}else{
				$bulle_info = '';
			}

			if($row['game_html5'] == 0 || !$row['game_html5']){
			$info = '<img src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
			}elseif($row['game_html5'] == 1){
			$info = '<img src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
			}else{
			$info = '';
			}
			
		
			$username =  ($row['gamestat_highscore']== 0) ?  '' : '(' . get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']).')';
			
			$bookmark_href = $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark', 'cid' => $arcade_catid, 'start' => $start, 'gid' => $row['game_id']));
			$this->template->assign_block_vars('reponse', array(
				'GAMENAME' => $gamename,
				'GAMEPIC' => $row['game_pic'] != '' ? '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '"><img  class="imggrrelax"  src="' . generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_swf']) . '/pics/' . $row['game_pic'] . '" width="80px" height="60px" alt="' . $gamename . '" title="' . $gamename . '" /></a>' : '',
				'GAMESET' => $row['gamestat_set'] != 0 ? $this->user->lang('GAME_NBSET') . ' : ' . $row['gamestat_set'] : '',
				'GAMEDESC' => $row['game_desc'],
				'GAME_TYPE'	=>$info,
				'ULHIGHSCORE' =>($row['us_score_game']== 0) ? $this->user->lang('NO_RECORD') : $row['us_score_game'] + 0,
				'ULHIGHUSER' => ($row['us_user_id'] != 0) ?  $topultime[$row['game_id']]['us_user_id']  : '',
				'ULDATEHIGH' => ($row['us_score_game']== 0) ? '' :  date("d/m/Y H:i",$row['us_score_date']).'<br />'.'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_gamescores', array('gid' => $row['game_id'])) . '">' . $this->user->lang('SEE_SCORES') . '</a>',
		 		
				'GAMECONT' => '<img src="' . generate_board_url() . '/arcade/pics_controle/' . $row['game_cont'] . '.png" title="' . $bulle_info . '" alt="' . $bulle_info . '" />',
				'HIGHSCORE' =>($row['gamestat_highscore']== 0) ? $this->user->lang('NO_MSCORE') : $row['gamestat_highscore'] + 0,
				'YOURHIGHSCORE' =>($row['score_game']== 0) ? '<br/>'.$this->user->lang('NO_SCORE') : ($row['user_id'] == $this->user->data['user_id'] ? '<img src="' . $ra_theme_basepath . '/images/couronne.png" alt="first" /><br/>' : '') . ($row['score_game'] + 0),
				'GAMENOTE' => $gamenote == 0 ? $this->user->lang('NO_GAME_NOTE') : $gamenote + 0 . '/10', 'GAMERATING' => $gamenote * 10,
				'L_GAME_NBVOTE' => $gamenote == 0 ? '' : (($row['gamestat_rating_set'] > 1) ? $this->user->lang('GAMENBVOTES') . ']' : $this->user->lang('GAMEVOTE') . ']'),
				'GAME_NBVOTE' => $gamenote == 0 ? '' : '[' . $row['gamestat_rating_set'],
				'HIGHUSER' => ($row['user_id'] != 0) ?   $username  : '',
				'GAMEID' => $row['game_id'], 'GAMEFPS' => ($row['game_fps'] != 0) ? $this->user->lang('GAME_FPS') . ' : ' . $row['game_fps'] : '',
				'GAMESIZE' => ($row['game_size'] != 0) ? $this->user->lang('GAME_SIZE') . ' : ' . size_hum_read($row['game_size']) : '',
				'DATEHIGH' => ($row['gamestat_highscore']== 0) ? '' : date("d/m/Y H:i",$row['gamestat_highdate']).'<br />'.'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_gamescores', array('gid' => $row['game_id'])) . '">' . $this->user->lang('SEE_SCORES') . '</a>',
				'YOURDATEHIGH' => ($row['score_date'] == 0) ? '' : date("d/m/Y H:i",$row['score_date']),
				'IMGRATING' => !is_null($row['game_rating_val']) ? '<img src="' . $ra_theme_basepath . '/images/arcade_rating_check.png" title="' . $this->user->lang('GAME_YOUR_NOTE') . ' : ' . $row['game_rating_val'] . '" alt="' . $this->user->lang('GAME_YOUR_NOTE') . ' : ' . $row['game_rating_val'] . '" />' : '',
				'IMGBOOKMARK' => is_null($row['fav']) ? '<a href="' . $bookmark_href . '"><img src="' . $ra_theme_basepath . '/images/ra_favoris.png" title="' . $this->user->lang('RA_FAV_ADD_GAME') . '" alt="' . $this->user->lang('RA_FAV_ADD_GAME') . '" /></a>' : '<a href="' . $bookmark_href . '"><img src="' . $ra_theme_basepath . '/images/ra_fav_del.png" title="' . $this->user->lang('RA_FAV_DEL_GAME') . '" alt="' . $this->user->lang('RA_FAV_DEL_GAME') . '" /></a>',
				'GAMELINK' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '">' . $row['game_name'] . '</a>',
				
			));
					}
				}
				$this->db->sql_freeresult($result);
			}
		}

		
		$this->template->assign_vars(array(
			'IS_RELAX' =>true,
			'IS_RELAXINDEX' =>false,
			'U_RELAXARCADE' => $this->helper->route('teamrelax_relaxarcade_page_list'),
			'L_ARCADE' => $this->user->lang('ARCADE_PAGE'),
			'TOTAL_GAMES' => $total_games,
			'PAGE_NUMBER' 	=> ($total_games > 0) ? $this->pagination->get_on_page($total_games, $games_per_page, $start): '', 
			'PAGINATION' 	=> ($total_games > 0) ? $this->pagination->generate_template_pagination($this->helper->route('teamrelax_relaxarcade_page_search', array('recherche' => $mot_clef)), 'pagination', 'start', $total_games, $games_per_page, $start, true): '', 
			'L_CAT' => $this->user->lang('RA_CAT'),
			'L_GAME' => $this->user->lang('GAMES'),
			'L_DESC' => $this->user->lang('DESC_GAME'),
			'U_SEARCH_GAMES' => $this->helper->route('teamrelax_relaxarcade_page_search'),
			'RECAP_SEARCH_GAMES' => $total_games <= 1 ? $this->user->lang('RECAP_SEARCH_GAME', $total_games, $mot_clef) : $this->user->lang('RECAP_SEARCH_GAMES', $total_games, $mot_clef),
		));

		return $this->helper->render('arcade_search_body.html', $this->user->lang('ARCADE_PAGE'));
	}

	function similar($str1, $str2)
	{
		$porcentage = 0;
		$strlen1 = strlen($str1);
		$strlen2 = strlen($str2);
		$max = max($strlen1, $strlen2);
		$splitSize = 250;
		if ($max > $splitSize)
		{
			$lev = 0;
			for ($cont = 0; $cont < $max; $cont += $splitSize)
			{
				if ($strlen1 <= $cont || $strlen2 <= $cont)
				{
					$lev = $lev / ($max / min($strlen1, $strlen2));
					break;
				}
				$lev += levenshtein(substr($str1, $cont, $splitSize), substr($str2, $cont, $splitSize));
			}
		}
		else
		{
			$lev = levenshtein($str1, $str2);
			$porcentage = -100 * $lev / $max + 100;
			if ($porcentage > 75)//Ajustar con similar_text
			{
				similar_text($str1, $str2, $porcentage);
			}
		}
		return $porcentage;
	}
}
