<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class arcade_topplayers_category
{
	/** @var user */
	protected $user;

	/** @var config */
	protected $config;

	/** @var request_interface */
	protected $request;

	/** @var db_interface */
	protected $db;

	/** @var template */
	protected $template;

	/** @var helper */
	protected $helper;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var string */
	protected $ext_path;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->user = $user;
		$this->config = $config;
		$this->request = $request;
		$this->db = $db;
		$this->template = $template;
		$this->helper = $helper;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function handle()
	{
		$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

		include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		include($ext_path . 'arcade/includes/functions_arcade.' . $this->php_ext);
		include($ext_path . 'arcade/includes/arcade_auth.' . $this->php_ext);

		

		if ($this->user->data['user_id'] == ANONYMOUS)
		{
			login_box('', $this->user->lang('LOGIN_EXPLAIN_RATOPPLAYERS'));
		}

		$total_games = $total_parts = $played_total_times = 0;
		$prev_place_topvict = $prev_nbvictprec = 0;
		$limit = $this->config['topjoueurcat'];
		$older_champion = $username = '';
		$nbultimeprec = $place_topultime = $pages_ultime = $numultime = 0;
		$older_champion = '';

		// Arcade fermé ?
		if ($this->config['arcade_close'] && $this->user->data['user_type'] != USER_FOUNDER)
		{
			$message = $this->user->lang('INFO_ARCADE_CLOSE') . '<br /><br />' . $this->user->lang('CLICK_RETURN_INDEX', '<a href="' . append_sid("index." . $this->php_ext) . '">', '</a> ');
			trigger_error($message);
		}

		//Param category
		$ra_cat_id = $this->request->variable('cid', 0);
		if (!$ra_cat_id)
		{
		   trigger_error($this->user->lang('RA_NO_CID'));
		}

		$sql = 'SELECT ra_cat_class, ra_cat_title
				FROM ' . RA_CAT_TABLE . '
				WHERE ra_cat_id = ' . $ra_cat_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if ($row['ra_cat_class'] == 0)
		{
			trigger_error($this->user->lang('RA_NO_CAT_CLASS'));
		}

		$start = $this->request->variable('start', 0);
		$place_topvict = $this->request->variable('place_topvict', 0);

		if ($this->request->is_set('nbvictprec'))
		{
			$nbvictprec = $this->request->variable('nbvictprec' , 0);
			$topvict_nav = true;
		}
		else
		{
			$nbvictprec = 0;
			$topvict_nav = false;
		}
		
		$place_topultime = $this->request->variable('place_topultime' , 0);

		if($this->request->is_set('nbultimeprec'))
		{
			$nbultimeprec = $this->request->variable('nbultimeprec' , 0);
			$topultime_nav = true;
		}
		else
		{
			$nbultimeprec = 0;
			$topultime_nav = false;
		}

		$place_toppoints = $this->request->variable('place_toppoints', 0);

		if ($this->request->is_set('nbpointsprec'))
		{
			$nbpointsprec = $this->request->variable('nbpointsprec' , 0);
			$toppoints_nav = true;
		}
		else
		{
			$nbpointsprec = 0;
			$toppoints_nav = false;
		}

		$placetemp = $this->request->variable('placetemp', 0);
		$placetemp2 = $this->request->variable('placetemp2', 0);
		$placetemp3 = $this->request->variable('placetemp3', 0);
		
		// Build navigation links
		$this->template->assign_block_vars('navlinks', array(
			'FORUM_NAME'		=> $this->user->lang('ARCADE_PAGE'),
			'U_VIEW_FORUM'	=> $this->helper->route('teamrelax_relaxarcade_page_list'),
		));

		$this->template->assign_block_vars('navlinks', array(
			'FORUM_NAME'		=> $this->user->lang('ARCADE_TOPPLAYER').'&nbsp; '. $this->user->lang('RA_CATEGORIES'),
			'U_VIEW_FORUM'	=> $this->helper->route('teamrelax_relaxarcade_page_topplayers_category', array('cid' => $ra_cat_id)),
		));
		
		$this->template->assign_block_vars('navlinks', array(
			'FORUM_NAME'		=>$row['ra_cat_title'],
			'U_VIEW_FORUM'	=> $this->helper->route('teamrelax_relaxarcade_page_list', array('cid' => $ra_cat_id)),
		));

		if ($topvict_nav)
		{
			$template_filename = 'arcade_topvictories.html';
		}
		else if ($toppoints_nav)
		{
			$template_filename = 'arcade_toppoints.html';
		}
		else if ($topultime_nav)
		{
			$template_filename =  'arcade_topultime.html';
		}
		else
		{
			$template_filename = 'arcade_topplayers_category.html';
		}

		$sql = 'SELECT user_id
			FROM ' . RA_BOOKMARKS_TABLE . '
			WHERE user_id = ' . (int)$this->user->data['user_id'];
			$result = $this->db->sql_query($sql);
			$favories = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);		
			
		$this->template->assign_vars(array(
			'U_RELAXARCADE' => $this->helper->route('teamrelax_relaxarcade_page_list'),
			'L_TOP_PLAYERS' => $this->user->lang('ARCADE_TOP_PLAYERS') . ' ' . $this->user->lang('RA_CATEGORIES') . ' ' . $row['ra_cat_title'],
			'CAT_TOP_PLAYERS' => true,
			'INDEX_TOP_PLAYERS' =>false,
			'FAV_GAMES' => ($favories) ? true : false,
			'IS_RELAX' =>true,
			'IS_RELAXINDEX' =>false,
			'L_TOP_VICTORIES' => $this->user->lang('ARCADE_TOP_VICTORIES'),
			'L_TOP_POINTS' => $this->user->lang('ARCADE_TOP_POINTS'),
			'L_PLAYER' => $this->user->lang('ARCADE_PLAYER'),
			'L_VICTORIES' => $this->user->lang('ARCADE_VICTORIES'),
			'L_POINTS' => $this->user->lang('ARCADE_POINTS'),
			'L_POSITION' => $this->user->lang('ARCADE_POSITION'),
			'L_BEGIN' => $this->user->lang('ARCADE_BEGIN'),
			'L_NEXT' => $this->user->lang('ARCADE_NEXT'),
			'L_STAT_GLOB' => $this->user->lang('ARCADE_STAT_GLOB'). ' ' . $this->user->lang('RA_CATEGORIES') . ' ' . $row['ra_cat_title'],
			'L_QUANTIFY' => $this->user->lang('ARCADE_QUANTIFY'),
			'L_GAMES_BESTNOTED' => $this->user->lang('ARCADE_GAMES_BESTNOTED'),
			'L_NB_GAMES' => $this->user->lang('ARCADE_NB_GAMES'),
			'L_NB_PARTS' => $this->user->lang('ARCADE_NB_PARTS'),
			'L_PLAYED_TIME' => $this->user->lang('ARCADE_PLAYED_TIME'),
			'L_OLDER_CHAMPION' => $this->user->lang('ARCADE_OLDER_CHAMPION'),
			'L_WITH_SCORE' => $this->user->lang('ARCADE_WITH_SCORE'),
			'L_SINCE' => $this->user->lang('ARCADE_SINCE'),
			'GAME_LIBCHAMPION_OF' => $this->user->lang('GAME_CHAMPION_OF'),
			'ARCADE_INDICATOR' => generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme/images/relaxarcade_indicator.gif',
			'L_BASE_URL' => $this->helper->route('teamrelax_relaxarcade_page_topplayers'),
			'U_RA_PRIZEULTIM' => $this->helper->route('teamrelax_relaxarcade_page_prizeultime'),	
			'U_RA_PRIZE' => $this->helper->route('teamrelax_relaxarcade_page_prize'),
		));

		$sql = 'SELECT *
				FROM ' . RA_CAT_TABLE . '
				ORDER BY ra_cat_order';
		$result = $this->db->sql_query($sql);

		$liste_cat = $this->db->sql_fetchrowset($result);
		$nbcat = count($liste_cat);
		$this->db->sql_freeresult($result);

		if ($nbcat == 0)
		{
			trigger_error($this->user->lang('RA_NO_CAT'));
		}

		//
		// Recherche des catégories visibles pour l'utilisateur
		//
		$is_auth_ary = arcade_auth(AUTH_VIEW, AUTH_LIST_ALL, $liste_cat);
		$liste_cat_auth = array();
		for ($i = 0; $i < $nbcat; $i++)
		{
			$arcade_cid = $liste_cat[$i]['ra_cat_id'];
			if ($is_auth_ary[$arcade_cid]['ra_cat_auth_view'])
			{
				$liste_cat_auth[] = $liste_cat[$i];
			}
		}
		$nbcat_auth = count($liste_cat_auth);
		unset($liste_cat);

		// Créer une condition sql à partir du tableau liste_cat_auth
		$liste_sql_cat_auth = '';
		if ($nbcat_auth > 0)
		{
			$liste_sql_cat_auth = '(';
			for ($i = 0; $i < $nbcat_auth; $i++)
			{
				if ($i == 0)
				{
					$liste_sql_cat_auth .= $liste_cat_auth[$i]['ra_cat_id'];
				}
				else
				{
					$liste_sql_cat_auth .= ',' . $liste_cat_auth[$i]['ra_cat_id'];
				}
			}
			$liste_sql_cat_auth .= ')';
		}
		unset($liste_cat_auth);

		//Nombre total de jeux
		$sql = 'SELECT SUM(ra_cat_nbgames) as total_games
				FROM ' . RA_CAT_TABLE .'
				WHERE  ra_cat_id = ' . $ra_cat_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		if ($row)
		{
			if (!is_null($row['total_games']))
			{
				$total_games = $row['total_games'];
			}
		}
		$this->db->sql_freeresult($result);

		//Nombre total de parties jouées
		$sql = 'SELECT SUM(a.gamestat_set) as total_parts
		FROM ' . RA_GAMESTAT_TABLE . ' a,	' . RA_GAMES_TABLE . ' g
		WHERE a.game_id = g.game_id AND  g.ra_cat_id = '. $ra_cat_id;
		$result = $this->db->sql_query($sql);		
		$row = $this->db->sql_fetchrow($result);
		if ($row)
		{
			if (!is_null($row['total_parts']))
			{
				$total_parts = $row['total_parts'];
			}
		}
		$this->db->sql_freeresult($result);

		//Temps total de parties jouées
		$sql = 'SELECT SUM(s.score_time) as played_total_times
			FROM ' . RA_SCORES_TABLE . ' s,	' . RA_GAMES_TABLE . ' g
			WHERE s.game_id = g.game_id AND  g.ra_cat_id = '. $ra_cat_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		if ($row)
		{
			if (!is_null($row['played_total_times']))
			{
				$played_total_times = arcade_time($row['played_total_times']);
			}
		}
		$this->db->sql_freeresult($result);

		//Champion le plus ancien à un jeu
		$sql_array = array(
			'SELECT'	=> 'u.username, u.user_id, u.user_colour, gs.gamestat_highdate, g.game_name, gs.gamestat_highscore',
			'FROM'		=> array(
				RA_GAMESTAT_TABLE	=> 'gs',
				RA_GAMES_TABLE		=> 'g',
				USERS_TABLE			=> 'u'
			),
			'WHERE'		=> 'gs.game_id = g.game_id
							AND gs.gamestat_user_id = u.user_id AND g.ra_cat_id = '. $ra_cat_id,
			'ORDER_BY'	=> 'gs.gamestat_highdate ASC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 1, 0);
		$row = $this->db->sql_fetchrow($result);
		if ($row)
		{
			if (!is_null($row['username']))
			{
				$older_champion = get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']);
			}
		}
		$this->db->sql_freeresult($result);

		$this->template->assign_block_vars('arcade_quantify', array(
			'TOTAL_GAMES' => $total_games,
			'TOTAL_PARTS' => $total_parts,
			'PLAYED_TIME' => $played_total_times,
			'OLDER_CHAMPION' => $older_champion,
			'GAME_NAME' => $row['game_name'],
			'CHAMP_SCORE' => $row['gamestat_highscore'],
			'CHAMP_DATE' => $this->user->format_date($row['gamestat_highdate']),
		));

		// Top 5 des jeux les mieux notés
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.game_name, g.game_pic, gs.gamestat_rating, gs.gamestat_rating_set',
			'FROM'		=> array(
				RA_GAMESTAT_TABLE	=> 'gs'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_GAMES_TABLE => 'g'),
					'ON'	=> 'gs.game_id = g.game_id'
				)
			),
			'WHERE'		=> 'gs.gamestat_rating > 0
							AND g.ra_cat_id IN ' . $liste_sql_cat_auth . 'AND g.ra_cat_id = '. $ra_cat_id,
			'ORDER_BY'	=> 'gs.gamestat_rating DESC, gs.gamestat_rating_set DESC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 5, 0);

		while ($row = $this->db->sql_fetchrow($result))
		{
			$this->template->assign_block_vars('games_bestnoted_row', array(
				'GAME' => $row['game_name'],
				'GAMEPIC' => generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_pic']) . '/pics/' . $row['game_pic'],
				'GAMELINK' => $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])),
				'NOTE' => $row['gamestat_rating'].'/10',
				'L_GAME_NBVOTE' => $row['gamestat_rating_set'] > 1 ? $this->user->lang('GAMENBVOTES') : $this->user->lang('GAMEVOTE'),
				'GAME_NBVOTE' => $row['gamestat_rating_set'],
			));
		}
		$this->db->sql_freeresult($result);

		
		
			// Compte du nombre de premières places par joueur (prise en compte des égalités)
		$sql_array = array(
			'SELECT'	=> 'COUNT(s.game_id) AS nbvictories, s.user_id, u.username, u.user_colour',
			'FROM'		=> array(
				RA_SCORES_TABLE		=> 's',
				RA_GAMESTAT_TABLE	=> 'st',
				RA_GAMES_TABLE  => 'g',
				USERS_TABLE			=> 'u'
			),
			'WHERE'		=> 's.game_id = g.game_id AND st.game_id = s.game_id
							AND st.gamestat_highscore = s.score_game
							AND s.user_id = u.user_id AND g.ra_cat_id = ' . $ra_cat_id,
			'GROUP_BY'	=> 's.user_id, u.username',
			'ORDER_BY'	=> 'nbvictories DESC, s.user_id ASC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, $limit, $start);

		$placetemp = $placetemp == 0 ? $place_topvict : $placetemp;
		while ($row = $this->db->sql_fetchrow($result))
		{
			$placetemp++;
			if ($nbvictprec != $row['nbvictories'])
			{
				$place_topvict = $placetemp;
				$nbvictprec = $row['nbvictories'];
			}

			$this->template->assign_block_vars('victories_row', array(
				'CLASSEMENT' => $place_topvict,
				'PLAYER' => get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
				'UID' => $row['user_id'],
				'NBVICTORIES' => $row['nbvictories'],
			));
		}
		$this->db->sql_freeresult($result);

		//Nombre total de joueurs ayant au moins une victoire
		$sql_array = array(
			'SELECT'	=> 'distinct(s.user_id)',
			'FROM'		=> array(
				RA_SCORES_TABLE		=> 's',
				RA_GAMES_TABLE  	=> 'g',
				RA_GAMESTAT_TABLE	=> 'st',
			),
			'WHERE' => 's.game_id = g.game_id AND st.game_id = s.game_id AND st.gamestat_highscore = s.score_game AND g.ra_cat_id = ' . $ra_cat_id,
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);

		$numvictories = $this->db->sql_affectedrows();
		$this->db->sql_freeresult($result);

		// Calcul du nombre total de page du tableau top victoires
		$pages_victories = intval($numvictories/$limit);
		if ($numvictories%$limit) {
			$pages_victories++;
		}
		// Affichage du lien précédent ?
		if ($start>=$limit) {
			$this->template->assign_block_vars('victories_begin', array());
		}

		// Affichage du lien suivant ?
		if (!(($start/$limit) == ($pages_victories - 1)) && $pages_victories != 1)
		{
			// si ce n'est pas la dernière afficher le lien NEXT
			$this->template->assign_block_vars('victories_next', array(
				'START' => $start+$limit,
				'PLACE_TOPVICT' => $place_topvict,
				'NBVICTPREC' => $nbvictprec,
				'PLACETEMP' => $placetemp,
				'PREVTOPVIC' => $prev_place_topvict,
				'PREVNBVICT' => $prev_nbvictprec,
			));
		}
		if ($topvict_nav)
		{
			return $this->helper->render($template_filename);
		}

		
		
		//Compte du nombre de records ultime par joueur
			$sql_array = array(
				'SELECT'	=> 'u.user_id, u.username, u.user_colour, g.us_user_id, COUNT(us_score_game) total_ultime',
				'FROM'		=> array(
					USERS_TABLE		=> 'u',
					RA_GAMES_TABLE	=> 'g',
				),
				'WHERE'		=> 'u.user_id = g.us_user_id AND g.ra_cat_id = ' . $ra_cat_id,
				'GROUP_BY'	=> 'g.us_user_id HAVING total_ultime > 0',
				'ORDER_BY'	=> 'total_ultime DESC'
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query_limit($sql, $limit, $start);

			$placetemp3 = ($placetemp3 == 0) ? $place_topultime : $placetemp3;
			while ( $row = $this->db->sql_fetchrow($result) )
			{
				$placetemp3++;
				if ($nbultimeprec != $row['total_ultime'])
				{
					$place_topultime = $placetemp3;
					$nbultimeprec = $row['total_ultime'];
				}

				$this->template->assign_block_vars('ultime_row', array(
				'CLASSEMENT' => $place_topultime,
				'PLAYER' => get_username_string('full', $row['us_user_id'], $row['username'], $row['user_colour']),
				'UID' => $row['us_user_id'],
				'TOTALULTIME' => $row['total_ultime'],
				));
			}

			$this->db->sql_freeresult($result);

			//Nombre total de joueurs ayant au moins un ultime record
			$sql = 'SELECT distinct(s.us_user_id)
					FROM ' . RA_GAMES_TABLE . ' s  
					WHERE s.us_score_game > 0 AND s.ra_cat_id = ' . $ra_cat_id;
			$result = $this->db->sql_query($sql);
			$numultime = $this->db->sql_affectedrows($result);
			$this->db->sql_freeresult($result);

			// Calcul du nombre total de page du tableau top ultime
			$pages_ultime = intval($numultime/$limit);
			if ($numultime%$limit) 
			{
				$pages_ultime++;
			}
			// Affichage du lien début ?
			if ($start>=$limit) 
			{ 
				$this->template->assign_block_vars('ultime_begin', array());
			}

			// Affichage du lien suivant ?
			if (!(($start/$limit)==($pages_ultime-1)) && $pages_ultime!=1) 
			{
				// si ce n'est pas la dernière afficher le lien NEXT
				$this->template->assign_block_vars('ultime_next', array(
				'START' => $start+$limit,
				'PLACE_TOPULTIME' => $place_topultime,
				'PLACETEMP3' => $placetemp3,
				'NBULTIMEPREC' => $nbultimeprec,
				));
			}

			if ($topultime_nav)
			{
			  return $this->helper->render($template_filename);
			
			}
	
	
	
	//Compte du nombre de points par joueur
		$sql_array = array(
			'SELECT'	=> 'u.user_id, u.username, u.user_colour, SUM(score_points) total_points',
			'FROM'		=> array(
				USERS_TABLE		=> 'u',
				RA_GAMES_TABLE  => 'g',
				RA_SCORES_TABLE	=> 's',
			),
			'WHERE'		=> 'u.user_id = s.user_id AND s.game_id = g.game_id	AND g.ra_cat_id = ' . $ra_cat_id,
			'GROUP_BY'	=> 's.user_id HAVING total_points > 0',
			'ORDER_BY'	=> 'total_points DESC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, $limit, $start);

		$placetemp2 = $placetemp2 == 0 ? $place_toppoints : $placetemp2;
		while ($row = $this->db->sql_fetchrow($result))
		{
			$placetemp2++;
			if ($nbpointsprec != $row['total_points'])
			{
				$place_toppoints = $placetemp2;
				$nbpointsprec = $row['total_points'];
			}

			$this->template->assign_block_vars('points_row', array(
				'CLASSEMENT' => $place_toppoints,
				'PLAYER' => get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
				'TOTALPOINTS' => $row['total_points'],
			));
		}

		$this->db->sql_freeresult($result);

		//Nombre total de joueurs ayant au moins un point
			$sql = 'SELECT distinct(s.user_id)
			FROM ' . RA_SCORES_TABLE . ' s,	' . RA_GAMES_TABLE . ' g
			WHERE s.score_game > 0  AND g.game_id = s.game_id AND g.ra_cat_id = '.$ra_cat_id ;
		$result = $this->db->sql_query($sql);
		$numpoints = $this->db->sql_affectedrows();
		$this->db->sql_freeresult($result);

		// Calcul du nombre total de page du tableau top points
		$pages_points = intval($numpoints/$limit);
		if ($numpoints%$limit)
		{
			$pages_points++;
		}
		// Affichage du lien début ?
		if ($start>=$limit)
		{
			$this->template->assign_block_vars('points_begin', array());
		}

		// Affichage du lien suivant ?
		if (!(($start/$limit)==($pages_points-1)) && $pages_points!=1)
		{
			// si ce n'est pas la dernière afficher le lien NEXT
			$this->template->assign_block_vars('points_next', array(
				'START' => $start+$limit,
				'PLACE_TOPPOINTS' => $place_toppoints,
				'PLACETEMP2' => $placetemp2,
				'NBPOINTSPREC' => $nbpointsprec,
			));
		}
		if ($toppoints_nav)
			{
			  return $this->helper->render($template_filename);
			
			}

	
	
		return $this->helper->render($template_filename, $this->user->lang('ARCADE_TOPPLAYER'));
	}
}
