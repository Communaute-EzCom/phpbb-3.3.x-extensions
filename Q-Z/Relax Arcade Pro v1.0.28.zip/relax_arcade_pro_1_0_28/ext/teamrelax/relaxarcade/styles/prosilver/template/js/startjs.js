
var sagscroller1=new sagscroller({
	id:'newgame',
	mode: 'auto',
	pause: 2000,
	navpanel: {show:true, cancelauto:false},
	animatespeed: 300 //<--no comma following last option
})



var sagscroller2=new sagscroller({
	id:'scoregame',
	mode: 'auto',
	pause: 2000,
	navpanel: {show:true, cancelauto:false},
	animatespeed: 300 //<--no comma following last option
})
var sagscroller3=new sagscroller({
	id:'recordgame',
	mode: 'auto',
	pause: 2000,
	navpanel: {show:true, cancelauto:false},
	animatespeed: 300 //<--no comma following last option
})


var sagscroller4=new sagscroller({
	id:'ultimegame',
	mode: 'auto',
	pause: 2000,
	navpanel: {show:true, cancelauto:false},
	animatespeed: 300 //<--no comma following last option
})


var sagscroller5=new sagscroller({
	id:'newgamest',
	mode: 'auto',
	pause: 2000,
	navpanel: {show:true, cancelauto:false},
	animatespeed: 300 //<--no comma following last option
})



var sagscroller6=new sagscroller({
	id:'scoregamest',
	mode: 'auto',
	pause: 2000,
	navpanel: {show:true, cancelauto:false},
	animatespeed: 300 //<--no comma following last option
})
var sagscroller7=new sagscroller({
	id:'recordgamest',
	mode: 'auto',
	pause: 2000,
	navpanel: {show:true, cancelauto:false},
	animatespeed: 300 //<--no comma following last option
})


var sagscroller8=new sagscroller({
	id:'ultimegamest',
	mode: 'auto',
	pause: 2000,
	navpanel: {show:true, cancelauto:false},
	animatespeed: 300 //<--no comma following last option
})

var sagscroller9=new sagscroller({
	id:'catind',
	mode: 'auto',
	pause: 4000,
	navpanel: {show:true, cancelauto:false},
	animatespeed: 300 //<--no comma following last option
})


/* =============================================================== */


