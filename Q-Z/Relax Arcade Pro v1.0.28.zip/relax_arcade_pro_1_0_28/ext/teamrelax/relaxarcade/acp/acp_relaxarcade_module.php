<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\acp;

class acp_relaxarcade_module
{
	public $u_action;
	public $page_title;
	public $tpl_name;
	public $new_config = array();

	function main($id, $mode)
	{
		global $db, $user, $template, $request, $cache, $phpbb_container;
		global $config, $phpbb_root_path, $phpEx ;

		$ext_path = $phpbb_root_path . 'ext/teamrelax/relaxarcade/';
		include($ext_path . 'arcade/includes/ra_common.' . $phpEx);
		include($ext_path . 'arcade/includes/constants.' . $phpEx);

		$admin_link = $phpbb_container->get('teamrelax.relaxarcade.controller.admin.championnat');
		$admin_defis = $phpbb_container->get('teamrelax.relaxarcade.controller.admin.defis');
		// Make the $u_action url available in the admin controller

		$admin_link->set_page_url($this->u_action);
		$admin_defis->set_page_url($this->u_action);
		
		// Set up general vars
		$action		= $request->variable('action', '');
		$update		= $request->is_set_post('update');
		$cat_id		= $request->variable('c', 0);
		$errors = $game_data = $category_data = array();

		$form_key = 'acp_relaxarcade';
		add_form_key($form_key);

		if ($update && !check_form_key($form_key))
		{
			$update = false;
			$errors[] = $user->lang('FORM_INVALID');
		}

		$this->tpl_name = 'acp_relaxarcade';

		$arcade_cat_auth_levels = array('ALL', 'REG', 'PRIVATE', 'MOD', 'ADMIN');
		$arcade_cat_auth_const = array(AUTH_ALL, AUTH_REG, AUTH_ACL, AUTH_MOD, AUTH_ADMIN);
		$arcade_cat_auth_level_fields = array();

		switch ($mode)
		{
			case 'acp_championnat':
				// Load a template from adm/style for our ACP page
				$this->tpl_name = 'acp_championnat';
				// Set the page title for our ACP page
				$this->page_title = $user->lang['ACP_CHAMPIONNAT_MANAGE'];
				// Load the display lottery in the admin controller
				$admin_link->acp_championnat();
			break;
			case 'acp_defis':
				// Load a template from adm/style for our ACP page
				$this->tpl_name = 'acp_defis';
				// Set the page title for our ACP page
				$this->page_title = $user->lang['ACP_DEFIS_MANAGE'];
				// Load the display lottery in the admin controller
				$admin_defis->acp_defis();
			break;
			case 'settings':
				$display_vars = array(
					'title'	=> 'ACP_RELAXARCADE_SETTINGS',
					'vars'	=> array(
						'legend1'				=> 'ACP_GENRALRELAXARCADE_SETTINGS',
						'arcade_close'			=> array('lang' => 'RA_ARCADE_CLOSE',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true),
						'avatar_maxsize'		=> array('lang' => 'RA_AVATAR_MAXSIZE',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						// 'cheater_submit'		=> array('lang' => 'RA_CHEATER_SUBMIT',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true),
						'game_time_tolerance'	=> array('lang' => 'RA_GAME_TIME_TOLERANCE','validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						'game_fps_tolerance'	=> array('lang' => 'RA_GAME_FPS_TOLERANCE',	'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						'games_order'			=> array('lang' => 'RA_GAMES_ORDER',		'validate' => 'string',	'type' => 'select', 'method' => 'select_games_order', 'explain' => true),
						'games_order_acp'		=> array('lang' => 'RA_GAMES_ORDER_ACP',	'validate' => 'string',	'type' => 'select', 'method' => 'select_games_order', 'explain' => true),
						'posts_needed'			=> array('lang' => 'RA_POSTS_NEEDED',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						'days_limit'			=> array('lang' => 'RA_DAYS_LIMIT',			'validate' => 'int',	'type' => 'text:3:4', 'explain' => true, 'append' => ' ' . $user->lang('DAYS')),
						'ra_allow_privmsg'		=> array('lang' => 'RA_ALLOW_PRIVMSG',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true),
						'games_per_page'		=> array('lang' => 'RA_GAMES_PER_PAGE',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						'games_per_page_acp'	=> array('lang' => 'RA_GAMES_PER_PAGE_ACP',	'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						'nb_cat_per_row'		=> array('lang' => 'RA_NB_CAT_PER_ROW',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						'ra_allow_bookmark'		=> array('lang' => 'RA_ALLOW_BOOKMARK',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true),
						'ra_bookmark_limit'		=> array('lang' => 'RA_BOOKMARK_LIMIT',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						'topjoueurcat'		=> array('lang' => 'RA_NB_TOP_JOUEUR_CAT',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						'topjoueur'		=> array('lang' => 'RA_NB_TOP_JOUEUR',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						'ra_last_installed'		=> array('lang' => 'RA_LAST_INSTALLED',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => false),
						'Styleaffichage'		=> array('lang' => 'RA_STYLEAFFICHAGE',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true),
						'ra_disable_forum_id'		=> array('lang' => 'RA_DISABLE_FORUM_ID',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true),
						'ra_forum_id'		=> array('lang' => 'RA_FORUM_ID',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
					
						
						'legend2'				=> 'ACP_RELAXSCORE_SETTINGS',						
						'active_defilement'		=> array('lang' => 'RA_DEFILEMENT',		'validate' => 'int',	'type' => 'radio:yes_no', 'explain' => true),
						'nb_dernier_scoregames'		=> array('lang' => 'RA_NB_SCORE',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true ),
						'nb_dernier_recordgames'		=> array('lang' => 'RA_NB_RECORD',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true ),
						'nb_dernier_ultimegames'		=> array('lang' => 'RA_NB_RECORD_ULTIME',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true ),
						'nb_dernier_games'		=> array('lang' => 'RA_NB_DERNIER_GAMES',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true ),
						
			
						'legend3'				=> 'ACP_RELAXINDEX_SETTINGS',
						'bloc_two_three'     	=> array('lang' => 'BLOC_TWO_THREE',     'validate' => 'int',	'type' => 'radio:yes_no', 'explain' => true),
						'ra_der_index'			=> array('lang' => 'RA_DER_INDEX',			'validate' => 'int','type' => 'text:3:4', 'explain' => true),
						'ra_top_point'			=> array('lang' => 'RA_TOP_POINT',			'validate' => 'int:0:15','type' => 'number:0:15', 'explain' => true),
						'ra_top_leader'			=> array('lang' => 'RA_TOP_LEADER',			'validate' => 'int:0:15','type' => 'number:0:15', 'explain' => true),
						'ra_voir_cats'		=> array('lang' => 'RA_VOIR_ACP_CATS',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true),
						'ra_voir_nbcats'		=> array('lang' => 'RA_VOIR_NBCATS',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true),
						'ra_voir_poscats'		=> array('lang' => 'RA_VOIR_POS_CATS',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true),
						'enable_lastgames'     	=> array('lang' => 'ENABLE_LASTGAMES',      'validate' => 'bool',   'type' => 'radio:yes_no', 'explain' => true),
						
						'legend4'				=> 'ACP_CHALENGE_SETTINGS',
						'challenge_day'			=>array('lang' => 'RA_GAMES_JOUR',		'validate' => 'int',	'type' => 'text:3:4', 'explain' => true), array('lang' => 'RA_GAMES_JOUR_HELP',		'validate' => 'string',	'type' => 'select', 'method' => 'select_games', 'explain' => true),									
						'active_challenge'		=> array('lang' => 'ACTIVE_CHALLENGE_INDEX',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true),
					
									
						
						
						'legend5'				=> $phpbb_container->has('dmzx.mchat.settings') ?  'ACP_RA_MCHAT_SETTINGS' : 'ACP_AUCUN_RA_MCHAT_SETTINGS',
						'no_score_mchat'		=>$phpbb_container->has('dmzx.mchat.settings') ? array('lang' => 'RA_NO_SCORE_MCHAT',	    'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true) : '',
						'new_record_mchat'		=> $phpbb_container->has('dmzx.mchat.settings') ? array('lang' => 'RA_NEW_RECORD_MCHAT',	'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true): '',
						'record_game_mchat'		=>$phpbb_container->has('dmzx.mchat.settings') ? array('lang' => 'RA_RECORD_MCHAT',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true): '',
						'record_ultime_mchat'	=>$phpbb_container->has('dmzx.mchat.settings') ? array('lang' => 'RA_ULTIME_MCHAT',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true): '',
						'ra_mchat_games'	=>$phpbb_container->has('dmzx.mchat.settings') ? array('lang' => 'RA_MCHAT_GAMES',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true): '',
						'ra_mchat_list'	=>$phpbb_container->has('dmzx.mchat.settings') ? array('lang' => 'RA_MCHAT_LIST',		'validate' => 'bool',	'type' => 'radio:yes_no', 'explain' => true): '',



						
						
							
						
						
						
						
						
					)
				);

				$this->new_config = $config;
				$cfg_array = $request->is_set_post('config') ? $request->variable('config', array('' => ''), true) : $this->new_config;

				// We validate the complete config if whished
				validate_config_vars($display_vars['vars'], $cfg_array, $errors);

				if ($update && !check_form_key($form_key))
				{
					$errors[] = $user->lang('FORM_INVALID');
				}
				// Do not write values if there is an error
				if (sizeof($errors))
				{
					$update = false;
				}

				$template->assign_var('S_RELAXARCADE_SETTINGS', true);

				// We go through the display_vars to make sure no one is trying to set variables he/she is not allowed to...
				foreach ($display_vars['vars'] as $config_name => $null)
				{
					if (!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false)
					{
						continue;
					}

					if ($config_name == 'auth_method')
					{
						continue;
					}

					$this->new_config[$config_name] = $config_value = $cfg_array[$config_name];

					if ($update)
					{
						$ra_active_zero		= $request->variable('ra_active_zero', '');
					// Update values 
						$config->set('ra_active_zero', $ra_active_zero);
						$config->set($config_name, $config_value);
					}
				}

				if ($request->variable('resetra', 0) === 1)
				{
					$sql = 'TRUNCATE ' . RA_SCORES_TABLE;
					$db->sql_query($sql);
					$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . ' SET gamestat_user_id = 0, gamestat_highscore = 0, gamestat_highdate = 0';
					$db->sql_query($sql);
				}
							

				if ($request->variable('resetus', 0) === 1)
				{
					$sql = 'UPDATE ' . RA_GAMES_TABLE . ' SET us_user_id = 0, us_score_game = 0, us_score_date = 0 ';
					$db->sql_query($sql);
				}
				
				if ($request->variable('ra_zeropartie', 0) === 1)
				{
					$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . ' SET gamestat_set = 0';
					$db->sql_query($sql);
				}
				
				if ($request->variable('ra_delcomment', 0) === 1)
				{
					$sql = 'UPDATE ' . RA_SCORES_TABLE . ' SET score_comment = ""';
					$db->sql_query($sql);
				}
			
				
				
				
				

				

				if ($update)
				{
					
					add_log('admin', 'LOG_RELAXARCADE_' . strtoupper($mode));

					trigger_error($user->lang('ARCADE_CONFIG_UPDATED') . adm_back_link($this->u_action));
				}

				$this->page_title = $display_vars['title'];

				$template->assign_vars(array(
					'L_TITLE'			=> $user->lang($display_vars['title']),
					'L_TITLE_EXPLAIN'	=> $user->lang($display_vars['title'] . '_EXPLAIN'),
					'RA_VERSION'		=>$config['ra_version'],
					'RA_ACTIVE_ZERO'		=>$config['ra_active_zero'],
					'RA_CONTRIBUTION' => $config['ra_contribution'],

					'GAME_PURGE_US'		=> $user->lang('GAME_PURGE_US'),
					'GAME_PURGE'		=> $user->lang('GAME_PURGE'),
					'GAME_PURGE_DESCRIP_US'		=> $user->lang('GAME_PURGE_DESCRIP_US'),
					'GAME_PURGE_DESCRIP'		=> $user->lang('GAME_PURGE_DESCRIP'),

					//'S_ERROR'			=> (sizeof($error)) ? true : false,
					//'ERROR_MSG'			=> implode('<br />', $error),

					'U_ACTION'			=> $this->u_action,
				));

				// Output relevant page
				foreach ($display_vars['vars'] as $config_key => $vars)
				{
					if (!is_array($vars) && strpos($config_key, 'legend') === false)
					{
						continue;
					}

					if (strpos($config_key, 'legend') !== false)
					{
						$template->assign_block_vars('options', array(
							'S_LEGEND'		=> true,
							'LEGEND'		=> (isset($user->lang[$vars])) ? $user->lang[$vars] : $vars)
						);

						continue;
					}

					$type = explode(':', $vars['type']);

					$l_explain = '';
					if ($vars['explain'] && isset($vars['lang_explain']))
					{
						$l_explain = isset($user->lang[$vars['lang_explain']]) ? $user->lang($vars['lang_explain']) : $vars['lang_explain'];
					}
					else if ($vars['explain'])
					{
						$l_explain = isset($user->lang[$vars['lang'] . '_EXPLAIN']) ? $user->lang($vars['lang'] . '_EXPLAIN') : '';
					}

					$template->assign_block_vars('options', array(
						'KEY'			=> $config_key,
						'TITLE'			=> isset($user->lang[$vars['lang']]) ? $user->lang($vars['lang']) : $vars['lang'],
						'S_EXPLAIN'		=> $vars['explain'],
						'TITLE_EXPLAIN'	=> $l_explain,
						'CONTENT'		=> build_cfg_template($type, $config_key, $this->new_config, $config_key, $vars),
						)
					);

					unset($display_vars['vars'][$config_key]);
				}

			break;

			case 'manage':

				// Major routines
				if ($update)
				{
					switch ($action)
					{
						case 'edit':
							$category_data = array(
								'ra_cat_id'		=>	$cat_id
							);

						// No break here

						case 'add':
							$category_data += array(
								'ra_cat_title'			=> $request->variable('category_name', '', true),
								'ra_cat_pic'			=> $request->variable('category_pic', '', true),
								'ra_cat_class'			=> $request->variable('category_class', 0),
								'ra_cat_active'			=> $request->variable('category_active', 0),
								'ra_cat_submit'			=> $request->variable('category_submit', 0),
							);

							$errors = $this->update_category_data($category_data);

							$message = ($action == 'add') ? $user->lang('RACAT_CREATED') : $user->lang('RACAT_UPDATED');
							trigger_error($message . adm_back_link($this->u_action));

						break;

					}
				}

				switch ($action)
				{
					case 'move_up':
					case 'move_down':
							$cat_id2	= $request->variable('c2', 0);
							$cat_order  = $request->variable('corder', 0);
							$cat_order2  = $request->variable('corder2', 0);

							$this->ra_move_updown('cat',$cat_id, $cat_id2, $cat_order, $cat_order2);
					break;

					case 'sync':
						$errors = $this->ra_cat_sync($cat_id);
						if (sizeof($errors))
						{
							break;
						}

						trigger_error($user->lang('RACAT_SYNC') . adm_back_link($this->u_action));
						return;

					break;

					case 'add':
					case 'edit':
						// Show form to create/modify a category
						if ($action == 'edit')
						{
							$this->page_title = 'EDIT_CATEGORY';
							$category_data = $this->get_category_info($cat_id);
						}
						else
						{
							$this->page_title = 'CREATE_CATEGORY';

							if (!$update)
							{
								$category_data = array(
									'ra_cat_title'			=> $request->variable('category_name', '', true),
									'ra_cat_pic'			=> '',
									'ra_cat_class'			=> 0,
									'ra_cat_active'			=> 0,
									'ra_cat_submit'			=> 0,
								);
							}
						}

					    //Tableau des images de cat�gories
					    $dir = @opendir($phpbb_root_path . 'arcade/pics_cat');
					    $count = 0;
					    $cat_pics = array();
					    while( $file = @readdir($dir) )
					    {
					    	if( !@is_dir($phpbb_root_path . 'arcade/pics_cat/' . $file))
					    	{
					    		if( preg_match('/(\.gif$|\.png$|\.jpg|\.jpeg)$/is', $file) )
					    		{
					    			$cat_pics[$count] = $file;
					    			$count++;
					    		}
					    	}
					    }
						@closedir($dir);
						$cat_pic_list = '';
						for( $i = 0; $i < $count; $i++ )
						{
							if ($action == 'edit')
							{
								if ($cat_pics[$i] == $category_data['ra_cat_pic'])
								{
								  $cat_pic_list .= '<option value="' . $cat_pics[$i] . '" selected="selected">' . $cat_pics[$i] . '</option>';
								}
								else
								{
								  $cat_pic_list .= '<option value="' . $cat_pics[$i] . '">' . $cat_pics[$i] . '</option>';
								}
							}
							else
							{
								$cat_pic_list .= '<option value="' . $cat_pics[$i] . '">' . $cat_pics[$i] . '</option>';
							}
						}

						$template->assign_vars(array(
							'S_EDIT_CATEGORY'			=> true,
							'S_ERROR'					=> (sizeof($errors)) ? true : false,
							'S_ADD_ACTION'				=> ($action == 'add') ? true : false,

							'U_BACK'					=> $this->u_action,
							'U_EDIT_ACTION'				=> $this->u_action . "&amp;action=$action&amp;c=$cat_id",

							'L_TITLE'					=> $user->lang($this->page_title),
							'L_TITLE_EXPLAIN'			=> $user->lang($this->page_title . '_EXPLAIN'),
							'ERROR_MSG'					=> (sizeof($errors)) ? implode('<br />', $errors) : '',

							'CATEGORY_NAME'				=> $category_data['ra_cat_title'],
							'S_CATEGORY_CLASS'			=> $category_data['ra_cat_class'],
							'S_CATEGORY_ACTIVE'			=> $category_data['ra_cat_active'],
							'S_CATEGORY_PIC'			=> $category_data['ra_cat_pic'],
							'S_CATEGORY_SUBMIT'			=> $category_data['ra_cat_submit'],
				            'S_CATEGORY_PIC_OPTIONS' 	=> $cat_pic_list,
						));
						return;

					break;

					case 'delete':
						if (confirm_box(true))
						{
							$errors = $this->ra_cat_delete($cat_id);
							if (sizeof($errors))
							{
								break;
							}

							trigger_error($user->lang('RACAT_DELETED') . adm_back_link($this->u_action));
						}
						else
						{
							confirm_box(false, $user->lang('CONFIRM_OPERATION'), build_hidden_fields(array(
								'mode'		=> $mode,
								'c'			=> $cat_id,
								'action'	=> 'delete',
							)));
						}

					break;

					case 'game':

					    $start			= $request->variable('start', 0);
					    $gid			= $request->variable('gid', 0);
					    $game_action 	= $request->variable('gaction', '');
					    $game_manage 	= $request->variable('select_valid', '');
					    $game_move		= $request->variable('movegames', '');
						$deletemark 	= $request->is_set_post('delmarked');
						$game_del 	= $request->is_set_post('game_del');
				    	$marked			= $request->variable('mark', array(0));

						if ($deletemark)
						{
							if (confirm_box(true))
							{
								$this->ra_game_delete($cat_id, $marked);
								add_log('admin', 'LOG_GAMES_' . strtoupper($mode));
							}
							else
							{
								confirm_box(false, $user->lang('CONFIRM_OPERATION'), build_hidden_fields(array(
									'c'			=> $cat_id,
									'delmarked'	=> $deletemark,
									'mark'		=> $marked,
									'i'			=> $id,
									'mode'		=> $mode,
									'action'	=> $action))
								);
							}
						}
						
						if ($game_del)
						{
							if (confirm_box(true))
							{
								
								  $nb_games = count($gid);
																//Suppression des repertoires des jeux du ftp
								$sql = 'SELECT game_swf FROM ' . RA_GAMES_TABLE
										. ' WHERE game_id = ' .$gid;
								$result = $db->sql_query($sql);

								while ( false !== ($row = $db->sql_fetchrow($result)) )
								{
									$game_dir = $phpbb_root_path . 'arcade/games/' . nom_sans_ext($row['game_swf']);
									$this->ra_dir_delete($game_dir);
								}
								$db->sql_freeresult($result);


								$sql = 'DELETE FROM ' . RA_GAMESTAT_TABLE .
										' WHERE game_id  = ' .$gid;
								$db->sql_query($sql);

								$sql = 'DELETE FROM ' . RA_SCORES_TABLE .
										' WHERE game_id  = ' .$gid;
								$db->sql_query($sql);

								$sql = 'DELETE FROM ' . RA_GAME_RATING_TABLE . ' WHERE game_id  = ' .$gid;
								$db->sql_query($sql);

								$sql = 'DELETE FROM ' . RA_GAMES_TABLE .
										' WHERE game_id = ' .$gid;
								$db->sql_query($sql);

								$sql = 'UPDATE ' . RA_CAT_TABLE . ' SET ra_cat_nbgames = ra_cat_nbgames - ' . (int)$nb_games .
									   ' WHERE ra_cat_id = ' . (int)$cat_id;
								$db->sql_query($sql);
								$cache->destroy(RA_CAT_TABLE);
								trigger_error($user->lang('RAGAME_DELETED') . adm_back_link($this->u_action . "&amp;action=game&amp;c=$cat_id"));
							}
							else
							{
								confirm_box(false, $user->lang('CONFIRM_OPERATION_DELETED'), build_hidden_fields(array(
										'mode'		=> $mode,
										'gid'		=> $gid,
										'action'	=> 'game',
										'gaction'	=> 'gamedel',
									)));
								
							}
						}

						if ($update)
						{
							switch ($game_action)
							{
								case 'gameedit':
									$game_data = array(
										'game_id'				=>	$gid
									);

								// No break here

								case 'gameadd':
									$game_data += array(
										'game_name'				=> $request->variable('game_name', '', true),
							            'game_desc' 			=> $request->variable('game_desc', '', true),
										'game_cont' 			=> $request->variable('game_cont', 0),
										'game_html5'          	=> $request->variable('game_html5', 0),
							            'game_pic' 				=> $request->variable('game_pic', '', true),
							            'game_swf' 				=> $request->variable('game_swf', '', true),
							            'game_width' 			=> $request->variable('game_width', 0),
							            'game_height' 			=> $request->variable('game_height', 0),
							            'game_scorevar' 		=> $request->variable('game_scorevar', '', true),
							            'game_fps' 				=> $request->variable('game_fps', 0),
							            'game_nbdecimal' 		=> $request->variable('game_nbdecimal', 0),
							            'game_scoretype' 		=> $request->variable('highscore_type', 0),
							            'game_cheat_control'	=> $request->variable('game_cheat_control', 0),
							            'game_bgcolor'			=> $request->variable('game_bgcolor', '', true),
							            'game_size'				=> $request->variable('game_size', 0),
							            'ra_cat_id'				=> $cat_id,
									);

									$errors = $this->update_game_data($game_data);

									$message = ($action == 'add') ? $user->lang('GAME_CREATED') : $user->lang('GAME_UPDATED');
									trigger_error($message . adm_back_link($this->u_action . "&amp;action=game&amp;c=$cat_id"));

								break;

							}
						}
						switch($game_action)
						{
							case 'gameorder':

								    $gid		= $request->variable('gid', 0);
									$gid2		= $request->variable('gid2', 0);
									$gorder		= $request->variable('gorder', 0);
									$gorder2  	= $request->variable('gorder2', 0);

									$this->ra_move_updown('game',$gid, $gid2, $gorder, $gorder2);
							break;

							case 'gamedelete':
								if (confirm_box(true))
								{
									$ary_game = array();
									$ary_game[0] = $gid;
									$errors = $this->ra_game_delete($cat_id, $ary_game);
									if (sizeof($errors))
									{
										break;
									}

									trigger_error($user->lang('RAGAME_DELETED') . adm_back_link($this->u_action));
								}
								else
								{
									confirm_box(false, $user->lang('CONFIRM_OPERATION'), build_hidden_fields(array(
										'mode'		=> $mode,
										'gid'		=> $gid,
										'action'	=> 'game',
										'gaction'	=> 'gamedelete',
									)));
								}
							break;
							
								case 'gamedel':
								if (confirm_box(true))
								{
									$ary_game = array();
									$ary_game[0] = $gid;
									$errors = $this->ra_game_delete($cat_id, $ary_game);
									if (sizeof($errors))
									{
										break;
									}

									trigger_error($user->lang('RAGAME_DELETED') . adm_back_link($this->u_action));
								}
								else
								{
									confirm_box(false, $user->lang('CONFIRM_OPERATION'), build_hidden_fields(array(
										'mode'		=> $mode,
										'gid'		=> $gid,
										'action'	=> 'game',
										'gaction'	=> 'gamedel',
									)));
								}
							break;


							case 'gameedit':
							case 'gameadd':
								// Show form to create/modify a game
								$prev_cat_id = 0;
								if ($game_action == 'gameedit')
								{
									$this->page_title = 'EDIT_GAME';
									$game_data = $this->get_game_info($gid);
							        $prev_cat_id = isset($game_data['ra_cat_id']) ? $game_data['ra_cat_id'] : 0;
								}
								else
								{
									$this->page_title = 'CREATE_GAME';

									if (!$update)
									{
										$game_data = array(
								            'game_name' 			=> $request->variable('game_name', '', true),
								            'game_desc' 			=> '',
											'game_cont'				=> 0,
											'game_html5'            => 0,
								            'game_pic' 				=> '',
								            'game_swf' 				=> '',
								            'game_width' 			=> 550,
								            'game_height' 			=> 400,
								            'game_scorevar' 		=> '',
								            'game_fps' 				=> 0,
								            'game_nbdecimal' 		=> 0,
								            'game_scoretype' 		=> 0,
								            'game_cheat_control'	=> 1,
								            'game_bgcolor'			=> 'FFFFFF',
								            'game_size'				=> 0,
								        );
									}
								}
								$cat_list = $this->get_category_list($cat_id);
								
								$hidden_fields = null;
							    $hidden_fields .= "<input type='hidden' name='gid' value='$gid' />";
							    $hidden_fields .= "<input type='hidden' name='prev_cat_id' value='$prev_cat_id' />";

								$selectcont ='';								
								if($game_data['game_cont'] == 0 || !$game_data['game_cont']){
								$selectcont .= '<option value="0" selected="selected">'.$user->lang['CONTROLES_INCONNUS'].'</option>'."\n";
								}else{
								$selectcont .= '<option value="0">'.$user->lang['CONTROLES_INCONNUS'].'</option>'."\n";
								}
								if($game_data['game_cont'] == 1){
								$selectcont .= '<option value="1" selected="selected">'.$user->lang['CLAVIER_UNIQUEMENT'].'</option>'."\n";
								}else{
								$selectcont .= '<option value="1">'.$user->lang['CLAVIER_UNIQUEMENT'].'</option>'."\n";
								}
								if($game_data['game_cont'] == 2){
								$selectcont .= '<option value="2" selected="selected">'.$user->lang['SOURIS_UNIQUEMENT'].'</option>'."\n";
								}else{
								$selectcont .= '<option value="2">'.$user->lang['SOURIS_UNIQUEMENT'].'</option>'."\n";
								}
								if($game_data['game_cont'] == 3){
								$selectcont .= '<option value="3" selected="selected">'.$user->lang['CLAVIER_SOURIS'].'</option>'."\n";
								}else{
								$selectcont .= '<option value="3">'.$user->lang['CLAVIER_SOURIS'].'</option>'."\n";
								}
								$selectchoix ='';                        
								if($game_data['game_html5'] == 0 || !$game_data['game_html5']){
								$selectchoix .= '<option value="0" selected="selected">'.$user->lang['JEUX_FLASH'].'</option>'."\n";
								}else{
								$selectchoix .= '<option value="0">'.$user->lang['JEUX_FLASH'].'</option>'."\n";
								}
								if($game_data['game_html5'] == 1){
								$selectchoix .= '<option value="1" selected="selected">'.$user->lang['JEUX_HTML5'].'</option>'."\n";
								}else{
								$selectchoix .= '<option value="1">'.$user->lang['JEUX_HTML5'].'</option>'."\n";
								}
							
								
								$template->assign_vars(array(
									'S_EDIT_GAME'				=> true,
									'S_ERROR'					=> (sizeof($errors)) ? true : false,
									'S_ADD_ACTION'				=> ($game_action == 'gameadd') ? true : false,

									'U_BACK'					=> $this->u_action . "&amp;action=game&amp;c=$cat_id",
									'U_EDIT_ACTION'				=> $this->u_action . "&amp;action=$action&amp;gaction=$game_action&amp;c=$cat_id&amp;gid=$gid",

									'L_TITLE'					=> $user->lang($this->page_title),
									'L_TITLE_EXPLAIN'			=> $user->lang($this->page_title . '_EXPLAIN'),
									'ERROR_MSG'					=> (sizeof($errors)) ? implode('<br />', $errors) : '',

								    'L_EDIT_GAME' 				=> $user->lang('EDIT_GAME'),
								    'L_EDIT_GAME_EXPLAIN' 		=> $user->lang('EDIT_GAME_EXPLAIN'),
								    'L_GAME_SETTINGS' 			=> $user->lang('GAME_SETTINGS'),
								    'L_GAME_NAME' 				=> $user->lang('GAME_NAME'),
								    'L_GAME_NAME_EXPLAIN' 		=> $user->lang('GAME_NAME_EXPLAIN'),
								    'L_DESCRIPTION' 			=> $user->lang('GAME_DESCRIPTION'),
								    'L_DESCRIPTION_EXPLAIN' 	=> $user->lang('GAME_DESCRIPTION_EXPLAIN'),
									'L_CONTROLE' 				=> $user->lang['GAME_CONTROLE'],
								    'L_CONTROLE_EXPLAIN' 		=> $user->lang['GAME_CONTROLE_EXPLAIN'],
									'L_TYPEJEU'             	=> $user->lang['GAME_TYPEJEU_EXPLAIN'],
									'L_TYPEJEU_EXPLAIN'       	=> $user->lang['GAME_TYPEJEU_EXPLAIN'],
								    'L_GAME_PIC' 				=> $user->lang('GAME_PIC'),
								    'L_GAME_PIC_EXPLAIN' 		=> $user->lang('GAME_PIC_EXPLAIN'),
								    'L_SWF' 					=> $user->lang('GAME_SWF'),
								    'L_SWF_EXPLAIN' 			=> $user->lang('GAME_SWF_EXPLAIN'),
								    'L_WIDTH' 					=> $user->lang('GAME_WIDTH'),
								    'L_WIDTH_EXPLAIN' 			=> $user->lang('GAME_WIDTH_EXPLAIN'),
								    'L_HEIGHT' 					=> $user->lang('GAME_HEIGHT'),
								    'L_HEIGHT_EXPLAIN' 			=> $user->lang('GAME_HEIGHT_EXPLAIN'),
								    'L_CATEGORY' 				=> $user->lang('GAME_CATEGORY'),
								    'L_CATEGORY_EXPLAIN' 		=> $user->lang('GAME_CATEGORY_EXPLAIN'),
								    'L_GAME_FPS' 				=> $user->lang('GAME_FPS'),
								    'L_GAME_FPS_EXPLAIN' 		=> $user->lang('GAME_FPS_EXPLAIN'),
								    'L_HIGHSCORE_TYPE' 			=> $user->lang('GAME_HSTYPE'),
								    'L_HIGHSCORE_TYPE_EXPLAIN' 	=> $user->lang('GAME_HSTYPE_EXPLAIN'),
								    'L_ASC' 					=> $user->lang('GAME_ASC'),
								    'L_DESC' 					=> $user->lang('GAME_DESC'),
								    'L_CHEAT_CONTROL' 			=> $user->lang('CHEAT_CONTROL'),
								    'L_CHEAT_CONTROL_EXPLAIN' 	=> $user->lang('CHEAT_CONTROL_EXPLAIN'),
								    'L_YES' 					=> $user->lang('YES'),
								    'L_NO' 						=> $user->lang('NO'),
								    'L_SCOREVAR' 				=> $user->lang('GAME_SCOREVAR'),
								    'L_SCOREVAR_EXPLAIN' 		=> $user->lang('GAME_SCOREVAR_EXPLAIN'),
								    'L_GAME_SIZE'				=> $user->lang('GAME_SIZE'),
								    'L_GAME_SIZE_EXPLAIN' 		=> $user->lang('GAME_SIZE_EXPLAIN'),
								    'L_GAME_NBDECIMAL' 			=> $user->lang('GAME_NBDECIMAL'),
								    'L_GAME_NBDECIMAL_EXPLAIN' 	=> $user->lang('GAME_NBDECIMAL_EXPLAIN'),
								    'L_GAME_BGCOLOR' 			=> $user->lang('GAME_BGCOLOR'),
								    'L_GAME_BGCOLOR_EXPLAIN' 	=> $user->lang('GAME_BGCOLOR_EXPLAIN'),
									
									'GAME_NAME' 				=> $game_data['game_name'],
									'GAME_DESC'		 			=> $game_data['game_desc'],
									'CONTSELECT'				=> $selectcont,
									'GAME_CONTROLE_EXPLAIN'		=> $user->lang('GAME_CONTROLE_EXPLAIN'),
									'CHOIXTYPE'					=> $selectchoix,
									'GAME_PIC' 					=> $game_data['game_pic'],
									'GAME_SWF' 					=> $game_data['game_swf'],
									'GAME_WIDTH' 				=> $game_data['game_width'],
									'GAME_HEIGHT' 				=> $game_data['game_height'],
									'GAME_SCOREVAR'				=> $game_data['game_scorevar'],
									'GAME_BGCOLOR' 				=> $game_data['game_bgcolor'],
									'GAME_FPS' 					=> $game_data['game_fps'],
									'GAME_SIZE' 				=> $game_data['game_size'],
									'GAME_NBDECIMAL' 			=> $game_data['game_nbdecimal'],
									'HIGHSCORE_TYPE_ASC' 		=> $game_data['game_scoretype'],
									'CHEAT_CONTROL_YES' 		=> $game_data['game_cheat_control'],
								    'S_CATEGORY'				=> $cat_list,
		    						'S_HIDDEN_FIELDS' 			=> $hidden_fields,
								));
								return;
							break;
						}

						if ($game_manage === $user->lang('GO'))
					    {
					    	$selection = $request->variable('selection', '');
					    	$marked		= $request->variable('mark', array(0));
					        switch ($selection)
					        {
					        	case 'resynch_nbparties':
					        		$errors = $this->ra_games_resynch($marked);
									if (sizeof($errors))
									{
										break;
									}

									trigger_error($user->lang('GAME_SYNC') . adm_back_link($this->u_action . "&amp;action=game&amp;c=$cat_id"));
								break;
					        	case 'deletescores':
					        		$errors = $this->ra_scores_delete($marked);
									if (sizeof($errors))
									{
										break;
									}

									trigger_error($user->lang('SCORE_GAME_DELETED') . adm_back_link($this->u_action . "&amp;action=game&amp;c=$cat_id"));
								break;
					        	case 'deletenote':
					        		$errors = $this->ra_note_delete($marked);
									if (sizeof($errors))
									{
										break;
									}

									trigger_error($user->lang('NOTE_GAME_DELETED') . adm_back_link($this->u_action . "&amp;action=game&amp;c=$cat_id"));
								break;
					        	case 'delete_nbparties':
					        		$errors = $this->ra_nbparties_delete($marked);
									if (sizeof($errors))
									{
										break;
									}

									trigger_error($user->lang('NBPARTIES_DELETED') . adm_back_link($this->u_action . "&amp;action=game&amp;c=$cat_id"));
								break;
					        }
						}

						if ($game_move === $user->lang('GO'))
						{
							//New cat
							$new_cat_id = $request->variable('catid', 0);
							//Games selected
							$marked		= $request->variable('mark', array(0));
						    //Move the games
							$this->ra_move_games($cat_id, $new_cat_id, $marked);
						}

						// Setting games for category
						if ($cat_id)
						{
							$this->page_title = 'GAME_MANAGE';
							$game_list = $this->ra_cat_manage($cat_id, $start);
							$nb_games = count($game_list);
							$tot_games = $this->ra_cat_nbgames($cat_id);
							$cat_list = $this->get_category_list($cat_id);
							$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';
						    for( $i = 0 ; $i < $nb_games; $i++)
						    {
								if($game_list[$i]['game_html5'] == 0 || !$game_list[$i]['game_html5']){
								$info = '<img src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$user->lang['JEUX_FLASH'].'" />';
								}elseif($game_list[$i]['game_html5'] == 1){
								$info = '<img src="' . $ra_theme_basepath . '/images/html.png" alt="'.$user->lang['JEUX_HTML5'].'" />';
								}else{
								$info = '';
								}
						    	$template->assign_block_vars('game_row', array(
						    		'GID'			=> $game_list[$i]['game_id'],
						    		'GAME_NAME'		=> $game_list[$i]['game_name'],
						        	'GAME_PIC' 		=> $game_list[$i]['game_pic'] != '' ? '<img src="' . './../arcade/games/' . nom_sans_ext($game_list[$i]['game_pic']) . '/pics/' . $game_list[$i]['game_pic'] . '" title="' . $game_list[$i]['game_name'] . '" alt="' . $game_list[$i]['game_name'] . '"/>' : '',
						    		'NB_PLAY'		=> $game_list[$i]['gamestat_set'],
						    		'NB_SCORES'		=> $game_list[$i]['nbscores'],
									'GAME_TYPE'	=>$info,
						    		'HIGHSCORE'	    => $game_list[$i]['gamestat_highscore'] + 0,
						    		'CHECK'			=> $game_list[$i]['game_id'],
						            'U_MOVE_UP'     => ($i > 0) ? $this->u_action . '&amp;action=game&amp;gaction=gameorder&amp;start='.$start.'&amp;c='.$cat_id.'&amp;gid='.$game_list[ $i ]['game_id'].'&amp;gid2='.$game_list[ $i - 1 ]['game_id'].'&amp;gorder='.$game_list[ $i ]['game_order'].'&amp;gorder2='.$game_list[ $i - 1 ]['game_order'] : '',
						            'U_MOVE_DOWN'   => ($i < ($nb_games - 1)) ? $this->u_action . '&amp;action=game&amp;gaction=gameorder&amp;start='.$start.'&amp;c='.$cat_id.'&amp;gid='.$game_list[ $i ]['game_id'].'&amp;gid2='.$game_list[ $i + 1 ]['game_id'].'&amp;gorder='.$game_list[ $i ]['game_order'].'&amp;gorder2='.$game_list[ $i + 1 ]['game_order'] : '',
						    		'U_EDIT'		=> $this->u_action . '&amp;action=game&amp;gaction=gameedit&amp;c='.$cat_id.'&amp;gid=' . $game_list[$i]['game_id'],
									'U_DELETE'		=> $this->u_action . '&amp;action=game&amp;gaction=gamedelete&amp;c='.$cat_id.'&amp;gid=' . $game_list[$i]['game_id'],
						    	));
						    }
						    unset($game_list);

							$pagination = $phpbb_container->get('pagination');
							$pagination->generate_template_pagination($this->u_action . '&amp;c='.$cat_id.'&amp;action=game', 'pagination', 'start', $tot_games, $config['games_per_page_acp'], $start, true);

							$template->assign_vars(array(
								'S_GAME_MANAGE'		=> true,
								'S_ERROR'			=> (sizeof($errors)) ? true : false,
								'S_ADD_ACTION'		=> ($action == 'add') ? true : false,
								'S_CAT_LIST'		=> $cat_list,

								'U_BACK'			=> $this->u_action,

								'L_TITLE'			=> $user->lang($this->page_title),
								'L_TITLE_EXPLAIN'	=> $user->lang($this->page_title . '_EXPLAIN'),
								'L_GAME_NAME'		=> $user->lang('RA_GAME'),
								'L_HIGHSCORE'		=> $user->lang('RA_HIGHSCORE'),
								'L_NBPARTY'			=> $user->lang('RA_SETS'),
								'L_NBSCORES'		=> $user->lang('RA_SCORES'),
								'ERROR_MSG'			=> (sizeof($errors)) ? implode('<br />', $errors) : '',
							));
						}
						return;

					break;
				}

				$display_vars = array(
					'title'	=> 'ACP_CATEGORY_MANAGE',
					'vars'	=> array(
						'legend1'				=> 'ACP_CATEGORY_MANAGE',
					)
				);

				if (isset($display_vars['lang']))
				{
					$user->add_lang($display_vars['lang']);
				}

				$this->page_title = $display_vars['title'];
				$template->assign_var('S_CATEGORY_MANAGE', true);
				$template->assign_vars(array(
					'L_TITLE'			=> $user->lang($display_vars['title']),
					'L_TITLE_EXPLAIN'	=> $user->lang($display_vars['title'] . '_EXPLAIN'),
					'L_CATEGORY'		=> $user->lang('CATEGORY'),
					'L_CAT_IMAGE'		=> $user->lang('CAT_IMAGE'),
					'L_NBGAMES'			=> $user->lang('NBGAMES'),

					'S_ERROR'			=> (sizeof($errors)) ? true : false,
					'ERROR_MSG'			=> implode('<br />', $errors),

					'U_ACTION'			=> $this->u_action,
				));

				$sql = 'SELECT ra_cat_id, ra_cat_title, ra_cat_order, ra_cat_nbgames, ra_cat_pic, ra_cat_class,ra_cat_active,ra_cat_submit
					FROM ' . RA_CAT_TABLE . '
					ORDER BY ra_cat_order';
				$result = $db->sql_query($sql);

				$category_rows = $db->sql_fetchrowset($result);
				$total_category = sizeof($category_rows);
				$db->sql_freeresult($result);

				for($i = 0; $i < $total_category; $i++)
				{
					$cid = $category_rows[$i]['ra_cat_id'];
					$corder = $category_rows[$i]['ra_cat_order'];
					$url = $this->u_action . "&amp;c={$category_rows[$i]['ra_cat_id']}";
					$template->assign_block_vars('category', array(
						'CAT_ID' 			=> $category_rows[$i]['ra_cat_id'],
						'CAT_TITLE'			=> $category_rows[$i]['ra_cat_title'],
						'CAT_CLASS'			=> $category_rows[$i]['ra_cat_class'],
						'RACAT_CLASS'			=> ($category_rows[$i]['ra_cat_class'] == true ) ? $user->lang('YES') : $user->lang('NO'),
						'RACAT_ACTIVE'			=> ($category_rows[$i]['ra_cat_active']== true ) ? $user->lang('YES') : $user->lang('NO'),
						'RACAT_SUBMIT'			=> ($category_rows[$i]['ra_cat_submit']== true ) ? $user->lang('YES') : $user->lang('NO'),
						'CAT_IMAGE'			=> ($category_rows[$i]['ra_cat_pic']) ? '<img src="' . $phpbb_root_path . 'arcade/pics_cat/' . $category_rows[$i]['ra_cat_pic'] . '" alt="" />' : '',
				        'NUM_GAMES' 		=> $category_rows[$i]['ra_cat_nbgames'],
						'U_CAT_MANAGE'		=> $this->u_action . '&amp;c=' . $category_rows[$i]['ra_cat_id'] . '&amp;action=game',
				        'U_MOVE_UP' 		=> ($i > 0) ? $this->u_action . '&amp;action=move_up&amp;c='.$cid.'&amp;c2='.$category_rows[$i-1]['ra_cat_id'].'&amp;corder='.$corder.'&amp;corder2='.$category_rows[$i-1]['ra_cat_order'] : '',
						'U_MOVE_DOWN' 		=> ($i < ($total_category - 1)) ? $this->u_action . '&amp;action=move_down&amp;c='.$cid.'&amp;c2='.$category_rows[$i+1]['ra_cat_id'].'&amp;corder='.$corder.'&amp;corder2='.$category_rows[$i+1]['ra_cat_order'] : '',
						'U_EDIT'			=> $url . '&amp;action=edit',
						'U_DELETE'			=> $url . '&amp;action=delete',
						'U_SYNC'			=> $url . '&amp;action=sync')
					);
				}
				unset($category_rows);

			break;

			case 'setting_category':
				/* code from phpBB2 */

				$this->page_title = 'AUTH_CONTROL_RA_CAT';
				$template->assign_var('S_AUTH_RA', true);
				$template->assign_vars(array(
					'L_TITLE'			=> $user->lang($this->page_title),
					'L_TITLE_EXPLAIN'	=> $user->lang($this->page_title . '_EXPLAIN'),

					'S_ERROR'			=> (sizeof($errors)) ? true : false,
					'ERROR_MSG'			=> implode('<br />', $errors),

					'U_ACTION'			=> $this->u_action)
				);

				//
				// Define vars
				//
				//                View      Play     Submit     Vote
				$simple_auth_ary = array(
					0  => array(AUTH_ALL, AUTH_ALL, AUTH_ALL, AUTH_ALL),
					1  => array(AUTH_ALL, AUTH_REG, AUTH_REG, AUTH_REG),
					2  => array(AUTH_REG, AUTH_REG, AUTH_REG, AUTH_REG),
					3  => array(AUTH_ALL, AUTH_ACL, AUTH_ACL, AUTH_ACL),
					4  => array(AUTH_ACL, AUTH_ACL, AUTH_ACL, AUTH_ACL),
					5  => array(AUTH_ALL, AUTH_MOD, AUTH_MOD, AUTH_MOD),
					6  => array(AUTH_MOD, AUTH_MOD, AUTH_MOD, AUTH_MOD),
				);

				$simple_auth_types = array($user->lang('PUBLIC'), $user->lang('REGISTERED'), $user->lang('REGISTERED') . ' [' . $user->lang('HIDDEN') . ']', $user->lang('PRIVATE'), $user->lang('PRIVATE') . ' [' . $user->lang('HIDDEN') . ']', $user->lang('MODERATORS'), $user->lang('MODERATORS') . ' [' . $user->lang('HIDDEN') . ']');

				$arcade_cat_auth_fields = array('ra_cat_auth_view', 'ra_cat_auth_play', 'ra_cat_auth_submit', 'ra_cat_auth_vote');

				$field_names = array(
					'ra_cat_auth_view' => $user->lang('VIEW'),
					'ra_cat_auth_play' => $user->lang('PLAY'),
					'ra_cat_auth_submit' => $user->lang('SUBMIT_SCORE'),
					'ra_cat_auth_vote' => $user->lang('VOTE'),
				);

				if ($request->is_set('c'))
				{
					$cat_id = $request->variable('c', 0);
					$arcade_cat_sql = ' WHERE ra_cat_id = ' . (int) $cat_id;
				}
				else
				{
					$cat_id = 0;
					$arcade_cat_sql = '';
				}

				if ($request->is_set('adv'))
				{
					$adv = $request->variable('adv', 0);
				}
				else
				{
					unset($adv);
				}

				if ($update)
				{
					$sql = '';

					if ($cat_id)
					{
						if ($request->is_set_post('simpleauth'))
						{
							$simple_ary = $simple_auth_ary[$request->variable('simpleauth', 0)];

							for($i = 0; $i < count($simple_ary); $i++)
							{
								$sql .= ( ( $sql != '' ) ? ', ' : '' ) . $arcade_cat_auth_fields[$i] . ' = ' . $simple_ary[$i];
							}

							if (is_array($simple_ary))
							{
								$sql = 'UPDATE ' . RA_CAT_TABLE . "
									SET $sql
									WHERE ra_cat_id = " . (int) $cat_id;
							}
						}
						else
						{
							for($i = 0; $i < count($arcade_cat_auth_fields); $i++)
							{
								$value = $request->variable($arcade_cat_auth_fields[$i], 0);

								$sql .= ( ( $sql != '' ) ? ', ' : '' ) .$arcade_cat_auth_fields[$i] . ' = ' . $value;
							}

							$sql = 'UPDATE ' . RA_CAT_TABLE . "
									SET $sql
									WHERE ra_cat_id = " . (int)$cat_id;
						}

						if ( $sql != '' )
						{
							$db->sql_query($sql);
							$cache->destroy(RA_CAT_TABLE);
						}

						$arcade_cat_sql = '';
						$adv = 0;
					}
					trigger_error($user->lang('ARCADE_CAT_AUTH_UPDATED') . adm_back_link($this->u_action));
				} // End of submit

				//
				// Get required information, either all forums if
				// no id was specified or just the requsted if it
				// was
				//
				$sql = 'SELECT *
					FROM ' . RA_CAT_TABLE .
					$arcade_cat_sql . '
					ORDER BY ra_cat_order ASC';
				$result = $db->sql_query($sql);
				$arcade_cat_rows = $db->sql_fetchrowset($result);
				$db->sql_freeresult($result);

				if( empty($cat_id) )
				{
					//
					// Output the selection table if no forum id was
					// specified
					//

					$select_list = '<select name="c">';
					for($i = 0; $i < count($arcade_cat_rows); $i++)
					{
						$select_list .= '<option value="' . $arcade_cat_rows[$i]['ra_cat_id'] . '">' . $arcade_cat_rows[$i]['ra_cat_title'] . '</option>';
					}
					$select_list .= '</select>';

					$template->assign_vars(array(
						'S_AUTH_RA_SELECT'			=> true,
						'L_AUTH_ARCADE_TITLE' 		=> $user->lang('AUTH_CONTROL_RA_CAT'),
						'L_AUTH_ARCADE_EXPLAIN' 	=> $user->lang('AUTH_CONTROL_RA_CAT_EXPLAIN'),
						'L_AUTH_ARCADE_SELECT' 		=> $user->lang('SELECT_A_CATEGORY'),

						'S_AUTH_ARCADE_ACTION' 		=> append_sid("admin_arcade_cat_auth.$phpEx"),
						'S_AUTH_ARCADE_SELECT' 		=> $select_list,
					));

				}
				else
				{
					//
					// Output the authorisation details if an id was
					// specified
					//
				/*	$template->set_filenames(array(
						'body' => 'admin/auth_arcade_cat_body.tpl')
					);*/

					$matched = 0;
					$matched_type = null;
					$arcade_cat_name = $arcade_cat_rows[0]['ra_cat_title'];

					@reset($simple_auth_ary);
					while( list($key, $auth_levels) = each($simple_auth_ary))
					{
						$matched = 1;
						for($k = 0; $k < count($auth_levels); $k++)
						{
							$matched_type = $key;

							if ( $arcade_cat_rows[0][$arcade_cat_auth_fields[$k]] != $auth_levels[$k] )
							{
								$matched = 0;
							}
						}

						if ( $matched )
						{
							break;
						}
					}

					//
					// If we didn't get a match above then we
					// automatically switch into 'advanced' mode
					//
					if ( !isset($adv) && !$matched )
					{
						$adv = 1;
					}

					$s_column_span = 0;

					if ( empty($adv) )
					{
						$simple_auth = '<select name="simpleauth">';

						for($j = 0; $j < count($simple_auth_types); $j++)
						{
							$selected = ( $matched_type == $j ) ? ' selected="selected"' : '';
							$simple_auth .= '<option value="' . $j . '"' . $selected . '>' . $simple_auth_types[$j] . '</option>';
						}

						$simple_auth .= '</select>';

						$template->assign_block_vars('arcade_cat_auth_titles', array(
							'CELL_TITLE' => $user->lang('SIMPLE_MODE'))
						);
						$template->assign_block_vars('arcade_cat_auth_data', array(
							'S_AUTH_LEVELS_SELECT' => $simple_auth)
						);

						$s_column_span++;
					}
					else
					{
						//
						// Output values of individual
						// fields
						//
						for($j = 0; $j < count($arcade_cat_auth_fields); $j++)
						{
							$custom_auth[$j] = '&nbsp;<select name="' . $arcade_cat_auth_fields[$j] . '">';

							for($k = 0; $k < count($arcade_cat_auth_levels); $k++)
							{
								$selected = ( $arcade_cat_rows[0][$arcade_cat_auth_fields[$j]] == $arcade_cat_auth_const[$k] ) ? ' selected="selected"' : '';
								$custom_auth[$j] .= '<option value="' . $arcade_cat_auth_const[$k] . '"' . $selected . '>' . $user->lang('ARCADE_CAT_' . $arcade_cat_auth_levels[$k]) . '</option>';
							}
							$custom_auth[$j] .= '</select>&nbsp;';

							$cell_title = $field_names[$arcade_cat_auth_fields[$j]];

							$template->assign_block_vars('arcade_cat_auth_titles', array(
								'CELL_TITLE' => $cell_title)
							);
							$template->assign_block_vars('arcade_cat_auth_data', array(
								'S_AUTH_LEVELS_SELECT' => $custom_auth[$j])
							);

							$s_column_span++;
						}
					}

					$adv_mode = ( empty($adv) ) ? '1' : '0';
					$switch_mode = $this->u_action . '&amp;c=' . $cat_id . '&amp;adv='. $adv_mode;
					$switch_mode_text = ( empty($adv) ) ? $user->lang('ADVANCED_MODE') : $user->lang('SIMPLE_MODE');
					$u_switch_mode = '<a href="' . $switch_mode . '">' . $switch_mode_text . '</a>';

					$s_hidden_fields = '<input type="hidden" name="c" value="' . $cat_id . '">';

					$template->assign_vars(array(
						'S_AUTH_RA'			=> true,
						'ARCADE_CAT_NAME' => $arcade_cat_name,

						'L_ARCADE_CAT' => $user->lang('ARCADE_CAT'),

						'U_SWITCH_MODE' => $u_switch_mode,

						'S_ARCADE_CAT_AUTH_ACTION' => $this->u_action,
						'S_COLUMN_SPAN' => $s_column_span,
						'S_HIDDEN_FIELDS' => $s_hidden_fields,
					));

				}

			break;

			case 'setting_groups':
				$group_id = $request->variable('g', 0);
				$adv = $request->variable('adv', 0);
				// $sgmode = $request->variable('smode', '');
				$select_list = null;

				$this->page_title = 'GROUP_PERMISSIONS';
				$template->assign_vars(array(
					'L_TITLE'			=> $user->lang($this->page_title),
					'L_TITLE_EXPLAIN'	=> $user->lang($this->page_title . '_EXPLAIN'),

					'S_ERROR'			=> (sizeof($errors)) ? true : false,
					'ERROR_MSG'			=> implode('<br />', $errors),

					'U_ACTION'			=> $this->u_action)
				);

				//
				// Start program - define vars
				//
				$arcade_cat_auth_fields = array('ra_cat_auth_view', 'ra_cat_auth_play', 'ra_cat_auth_submit', 'ra_cat_auth_vote');

				$field_names = array(
					'ra_cat_auth_view' => $user->lang('VIEW'),
					'ra_cat_auth_play' => $user->lang('PLAY'),
					'ra_cat_auth_submit' => $user->lang('SUBMIT_SCORE'),
					'ra_cat_auth_vote' => $user->lang('VOTE'),
				);

				if ( $update &&  $group_id )
				{
					//
					// Carry out requests
					//

					if (!$adv)
					{
						$change_acl_list = $request->variable('private', array('' => ''), true);
					}
					else
					{
						$change_acl_list = array();
						for($j = 0; $j < count($arcade_cat_auth_fields); $j++)
						{
							$auth_field = $arcade_cat_auth_fields[$j];

							$private_auth_field = $request->variable('private_' . $auth_field, array('' => ''));
							while (list($arcade_cat_id, $value) = @each($private_auth_field))
							{
								$change_acl_list[$arcade_cat_id][$auth_field] = $value;
							}
						}
					}

					$sql = 'SELECT *
						FROM ' . RA_CAT_TABLE . '
						ORDER BY ra_cat_order';
					$result = $db->sql_query($sql);

					$arcade_cat_access = array();
					while( $row = $db->sql_fetchrow($result) )
					{
						$arcade_cat_access[] = $row;
					}
					$db->sql_freeresult($result);

					$sql = 'SELECT *
						FROM ' . RA_AUTH_ACCESS_TABLE . '
						WHERE group_id = ' . (int)$group_id;
					$result = $db->sql_query($sql);

					$auth_access = array();
					while( $row = $db->sql_fetchrow($result) )
					{
						$auth_access[$row['ra_cat_id']] = $row;
					}
					$db->sql_freeresult($result);

					$arcade_cat_auth_action = array();
					$update_acl_status = array();

					$nb_arcade_cat_access = sizeof($arcade_cat_access);
					for($i = 0; $i < $nb_arcade_cat_access; $i++)
					{
						$arcade_cat_id = $arcade_cat_access[$i]['ra_cat_id'];
						$arcade_cat_auth_action[$arcade_cat_id] = '';

						for($j = 0; $j < count($arcade_cat_auth_fields); $j++)
						{
							$auth_field = $arcade_cat_auth_fields[$j];

							if( $arcade_cat_access[$i][$auth_field] == AUTH_ACL && isset($change_acl_list[$arcade_cat_id][$auth_field]) )
							{
								if
								(
									( isset($auth_access[$arcade_cat_id][$auth_field]) && $change_acl_list[$arcade_cat_id][$auth_field] != $auth_access[$arcade_cat_id][$auth_field] ) ||
									( !isset($auth_access[$arcade_cat_id][$auth_field]) && !empty($change_acl_list[$arcade_cat_id][$auth_field]) )
								)
								{
									$update_acl_status[$arcade_cat_id][$auth_field] = $change_acl_list[$arcade_cat_id][$auth_field];

									if ( isset($auth_access[$arcade_cat_id][$auth_field]) && empty($update_acl_status[$arcade_cat_id][$auth_field]) && $arcade_cat_auth_action[$arcade_cat_id] != 'insert' && $arcade_cat_auth_action[$arcade_cat_id] != 'update' )
									{
										$arcade_cat_auth_action[$arcade_cat_id] = 'delete';
									}
									else if ( !isset($auth_access[$arcade_cat_id][$auth_field]) && !( $arcade_cat_auth_action[$arcade_cat_id] == 'delete' && empty($update_acl_status[$arcade_cat_id][$auth_field]) ) )
									{
										$arcade_cat_auth_action[$arcade_cat_id] = 'insert';
									}
									else if ( isset($auth_access[$arcade_cat_id][$auth_field]) && !empty($update_acl_status[$arcade_cat_id][$auth_field]) )
									{
										$arcade_cat_auth_action[$arcade_cat_id] = 'update';
									}
								}
								else if ( (
									( isset($auth_access[$arcade_cat_id][$auth_field]) && $change_acl_list[$arcade_cat_id][$auth_field] == $auth_access[$arcade_cat_id][$auth_field] ) ) && $arcade_cat_auth_action[$arcade_cat_id] == 'delete' )
								{
									$arcade_cat_auth_action[$arcade_cat_id] = 'update';
								}
							}
						}
					}

					//
					// Checks complete, make updates to DB
					//
					$delete_sql = '';
					while( list($arcade_cat_id, $action) = @each($arcade_cat_auth_action) )
					{
						switch ($action)
						{
							case 'delete':
								$delete_sql .= ( ( $delete_sql != '' ) ? ', ' : '' ) . $arcade_cat_id;
							break;
							case 'insert':
								$sql_field = '';
								$sql_value = '';
								while ( list($auth_type, $value) = @each($update_acl_status[$arcade_cat_id]) )
								{
									$sql_field .= ( ( $sql_field != '' ) ? ', ' : '' ) . $auth_type;
									$sql_value .= ( ( $sql_value != '' ) ? ', ' : '' ) . $value;
								}

								$sql = 'INSERT INTO ' . RA_AUTH_ACCESS_TABLE . " (ra_cat_id, group_id, $sql_field)
									VALUES (" . (int)$arcade_cat_id . ',' . (int)$group_id . ',' . $db->sql_escape($sql_value). ')';
								$db->sql_query($sql);
							break;
							case 'update':
								$sql_values = '';
								while ( list($auth_type, $value) = @each($update_acl_status[$arcade_cat_id]) )
								{
									$sql_values .= ( ( $sql_values != '' ) ? ', ' : '' ) . $auth_type . ' = ' . $value;
								}

								$sql = 'UPDATE ' . RA_AUTH_ACCESS_TABLE . "
									SET $sql_values
									WHERE group_id = " . (int)$group_id . '
										AND ra_cat_id = ' . (int)$arcade_cat_id;
								$db->sql_query($sql);
							break;

						}
					}

					if ( $delete_sql != '' )
					{
						$sql = 'DELETE FROM ' . RA_AUTH_ACCESS_TABLE . '
							WHERE group_id = ' . (int)$group_id . '
								AND ra_cat_id IN (' . $db->sql_escape($delete_sql) . ')';
						$db->sql_query($sql);
					}

					trigger_error($user->lang('AUTH_UPDATED') . adm_back_link($this->u_action));

					//message_die(GENERAL_MESSAGE, $message);
				}
				else if ( $group_id )
				{
					//
					// Front end
					//
					$sql = 'SELECT *
						FROM ' . RA_CAT_TABLE . '
						ORDER BY ra_cat_order ASC';
					$result = $db->sql_query($sql);

					$arcade_cat_access = array();
					while( $row = $db->sql_fetchrow($result) )
					{
						$arcade_cat_access[] = $row;
					}
					$db->sql_freeresult($result);

					if( empty($adv) )
					{
						for($i = 0; $i < count($arcade_cat_access); $i++)
						{
							$arcade_cat_id = $arcade_cat_access[$i]['ra_cat_id'];

							$arcade_cat_auth_level[$arcade_cat_id] = AUTH_ALL;

							for($j = 0; $j < count($arcade_cat_auth_fields); $j++)
							{
								// $arcade_cat_access[$i][$arcade_cat_auth_fields[$j]] . ' :: ';
								if ( $arcade_cat_access[$i][$arcade_cat_auth_fields[$j]] == AUTH_ACL )
								{
									$arcade_cat_auth_level[$arcade_cat_id] = AUTH_ACL;
									$arcade_cat_auth_level_fields[$arcade_cat_id][] = $arcade_cat_auth_fields[$j];
								}
							}
						}
					}

					$sql_array = array(
						'SELECT'	=> 'u.user_id, u.username, g.group_id, g.group_name, ug.user_pending',
						'FROM'		=> array(
							USERS_TABLE			=> 'u',
							GROUPS_TABLE		=> 'g',
							USER_GROUP_TABLE	=> 'ug'
						),
						'WHERE'		=> 'g.group_id = ' . $group_id . '
										AND ug.group_id = g.group_id
										AND u.user_id = ug.user_id'
					);
					$sql = $db->sql_build_query('SELECT', $sql_array);
					$result = $db->sql_query($sql);
					$ug_info = array();
					while( $row = $db->sql_fetchrow($result) )
					{
						$ug_info[] = $row;
					}
					$db->sql_freeresult($result);

					$sql = 'SELECT *
						FROM ' . RA_AUTH_ACCESS_TABLE . '
						WHERE group_id = ' . (int)$group_id;
					$result = $db->sql_query($sql);

					$auth_access = array();
					$auth_access_count = array();
					while( $row = $db->sql_fetchrow($result) )
					{
						$auth_access[$row['ra_cat_id']][] = $row;
						if (!isset($auth_access_count[$row['ra_cat_id']]))
						{
							$auth_access_count[$row['ra_cat_id']] = 1;
						}
						else
						{
							$auth_access_count[$row['ra_cat_id']]++;
						}
					}
					$db->sql_freeresult($result);

					$is_admin = 0;

					for($i = 0; $i < count($arcade_cat_access); $i++)
					{
						$arcade_cat_id = $arcade_cat_access[$i]['ra_cat_id'];

						unset($prev_acl_setting);
						for($j = 0; $j < count($arcade_cat_auth_fields); $j++)
						{
							$key = $arcade_cat_auth_fields[$j];
							$value = $arcade_cat_access[$i][$key];

							switch( $value )
							{
								case AUTH_ALL:
								case AUTH_REG:
									$auth_ug[$arcade_cat_id][$key] = 1;
									break;

								case AUTH_ACL:
									$auth_ug[$arcade_cat_id][$key] = ( !empty($auth_access_count[$arcade_cat_id]) ) ? $this->ra_check_auth(AUTH_ACL, $key, $auth_access[$arcade_cat_id], $is_admin) : 0;
									$auth_field_acl[$arcade_cat_id][$key] = $auth_ug[$arcade_cat_id][$key];

									if ( isset($prev_acl_setting) )
									{
										if ( $prev_acl_setting != $auth_ug[$arcade_cat_id][$key] && empty($adv) )
										{
											$adv = 1;
										}
									}

									$prev_acl_setting = $auth_ug[$arcade_cat_id][$key];

									break;

								case AUTH_MOD:
									$auth_ug[$arcade_cat_id][$key] = ( !empty($auth_access_count[$arcade_cat_id]) ) ? $this->ra_check_auth(AUTH_MOD, $key, $auth_access[$arcade_cat_id], $is_admin) : 0;
									break;

								case AUTH_ADMIN:
									$auth_ug[$arcade_cat_id][$key] = $is_admin;
									break;

								default:
									$auth_ug[$arcade_cat_id][$key] = 0;
									break;
							}
						}

						//
						// Is user a moderator?
						//
						//$auth_ug[$arcade_cat_id]['auth_mod'] = ( !empty($auth_access_count[$arcade_cat_id]) ) ? ra_check_auth(AUTH_MOD, 'auth_mod', $auth_access[$arcade_cat_id], 0) : 0;
					}

					$i = 0;
					$optionlist_acl = '';
					@reset($auth_ug);
					while( list($arcade_cat_id, $user_ary) = @each($auth_ug) )
					{
						if ( empty($adv) )
						{
							if ( $arcade_cat_auth_levels[$arcade_cat_id] == AUTH_ACL )
							{
								$allowed = 1;

								for($j = 0; $j < count($arcade_cat_auth_level_fields[$arcade_cat_id]); $j++)
								{
									if ( !$auth_ug[$arcade_cat_id][$arcade_cat_auth_level_fields[$arcade_cat_id][$j]] )
									{
										$allowed = 0;
									}
								}

								$optionlist_acl = '<select name="private[' . $arcade_cat_id . ']">';

								if ( $is_admin )
								{
									$optionlist_acl .= '<option value="1">' . $user->lang('ALLOWED_ACCESS') . '</option>';
								}
								else if ( $allowed )
								{
									$optionlist_acl .= '<option value="1" selected="selected">' . $user->lang('ALLOWED_ACCESS') . '</option><option value="0">'. $user->lang('DISALLOWED_ACCESS') . '</option>';
								}
								else
								{
									$optionlist_acl .= '<option value="1">' . $user->lang('ALLOWED_ACCESS') . '</option><option value="0" selected="selected">' . $user->lang('DISALLOWED_ACCESS') . '</option>';
								}

								$optionlist_acl .= '</select>';
							}
							else
							{
								$optionlist_acl = '&nbsp;';
							}
						}
						else
						{
							for($j = 0; $j < count($arcade_cat_access); $j++)
							{
								if ( $arcade_cat_access[$j]['ra_cat_id'] == $arcade_cat_id )
								{
									for($k = 0; $k < count($arcade_cat_auth_fields); $k++)
									{
										$field_name = $arcade_cat_auth_fields[$k];

										if( $arcade_cat_access[$j][$field_name] == AUTH_ACL )
										{
											$optionlist_acl_adv[$arcade_cat_id][$k] = '<select name="private_' . $field_name . '[' . $arcade_cat_id . ']">';

											//if( isset($auth_field_acl[$arcade_cat_id][$field_name]) && !($is_admin || $user_ary['auth_mod']) )
											if( isset($auth_field_acl[$arcade_cat_id][$field_name]) && !($is_admin ))
											{
												if( !$auth_field_acl[$arcade_cat_id][$field_name] )
												{
													$optionlist_acl_adv[$arcade_cat_id][$k] .= '<option value="1">' . $user->lang('YES') . '</option><option value="0" selected="selected">' . $user->lang('NO') . '</option>';
												}
												else
												{
													$optionlist_acl_adv[$arcade_cat_id][$k] .= '<option value="1" selected="selected">' . $user->lang('YES') . '</option><option value="0">' . $user->lang('NO') . '</option>';
												}
											}
											else
											{
												if( $is_admin )
												{
													$optionlist_acl_adv[$arcade_cat_id][$k] .= '<option value="1">' . $user->lang('YES') . '</option>';
												}
												else
												{
													$optionlist_acl_adv[$arcade_cat_id][$k] .= '<option value="1">' . $user->lang('YES') . '</option><option value="0" selected="selected">' . $user->lang('NO') . '</option>';
												}
											}

											$optionlist_acl_adv[$arcade_cat_id][$k] .= '</select>';

										}
									}
								}
							}
						}

						$template->assign_block_vars('arcade_cat', array(
							'ARCADE_CAT_NAME' => $arcade_cat_access[$i]['ra_cat_title'],

							'U_ARCADE_CAT_AUTH' => append_sid("admin_arcade_cat_auth.$phpEx?c=" . $arcade_cat_access[$i]['ra_cat_id']))
						);

						if( !$adv )
						{
							$template->assign_block_vars('arcade_cat.aclvalues', array(
								'S_ACL_SELECT' => $optionlist_acl)
							);
						}
						else
						{
							for($j = 0; $j < count($arcade_cat_auth_fields); $j++)
							{
								if ( isset($optionlist_acl_adv[$arcade_cat_id][$j]) )
								{
									$template->assign_block_vars('arcade_cat.aclvalues', array(
										'S_ACL_SELECT' => $optionlist_acl_adv[$arcade_cat_id][$j])
									);
								}
								else
								{
									$template->assign_block_vars('arcade_cat.aclvalues', array(
										'S_ACL_SELECT' => '')
									);
								}
							}
						}
						$i++;
					}
				//	@reset($auth_user);

					$t_groupname = isset($ug_info[0]['group_name']) ? $ug_info[0]['group_name'] : '';

					$name = array();
					$id = array();
					for($i = 0; $i < count($ug_info); $i++)
					{
						$name[] = $ug_info[$i]['username'];
						$id[] = intval($ug_info[$i]['user_id']);
					}

					$t_usergroup_list = $t_pending_list = '';
					if( count($name) )
					{
						for($i = 0; $i < count($ug_info); $i++)
						{
							// $ug = 'user&amp;u';

							if (!$ug_info[$i]['user_pending'])
							{
            $t_usergroup_list .= ( ( $t_usergroup_list != '' ) ? ', ' : '' ) . '<a href="' . append_sid($phpbb_root_path . "index.$phpEx?i=users&mode=overview&u=" . $id[$i]) . '">' . $name[$i] . '</a>';
							}
							else
							{
            $t_pending_list .= ( ( $t_pending_list != '' ) ? ', ' : '' ) . '<a href="' . append_sid($phpbb_root_path . "index.$phpEx?i=users&mode=overview&u=" . $id[$i]) . '">' . $name[$i] . '</a>';							}
						}
					}

					$t_usergroup_list = ($t_usergroup_list == '') ? $user->lang('NONE') : $t_usergroup_list;
					$t_pending_list = ($t_pending_list == '') ? $user->lang('NONE') : $t_pending_list;

					$s_column_span = 2; // Two columns always present
					if( !$adv )
					{
						$template->assign_block_vars('acltype', array(
							'L_UG_ACL_TYPE' => $user->lang('SIMPLE_PERMISSION'))
						);
						$s_column_span++;
					}
					else
					{
						for($i = 0; $i < count($arcade_cat_auth_fields); $i++)
						{
							$cell_title = $field_names[$arcade_cat_auth_fields[$i]];

							$template->assign_block_vars('acltype', array(
								'L_UG_ACL_TYPE' => $cell_title)
							);
							$s_column_span++;
						}
					}

					//
					// Dump in the page header ...
					//
					$adv_switch = ( empty($adv) ) ? 1 : 0;
					$u_ug_switch = 'g=' . $group_id;
					$switch_mode = $this->u_action . '&amp;' . $u_ug_switch . '&amp;adv=' . $adv_switch;
					$switch_mode_text = ( empty($adv) ) ? $user->lang('ADVANCED_MODE') : $user->lang('SIMPLE_MODE');
					$u_switch_mode = '<a href="' . $switch_mode . '">' . $switch_mode_text . '</a>';


					$s_hidden_fields = '<input type="hidden" name="adv" value="' . $adv . '" />';
					$s_hidden_fields .= '<input type="hidden" name="g" value="' . $group_id . '" />';

					$template->assign_block_vars("switch_group_auth", array());

					$template->assign_vars(array(
						'GROUPNAME' => $t_groupname,
						'GROUP_MEMBERSHIP' => $user->lang('USERGROUP_MEMBERS') . ' : ' . $t_usergroup_list . '<br />' . $user->lang('PENDING_MEMBERS') . ' : ' . $t_pending_list)
					);

					$template->assign_vars(array(
						'S_AUTH_GROUP'	=> true,
						'L_GROUPNAME' => $user->lang('GROUP_NAME'),

						'L_PERMISSIONS' => $user->lang('PERMISSIONS'),
						'L_ARCADE_CAT' => $user->lang('ARCADE_CAT'),

						'U_SWITCH_MODE' => $u_switch_mode,

						'S_COLUMN_SPAN' => $s_column_span,
						'S_HIDDEN_FIELDS' => $s_hidden_fields,
					));
				}
				else
				{
					//
					// Select a group
					//

					$sql = 'SELECT group_id, group_name
						FROM ' . GROUPS_TABLE;
					$result = $db->sql_query($sql);

					if ( $row = $db->sql_fetchrow($result) )
					{
						$select_list = '<select name="g">';
						do
						{
							$select_list .= '<option value = "'.$row['group_id'].'">'.(isset($user->lang[ 'G_'.$row['group_name'] ]) ? $user->lang[ 'G_'.$row['group_name'] ]: $row['group_name']).'</option>';
	
						}
						while ( $row = $db->sql_fetchrow($result) );
						$select_list .= '</select>';
					}

					$template->assign_vars(array(
						'S_AUTH_ARCADE_SELECT' => $select_list,
					));

					$s_hidden_fields = '<input type="hidden" name="mode" value="' . $mode . '" />';

					$template->assign_vars(array(
						'S_AUTH_GROUP_SELECT'	=> true,
						'L_AUTH_ARCADE_TITLE' => $user->lang('AUTH_CONTROL_RA_CAT'),
						'L_AUTH_ARCADE_EXPLAIN' => $user->lang('AUTH_CONTROL_RA_CAT_EXPLAIN'),
						'L_AUTH_ARCADE_SELECT' => $user->lang('SELECT_A_GROUP'),

						'S_HIDDEN_FIELDS' => $s_hidden_fields,
					));
				}

			break;

			case 'install':

				include($ext_path . 'arcade/includes/tar.' . $phpEx);
				$hidden_fields = null;
				$array_games_list = array();
				$path_install = $phpbb_root_path . 'arcade/games_pack';

				$upload_ok = $upload_no = $err_ext = '';

				if ($action == 'upload_games')
				{
					
					$file = $request->file('fichier');
					$nom_fichier = $file['name'];
					$nom_fichier = strtr($nom_fichier, 'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ', 'AAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy');
					$type_fichier = substr(strtolower(strrchr(basename($nom_fichier), '.')), 1);
					$tmp = $file['tmp_name'];

					if ($request->is_set_post('uploaded'))
					{
						if (!empty($nom_fichier))
						{
							if ($type_fichier == 'tar' || $type_fichier == 'rar')
							{
								if (move_uploaded_file($tmp, $path_install . '/' . $nom_fichier))
								{
									$upload_ok = $user->lang('RA_UPLOAD_OK');
								}
								else
								{
									$upload_no = $user->lang('RA_UPLOAD_NO');
								}
							}
							else
							{
								$err_ext = $user->lang('RA_ERR_EXT');
							}
						}
					}
				}

				if ($action == 'install_games')
				{
					if (!$cat_id)
					{
						trigger_error('No category selected');
					}
				    $i=0;
				    $handle = opendir($path_install);

					if ($handle === false)
					{
						echo 'Games folder missing';
						return;
					}

				    while (false !== ($file = readdir($handle)))
				    {
				        $type = (substr($file, -3, 4));
				        if ($file != '.' && $file != '..' && $type=='tar')
				        {
				            $array_games_list[$i]['id'] = $i;
				            $array_games_list[$i]['name'] = $file;
				            $i++;
				        }
				    }
				    closedir($handle);

			    	$marked		= $request->variable('mark', array(0));

					$csc = count($marked);
					$tab_log_install = array();
					if($csc==0)
					{
						trigger_error($user->lang('ARCADE_NO_SEL_ROW'));
					}
					for($i = 0; $i < $csc; $i++)
					{
				      $tab_log_install[$i]['jeu'] = $array_games_list[$marked[$i]]['name'];
				      $tar_object = new \Archive_Tar($path_install.'/'.$array_games_list[$marked[$i]]['name']);

				      //V�rifier la pr�sence des fichiers de conf dans l'archive
					  $tab_file_archive = array();
				      if (($v_list  =  $tar_object->listContent()) != 0)
				      {
				      	 $size_v_list = sizeof($v_list);
				         for ($j=0; $j < $size_v_list; $j++)
				         {
				            $tab_file_archive[$j] = $v_list[$j]['filename'];
				         }
				         $nom_arch = nom_sans_ext($array_games_list[$marked[$i]]['name']);
				         //Pr�sence du fichier ini ?
				         $nom_verif_ini = $nom_arch.'/'.$nom_arch.'_config.ini';
				         if ( !in_array($nom_verif_ini ,$tab_file_archive) )
				         {
				            $tab_log_install[$i]['resultat'] = sprintf($user->lang('ARCADE_ERREUR_ARCHIVE'), 'ini');
				            continue;
				         }
				         //Presence du fichier swf ?
				         $nom_verif_swf = $nom_arch.'/'.$nom_arch.'.swf' || $nom_arch.'/'.$nom_arch.'.html';
				         $nom_swf = $nom_arch;
				         if (!in_array($nom_verif_swf, $tab_file_archive))
				         {
				            $tab_log_install[$i]['resultat'] = sprintf($user->lang('ARCADE_ERREUR_ARCHIVE'), 'swf' || 'html');
				            continue;
				         }
				         //Pr�sence du fichier gif ?
				         $nom_verif_gif = $nom_arch.'/pics/'.$nom_arch.'.gif';
				         if (!in_array($nom_verif_gif, $tab_file_archive))
				         {
				            $tab_log_install[$i]['resultat'] = sprintf($user->lang('ARCADE_ERREUR_ARCHIVE'), 'gif');
				            continue;
				         }
				      }
				      else
				      {
				         $tab_log_install[$i]['resultat'] = sprintf($user->lang('ARCADE_ERREUR_FORMAT'), $array_games_list[$marked[$i]]['name']);
				         continue;
				      }
				      // Fin v�rif archive

				      //V�rifier qu'il n'existe pas d�j� un rep de m�me nom
				      //Sinon erreur
				      if (is_dir($phpbb_root_path.'arcade/games/'.$nom_arch))
				      {
				         $tab_log_install[$i]['resultat'] = sprintf($user->lang('ARCADE_ALREADY_EXIST'), $array_games_list[$marked[$i]]['name']);
				         continue;
				      }

				      // Extraction de l'archive dans le rep games
				      $tar_object->extract($phpbb_root_path.'arcade/games');
				      $old = umask(0);
				      $this->ra_chmod_dir($phpbb_root_path.'arcade/games/'.$nom_arch);
				      umask($old);
				      @chmod($phpbb_root_path.'arcade/games/'.$nom_arch, 0777);

				      // Parse du fichier ini dans le tableau tab_info_games
				      $tab_info_games = parse_ini_file($phpbb_root_path.'arcade/games/' . $nom_verif_ini);
					  if (isset($tab_info_games['controle']))
				      {
				         $controle = intval($tab_info_games['controle']);
				      }
				      else
				      {
				         $controle = 0;
				      }
				      if (isset($tab_info_games['jeuxhtml5']))
						{
                     $jeuxhtml5 = intval($tab_info_games['jeuxhtml5']);
					}
					else
					{
                     $jeuxhtml5 = 0;
					}
					  if (isset($tab_info_games['anti_triche']))
				      {
				         $game_cheat_control = intval($tab_info_games['anti_triche']);
				      }
				      else
				      {
				         $game_cheat_control = 0;
				      }
				      if (isset($tab_info_games['highscore_type']))
				      {
				         $game_highscore_type = intval($tab_info_games['highscore_type']);
				      }
				      else
				      {
				         $game_highscore_type = 0;
				      }
				      $game_pic = $nom_arch . '.gif';
				      if (isset($tab_info_games['fps']))
				      {
				         $fps = intval($tab_info_games['fps']);
				      }
				      else
				      {
				         $fps = 0;
				      }
				      if (isset($tab_info_games['largeur']))
				      {
				         $largeur = intval($tab_info_games['largeur']);
				      }
				      else
				      {
				         $largeur = 0;
				      }
				      if (isset($tab_info_games['hauteur']))
				      {
				         $hauteur = intval($tab_info_games['hauteur']);
				      }
				      else
				      {
				         $hauteur = 0;
				      }
				      if (isset($tab_info_games['size']))
				      {
				         $game_size = intval($tab_info_games['size']);
				      }
				      else
				      {
				         $game_size = 0;
				      }
				      if (isset($tab_info_games['bgcolor']))
				      {
				         $game_bgcolor = preg_replace('@[^A-F0-9]@', '',$tab_info_games['bgcolor']);
				      }
				      else
				      {
				         $game_bgcolor = 0;
				      }
				      if (isset($tab_info_games['nbdecimal']))
				      {
				         $game_nbdecimal = intval($tab_info_games['nbdecimal']);
				      }
				      else
				      {
				         $game_nbdecimal = 0;
				      }

				      // Supprimer le fichier ini
				      @unlink($phpbb_root_path.'arcade/games/' .$nom_verif_ini);

				      // Ins�rer l'enregistrement dans la table des jeux
				      $sql = 'SELECT MAX(game_order) AS max_order
				      FROM ' . RA_GAMES_TABLE;
				      $result = $db->sql_query($sql);
				      $row = $db->sql_fetchrow($result);
				      $next_order = $row['max_order'] + 1;

				      $sql_data = array(
					  	  'game_pic' 			=> utf8_encode($game_pic),
						  'game_desc'		 	=> utf8_encode($tab_info_games['description']),
						  'game_cont'		 	=> $controle,
						  'game_html5'          => $jeuxhtml5,
						  'game_name'			=> utf8_encode($tab_info_games['nom']),
						  'game_swf'			=> utf8_encode($nom_swf),
						  'game_scorevar'		=> utf8_encode($tab_info_games['variable']),
						  'game_width'			=> $largeur,
						  'game_height'			=> $hauteur,
						  'game_type'			=> 1,
						  'game_order'			=> $next_order,
						  'game_cheat_control'	=> $game_cheat_control,
						  'game_scoretype'		=> $game_highscore_type,
						  'game_fps'			=> $fps,
						  'game_size'			=> $game_size,
						  'game_bgcolor'		=> $game_bgcolor,
						  'game_nbdecimal'		=> $game_nbdecimal,
						  'ra_cat_id'			=> $cat_id,
					  );
					  $sql = 'INSERT INTO ' . RA_GAMES_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);
				      $db->sql_query($sql);

 					  $sql = 'UPDATE ' . RA_CAT_TABLE . '
							  SET ra_cat_nbgames = ra_cat_nbgames + 1
							  WHERE ra_cat_id = ' . (int)$cat_id;
					  $db->sql_query($sql);
					  $cache->destroy(RA_CAT_TABLE);

				      // Supprimer l'archive du rep games_pack
				      @unlink($path_install.'/'.$array_games_list[$marked[$i]]['name']);
				      $tab_log_install[$i]['resultat'] = $user->lang('ARCADE_ARCHIVE_OK');
				   }
				   unset($action);
				   unset($tar_object);

				   $template->assign_vars(array(
						'S_GAMES_INSTALL'			=> true,
						'L_TITLE' 					=> $user->lang('ADMIN_GAMES_RESULTAT'),
						'L_TITLE_EXPLAIN' 			=> $user->lang('ADMIN_GAMES_RESULTAT_EXPLAIN'),
						'L_NAME' 					=> $user->lang('ARCADE_ARCHIVE_RESULTAT'),
						'L_SIZE' 					=> $user->lang('ARCADE_RESULTAT'),
				   ));
				   // Parse tab_log_install
				   $nb_install = sizeof($tab_log_install);
				   for($i = 0; $i < $nb_install; $i++)
				   {
				       $template->assign_block_vars('ligne_loginstall', array(
					       'NUM' 		=> $i+1,
					       'ARCHIVE' 	=> $tab_log_install[$i]['jeu'],
					       'RESULTAT' 	=> $tab_log_install[$i]['resultat'],
				       ));
				   }
				   unset($tab_log_install);
				   break;
				}

				// R�cup�ration de la liste des cat�gories
				$sql = 'SELECT ra_cat_title, ra_cat_id
						FROM ' . RA_CAT_TABLE . '
						ORDER BY ra_cat_title ASC';
				$result = $db->sql_query($sql);
				$liste_cat = '';
				while ( $row = $db->sql_fetchrow($result))
				{
				   $selected = ( $row['ra_cat_id'] == $cat_id ) ? " selected='selected'" : "" ;
				   $liste_cat .= "<option value='" . $row['ra_cat_id'] . "' $selected >" . $row['ra_cat_title'] . "</option>\n";
				}
				$hidden_fields .= "<input type='hidden' name='last_catid' value='$cat_id' />";
				$db->sql_freeresult($result);

				// R�cup�ration de la liste des archives jeux du rep games_pack
				/*$template->set_filenames(array( 'body' => 'admin/arcade_games_install.tpl'));*/

				$i=0;
				$handle = opendir($path_install);

				if ($handle === false)
				{
					echo 'Games folder missing';
					return;
				}

				while (false !== ($file = readdir($handle)))
				{
					$tab_info_archive = pathinfo($path_install.'/'.$file);
					$type = $tab_info_archive['extension'];
					if ($file != '.' && $file != '..' && $type=='tar')
					{
						$taille = size_hum_read(filesize($path_install.'/'.$file));
						$array_games_list[$i]['id'] = $i;
						$array_games_list[$i]['name'] = $file;
						$array_games_list[$i]['size'] = $taille;
						$i++;
					}
				}
				closedir($handle);

				// Parse du tableau array_game_list dans le template
				$nb_games = sizeof($array_games_list);
				for($i = 0; $i < $nb_games; $i++)
				{
				    $template->assign_block_vars('ligne_gameinstall', array(
				    'ID' => $array_games_list[$i]['id'],
				    'NAME' => $array_games_list[$i]['name'],
				    'SIZE' => $array_games_list[$i]['size']
				    ));
				}
				$total_games = $i;

				$this->page_title = 'RA_GAMES_INSTALL';
				$template->assign_vars(array(
					'S_GAMES_INSTALL'		=> true,
					'L_TITLE'				=> $user->lang($this->page_title),
					'L_TITLE_EXPLAIN'		=> $user->lang($this->page_title . '_EXPLAIN'),

					'L_CATEGORIE' 			=> $user->lang('GAME_CATEGORY'),
					'L_CATEGORIE_EXPLAIN' 	=> $user->lang('GAME_CATEGORY_EXPLAIN'),
					'L_INSTALL' 			=> $user->lang('INSTALL_GAME'),
					'L_GAME' 				=> $user->lang('GAME_NAME'),
					'L_SIZE' 				=> $user->lang('ARCHIVE_SIZE'),
					'L_NAME' 				=> $user->lang('ARCHIVE_NAME'),
					'L_FOR_GAME_SELECTION' 	=> $user->lang('FOR_GAME_SELECTION'),
					'L_CHOIX_CATEGORIE' 	=> $user->lang('ARCADE_CHOIX_CATEGORIE'),
					'S_CATEGORIE' 			=> $liste_cat,
					'S_HIDDEN_FIELDS'		=> $hidden_fields,
					
					'ERR_EXT'				=> $err_ext,
					'UPLOAD_OK'				=> $upload_ok,
					'UPLOAD_NO'				=> $upload_no,
					'U_ACTION_GAME'			=> $this->u_action . '&amp;action=upload_games',

					'U_ACTION'				=> $this->u_action . '&amp;action=install_games',
				));

				if ( $total_games>0 )
				{
				  $template->assign_block_vars('switch_liste_non_vide', array());
				}

			break;

			case 'cheat':
				$start = $request->variable('start', 0);
				$action = $request->variable('action', '');

				if ( $action == 'delete_cheater' )
				{
			    	$marked		= $request->variable('mark', array(0));
					$csc = count($marked);
					if($csc == 0)
					{
						trigger_error('Aucune ligne s�lectionn�e');
					}
					$sql = 'DELETE FROM ' . RA_CHEATERS_TABLE . '
							WHERE ' . $db->sql_in_set('cheater_id', $marked);
					$db->sql_query($sql);
					unset($action);
				}

				$sql_array = array(
					'SELECT'	=> 'u.username, u.user_id, u.user_colour, g.game_name, a.cheater_id, a.cheater_date, a.score_game, a.cheater_realtime, a.cheater_flashtime, a.cheater_type',
					'FROM'		=> array(
						RA_GAMES_TABLE	=> 'g',
						RA_CHEATERS_TABLE => 'a'
					),
					'LEFT_JOIN'	=> array(
						array(
							'FROM'	=> array(USERS_TABLE => 'u'),
							'ON'	=> 'a.user_id = u.user_id'
						)
					),
					'WHERE'		=> 'g.game_id = a.game_id',
					'ORDER_BY'	=> 'a.cheater_date DESC, g.game_name ASC, u.username ASC'
				);
				$sql = $db->sql_build_query('SELECT', $sql_array);
				$result = $db->sql_query_limit($sql, $config['games_per_page_acp'], $start);

				$cheaters = array();
				while ($row = $db->sql_fetchrow($result))
				{
					$cheaters[] = $row;
				}
				$nb_cheaters = isset($cheaters) ? sizeof($cheaters) : 0;
				for($i = 0; $i < $nb_cheaters; $i++)
				{
					$template->assign_block_vars('ligne_cheat', array(
						'CHEATER_ID' 			=> $cheaters[$i]['cheater_id'],
						'CHEATER_USERS' 		=> get_username_string('full', $cheaters[$i]['user_id'], $cheaters[$i]['username'], $cheaters[$i]['user_colour']),
						'CHEATER_GAME' 			=> $cheaters[$i]['game_name'],
						'CHEATER_DATE_CHEAT' 	=> $user->format_date($cheaters[$i]['cheater_date']),
						'CHEATER_SCORE' 		=> $cheaters[$i]['score_game'],
						'CHEATER_TIME_CLIENT' 	=> $cheaters[$i]['cheater_flashtime'],
						'CHEATER_TIME_SERVER' 	=> $cheaters[$i]['cheater_realtime'],
						'CHEATER_TYPE' 			=> $cheaters[$i]['cheater_type'],
					));
				}
				if ($nb_cheaters > 0)
				{
				    $db->sql_freeresult($result);
				}

				$sql = 'SELECT count(*) AS total FROM ' . RA_CHEATERS_TABLE ;
				$total_cheaters = 0;
				$result = $db->sql_query($sql);
				if ( $total = $db->sql_fetchrow($result) )
				{
				    $total_cheaters = $total['total'];
				}
				$db->sql_freeresult($result);

				$pagination = $phpbb_container->get('pagination');
				$pagination->generate_template_pagination($this->u_action, 'pagination', 'start', $total_cheaters, $config['games_per_page_acp'], $start, true);

				$this->page_title = 'RA_CHEATER_MANAGE';
				$template->assign_vars(array(
					'S_CHEAT_MANAGE'		=> true,
					'L_TITLE'				=> $user->lang($this->page_title),
					'L_TITLE_EXPLAIN'		=> $user->lang($this->page_title . '_EXPLAIN'),

					'L_ACTION' 				=> $user->lang('ACTION'),
					'L_GAME' 				=> $user->lang('GAME_NAME'),
					'L_DATE_CHEAT'			=> $user->lang('DATE_CHEAT'),
					'L_SCORE' 				=> $user->lang('GAME_SCORE'),
					'L_TIME_CLIENT' 		=> $user->lang('TIME_CLIENT'),
					'L_TIME_SERVER' 		=> $user->lang('TIME_SERVER'),
					'L_CHEAT_TYPE' 			=> $user->lang('TYPE_TRICHE'),
					'L_DELETE' 				=> $user->lang('DELETE'),
					'L_FOR_GAME_SELECTION' 	=> $user->lang('FOR_GAME_SELECTION'),
					'ALL_CHECKED' 			=> $user->lang('ALL_CHECKED'),
					'NOTHING_CHECKED' 		=> $user->lang('NOTHING_CHECKED'),
					'U_ACTION'				=> $this->u_action . '&amp;action=delete_cheater',
				));

				// On affiche le bouton supprimer seulement s'il existe au moins un cheater dans la liste
				if ( $total_cheaters>0 )
				{
				  $template->assign_block_vars('switch_liste_non_vide', array());
				}

			break;
		}
	}

	
	/**
	* Select games order
	*/
		function select_games()
	{
		global $db,$user;
		
		$select_games ='';
		
		$sql_array = array(
				'SELECT'	=> 'g.game_id , g.game_name',
					
				'FROM'		=> array(
					RA_GAMES_TABLE => 'g'
				),
				'ORDER_BY' => 'g.game_id ASC',				
			);
			
			$sql = $db->sql_build_query('SELECT', $sql_array);
			$result = $db->sql_query($sql);
			
			
			$select_games  .= '<option  value="">(0) '.$user->lang('RA_DESACTIVER').'</option>';
			
			while( $row = $db->sql_fetchrow($result) )
			{	
				$select_games  .= '<option  value="">('.$row['game_id'].')&nbsp;'.$row['game_name'].'</option>';
			}

		return $select_games;
	}
	
	
	/**
	* Select games order
	*/
	function select_games_order($selected_value, $key)
	{
		global $user;

		$games_order_ary = array('RA_GAMES_ORDER_ALPHA', 'RA_GAMES_ORDER_POPULAR', 'RA_GAMES_ORDER_FIXED', 'RA_GAMES_ORDER_NEWS');
		$games_order_options = '';
		foreach ($games_order_ary as $order_type)
		{
			$selected = ($selected_value == $order_type) ? ' selected="selected"' : '';
			$games_order_options .= '<option value="' . $order_type . '"' . $selected . '>' . $user->lang($order_type) . '</option>';
		}

		return $games_order_options;
	}

	/**
	* Get category details
	*/
	function get_category_info($cat_id)
	{
		global $db;

		$sql = 'SELECT *
			FROM ' . RA_CAT_TABLE . '
			WHERE ra_cat_id = ' . (int) $cat_id;
		$result = $db->sql_query($sql);
		$row = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);

		if (!$row)
		{
			trigger_error("Category #$cat_id does not exist", E_USER_ERROR);
		}

		return $row;
	}

	/**
	* Update category data
	*/
	function update_category_data(&$category_data)
	{
		global $db, $user, $cache;

		$errors = array();

		if (!$category_data['ra_cat_title'])
		{
			$errors[] = $user->lang('CATEGORY_NAME_EMPTY');
		}

		if (sizeof($errors))
		{
			return $errors;
		}

		// Unset data that are not database fields
		$category_data_sql = $category_data;

		if (!isset($category_data_sql['ra_cat_id']))
		{
			// no ra_cat_id means we're creating a new category

        	$sql = 'SELECT MAX(ra_cat_order) + 1 AS next_order
					FROM ' . RA_CAT_TABLE;
			$result = $db->sql_query($sql);
    		$row = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			if (is_null($row['next_order']))
			{
				$category_data_sql['ra_cat_order'] = 1;
			}
			else
			{
				$category_data_sql['ra_cat_order'] = $row['next_order'];
			}

			$sql = 'INSERT INTO ' . RA_CAT_TABLE . ' ' . $db->sql_build_array('INSERT', $category_data_sql);
			$db->sql_query($sql);

			$category_data['ra_cat_id'] = $db->sql_nextid();
			$cache->destroy(RA_CAT_TABLE);
			add_log('admin', 'LOG_RACAT_ADD', $category_data['ra_cat_title']);
		}
		else
		{
			$this->get_category_info($category_data_sql['ra_cat_id']);
			$ra_cat_id = $category_data_sql['ra_cat_id'];

			$sql = 'UPDATE ' . RA_CAT_TABLE . '
				SET ' . $db->sql_build_array('UPDATE', $category_data_sql) . '
				WHERE ra_cat_id = ' . (int)$ra_cat_id;
			$db->sql_query($sql);

			// Add it back
			$category_data['ra_cat_id'] = $ra_cat_id;
			$cache->destroy(RA_CAT_TABLE);
			add_log('admin', 'LOG_RACAT_EDIT', $category_data['ra_cat_title']);
		}
		return $errors;
	}

	// Delete category only if no games
	function ra_cat_delete($cat_id)
	{
	    global $db, $user, $cache;
		$errors = array();

		$category_data = $this->get_category_info($cat_id);
		if (!$category_data)
		{
	    	$errors[] = $user->lang('NO_RACAT');
		}

	    if ( $this->is_category_empty($cat_id) )
	    {
	    	$errors[] = $user->lang('MUST_DELETE_GAMES');
	    }
	    else
	    {
			$sql = 'DELETE FROM ' . RA_CAT_TABLE . '
				WHERE ra_cat_id = ' . (int)$cat_id;
			$db->sql_query($sql);
			$cache->destroy(RA_CAT_TABLE);
	    }

		if (!sizeof($errors))
		{
			add_log('admin', 'LOG_RACAT_DEL', $category_data['ra_cat_title']);
		}

	    return $errors;
	}

	/**
	* Check if category containing games
	*/
	function is_category_empty($cat_id)
	{
		global $db;

		$sql = 'SELECT *
			FROM ' . RA_GAMES_TABLE . '
			WHERE ra_cat_id = ' . (int)$cat_id;
		$result = $db->sql_query($sql);
		$row = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);

		if (!$row)
		{
			return false;
		}

		return true;
	}

	/**
	* Synchro functions for arcade category
	*/
	function ra_cat_sync($cat_id = 0)
	{
		global $db, $user, $cache;
		$errors = array();

		$category_data = $this->get_category_info($cat_id);
		if (!$category_data)
		{
	    	$errors[] = $user->lang('NO_RACAT');
		}


	    $nbgames = $this->ra_cat_nbgames($cat_id);
	    $sql = 'UPDATE ' . RA_CAT_TABLE . ' SET ra_cat_nbgames = ' . (int)$nbgames . '
	            WHERE ra_cat_id = ' . (int)$cat_id;
	    $db->sql_query($sql);
		$cache->destroy(RA_CAT_TABLE);

		if (!sizeof($errors))
		{
			add_log('admin', 'LOG_RACAT_SYNC', $category_data['ra_cat_title']);
		}

	    return $errors;
	}

	/**
	* Move function for arcade category or games
	*/
	function ra_move_updown($param = '', $item1 = 0, $item2 = 0, $order1 = 0, $order2 = 0)
	{
		global $db, $cache;

	    if ($param === 'cat')
	    {
	        $sql = 'UPDATE ' . RA_CAT_TABLE . '
		        SET ra_cat_order = ' . (int)$order1 . '+' . (int)$order2 .' - ra_cat_order
		        WHERE ra_cat_id = '. (int)$item1 . ' OR ra_cat_id = ' . (int)$item2;

	    	$db->sql_query($sql);
			$cache->destroy(RA_CAT_TABLE);
	    }
		else if ($param === 'game')
	    {
	        $sql = 'UPDATE ' . RA_GAMES_TABLE . '
		        SET game_order = ' . (int)$order1 . '+' . (int)$order2 .' - game_order
		        WHERE game_id = '. (int)$item1 . ' OR game_id = ' . (int)$item2;

	    	$db->sql_query($sql);
			$cache->destroy(RA_CAT_TABLE);
	    }

	    return true;
	}

	/**
	* Game list for category
	*/
	function ra_cat_manage($cat_id = 0, $start = 0)
	{
	    global $db, $config;

	    $games_per_page = $config['games_per_page_acp'];

		$order_by = 'g.game_id DESC';
		if ($config['games_order_acp'] == 'RA_GAMES_ORDER_ALPHA')
		{
		  $order_by = 'g.game_name ASC ';
		}
		else if ($config['games_order_acp'] == 'RA_GAMES_ORDER_POPULAR')
		{
		  $order_by = 'gs.gamestat_set DESC ';
		}
		else if ($config['games_order_acp'] == 'RA_GAMES_ORDER_FIXED')
		{
		  $order_by = 'g.game_order ASC ';
		}
		else if ($config['games_order_acp'] == 'RA_GAMES_ORDER_NEWS')
		{
		  $order_by = 'g.game_id DESC ';
		}

		// Find game list for the category
		$sql_array = array(
			'SELECT'	=> 'COUNT(s.score_game) as nbscores,g.*, gs.gamestat_highscore, gs.gamestat_set',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's'),
					'ON'	=> 's.game_id = g.game_id'
				),
				array(
					'FROM'	=> array(RA_GAMESTAT_TABLE => 'gs'),
					'ON'	=> 'g.game_id = gs.game_id'
				)
			),
			'WHERE'		=> 'g.ra_cat_id = ' . $cat_id,
			'GROUP_BY'	=> 'g.game_id',
			'ORDER_BY'	=> $order_by
		);

		$sql = $db->sql_build_query('SELECT', $sql_array);
		$result = $db->sql_query_limit($sql, $games_per_page, $start);
		$liste_jeux = $db->sql_fetchrowset($result);
		$db->sql_freeresult($result);

	    return $liste_jeux;
	}

	/**
	* Game count for category
	*/
	function ra_cat_nbgames($cat_id = 0)
	{
		global $db;
	    $sql = 'SELECT COUNT(game_id) AS nbgames
			FROM ' . RA_GAMES_TABLE . '
	        WHERE ra_cat_id = ' . (int)$cat_id;
	    $result = $db->sql_query($sql);
	    $row = $db->sql_fetchrow($result);
	    $db->sql_freeresult($result);
    	$total_games = $row['nbgames'];
	    return $total_games;
	}

	function ra_dir_delete($game_dir)
	{
	  $current_dir = @opendir($game_dir);
	  while($entryname = @readdir($current_dir))
	  {
	    if(is_dir($game_dir.'/'.$entryname) and ($entryname != '.' and $entryname!='..'))
	    {
	      $this->ra_dir_delete($game_dir.'/'.$entryname);
	    }
	    elseif($entryname != '.' and $entryname!='..')
	    {
	      @unlink($game_dir.'/'.$entryname);
	    }
	  }
	  @closedir($current_dir);
	  @rmdir($game_dir);
	}

	/**
	* Game delete
	*/
	function ra_game_delete($cat_id = 0, $array_games)
	{
	    global $db, $user, $cache, $phpbb_root_path;
		$errors = $category_data = array();

	    $select_game_id = '';

		$category_data = $this->get_category_info($cat_id);
		if (!$category_data)
		{
	    	$errors[] = $user->lang('NO_RACAT');
		}

	    $nb_games = count($array_games);
	    for ($i = 0; $i < $nb_games; $i++)
	    {
			    $select_game_id .= ( ( $select_game_id != '' ) ? ', ' : '' ) . (int)$array_games[$i];
	    }

	    //Suppression des repertoires des jeux du ftp
	    $sql = 'SELECT game_swf FROM ' . RA_GAMES_TABLE
	            . ' WHERE game_id IN (' . $select_game_id . ')';
		$result = $db->sql_query($sql);

	    while ( false !== ($row = $db->sql_fetchrow($result)) )
	    {
	        $game_dir = $phpbb_root_path . 'arcade/games/' . nom_sans_ext($row['game_swf']);
	        $this->ra_dir_delete($game_dir);
	    }
	    $db->sql_freeresult($result);

	    /*//Petit delele multi-table avec syntaxe pour mysql >= 4.1
	    //
	    $sql = 'DELETE ' . RA_GAMES_TABLE .' g, ' . RA_SCORES_TABLE . ' s, ' . RA_GAMESTAT_TABLE . ' st
	            FROM ' . RA_GAMES_TABLE . ' g
	            LEFT JOIN ' . RA_SCORES_TABLE . ' s ON g.game_id = s.game_id
	            LEFT JOIN ' . RA_GAMESTAT_TABLE . ' st ON g.game_id = st.game_id
	            WHERE g.game_id IN (' . $select_game_id . ')';*/

        $sql = 'DELETE FROM ' . RA_GAMESTAT_TABLE .
                ' WHERE game_id IN (' . $select_game_id . ')';
        $db->sql_query($sql);

        $sql = 'DELETE FROM ' . RA_SCORES_TABLE .
                ' WHERE game_id IN (' . $select_game_id . ')';
        $db->sql_query($sql);

        $sql = 'DELETE FROM ' . RA_GAME_RATING_TABLE . ' WHERE game_id IN (' . $select_game_id . ')';
        $db->sql_query($sql);

        $sql = 'DELETE FROM ' . RA_GAMES_TABLE .
                ' WHERE game_id IN (' . $select_game_id . ')';
        $db->sql_query($sql);

	    $sql = 'UPDATE ' . RA_CAT_TABLE . ' SET ra_cat_nbgames = ra_cat_nbgames - ' . (int)$nb_games .
	           ' WHERE ra_cat_id = ' . (int)$cat_id;
        $db->sql_query($sql);
		$cache->destroy(RA_CAT_TABLE);
	    return $errors;
	}

	/**
	* Get game details
	*/
	function get_game_info($gid)
	{
		global $db, $user;

		$sql = 'SELECT *
			FROM ' . RA_GAMES_TABLE . '
			WHERE game_id = ' . (int)$gid;
		$result = $db->sql_query($sql);
		$row = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);

		if (!$row)
		{
			trigger_error(sprintf($user->lang('ARCADE_NO_GID'), $gid), E_USER_ERROR);
		}

		return $row;
	}
	/**
	* Get category list
	*/
	function get_category_list($cat_id = 0)
	{
		global $db;

	    $sql = 'SELECT ra_cat_id, ra_cat_title
				FROM ' . RA_CAT_TABLE . '
				ORDER BY ra_cat_title ASC';
	    $result = $db->sql_query($sql);
	    $list_cat = '';
	    $selected = '';
	    while ( $rowcat = $db->sql_fetchrow($result))
	    {
			if (isset($rowcat['ra_cat_id']) && isset($rowgame['ra_cat_id']))
			{
				$selected = ( $rowcat['ra_cat_id'] == $cat_id ) ? " selected='selected'" : "" ;
			}
			$list_cat .= "<option value='" . $rowcat['ra_cat_id'] . "' $selected >" . $rowcat['ra_cat_title'] . "</option>\n";
	    }
	    return $list_cat;
	}
	
	

	/**
	* Update category data
	*/
	protected function update_game_data(&$game_data)
	{
		global $db, $user, $cache;

		$errors = array();

		if (!$game_data['game_name'])
		{
			$errors[] = $user->lang('GAME_NAME_EMPTY');
		}

		if (sizeof($errors))
		{
			return $errors;
		}

		// Unset data that are not database fields
		$game_data_sql = $game_data;

		if (!isset($game_data_sql['game_id']))
		{
			// no game_id means we're creating a new game

        	$sql = 'SELECT MAX(game_order) + 1 AS next_order
					FROM ' . RA_GAMES_TABLE;
			$result = $db->sql_query($sql);
    		$row = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			if (is_null($row['next_order']))
			{
				$game_data_sql['game_order'] = 1;
			}
			else
			{
				$game_data_sql['game_order'] = $row['next_order'];
			}

			$sql = 'INSERT INTO ' . RA_GAMES_TABLE . ' ' . $db->sql_build_array('INSERT', $game_data_sql);
			$db->sql_query($sql);

			$game_data['game_id'] = $db->sql_nextid();

		    $sql = 'UPDATE ' . RA_CAT_TABLE . ' SET ra_cat_nbgames = ra_cat_nbgames + 1' .
	           ' WHERE ra_cat_id = ' . (int)$game_data_sql['ra_cat_id'];
	        $db->sql_query($sql);
			$cache->destroy(RA_CAT_TABLE);

			add_log('admin', 'LOG_RAGAME_ADD', $game_data['game_name']);
		}
		else
		{
			$row = $this->get_game_info($game_data_sql['game_id']);
			$game_id = intval($row['game_id']);

			$sql = 'UPDATE ' . RA_GAMES_TABLE . '
				SET ' . $db->sql_build_array('UPDATE', $game_data_sql) . '
				WHERE game_id = ' . (int)$game_id;
			$db->sql_query($sql);

			// Add it back
			$game_data['game_id'] = $game_id;

			add_log('admin', 'LOG_GAME_EDIT', $game_data['game_name']);
		}
		return $errors;
	}

	protected function ra_move_games($last_cat_id = 0, $new_cat_id = 0, $array_games)
	{
	    global $db, $cache;

	    if (($last_cat_id == $new_cat_id) || ($last_cat_id <= 0) || ($new_cat_id <= 0)) return true;

	    $nb_games = sizeof($array_games);

	    $sql = 'UPDATE ' . RA_GAMES_TABLE . ' SET ra_cat_id = ' . (int)$new_cat_id
	            . ' WHERE ' . $db->sql_in_set('game_id', $array_games);
	    $db->sql_query($sql);

	    //Mise � jour du nombre de jeux pour les cat�gories modifi�es
	    $sql = 'UPDATE ' . RA_CAT_TABLE . ' SET ra_cat_nbgames = ra_cat_nbgames - ' . (int)$nb_games
	            . ' WHERE ra_cat_id = ' . (int)$last_cat_id;
	    $db->sql_query($sql);

	    $sql = 'UPDATE ' . RA_CAT_TABLE . ' SET ra_cat_nbgames = ra_cat_nbgames + ' . (int)$nb_games
	            . ' WHERE ra_cat_id = ' . (int)$new_cat_id;
	    $db->sql_query($sql);
		$cache->destroy(RA_CAT_TABLE);

	    return true;
	}

	/**
	* Synchro function for games
	*/
	protected function ra_games_resynch($array_games)
	{
		global $db, $user;
	    $nb_games = 0;
		$errors = array();

	    if (!sizeof($array_games))
		{
			$errors[] = $user->lang('NO_SELECTED_GAMES');
		}
		else
		{
		    $nb_games = sizeof($array_games);
		}

		if (sizeof($errors))
		{
			return $errors;
		}

	    for ($i = 0; $i < $nb_games; $i++)
	    {
	        $sql = 'SELECT SUM(score_set) AS nbparty FROM ' . RA_SCORES_TABLE .
	                ' WHERE game_id = ' . (int)$array_games[$i];
	        $result = $db->sql_query($sql);
	        $row = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);
    		if (!is_null($row['nbparty']))
    		{
	            $sql = 'UPDATE ' . RA_GAMESTAT_TABLE . ' SET gamestat_set = ' . (int)$row['nbparty'] . '
	                    WHERE game_id = ' . (int)$array_games[$i];
	            $db->sql_query($sql);
    		}
	    }
	    return $errors;
	}

	protected function ra_scores_delete($array_games)
	{
		global $db, $user;
	    $errors = array();

	    if (!sizeof($array_games))
		{
			$errors[] = $user->lang('NO_SELECTED_GAMES');
		}

		if (sizeof($errors))
		{
			return $errors;
		}

	    $sql_in = $db->sql_in_set('game_id', $array_games);
		$sql = 'DELETE FROM ' . RA_SCORES_TABLE . '
			WHERE ' . $sql_in;
	    $db->sql_query($sql);

	    $sql = 'UPDATE ' . RA_GAMESTAT_TABLE .
			   ' SET gamestat_user_id = 0, gamestat_highscore = 0, gamestat_highdate = 0' .
	           ' WHERE ' . $sql_in;
	    $db->sql_query($sql);
	    return $errors;
	}

	protected function ra_note_delete($array_games)
	{
		global $db, $user;
	    $errors = array();

	    if (!sizeof($array_games))
		{
			$errors[] = $user->lang('NO_SELECTED_GAMES');
		}

		if (sizeof($errors))
		{
			return $errors;
		}

	    $sql_in = $db->sql_in_set('game_id', $array_games);

	    $sql = 'DELETE FROM ' . RA_GAME_RATING_TABLE . '
			WHERE ' . $sql_in;
	    $db->sql_query($sql);

	    $sql = 'UPDATE ' . RA_GAMESTAT_TABLE .
           ' SET gamestat_rating = 0, gamestat_rating_set = 0
		   WHERE ' . $sql_in;
	    $db->sql_query($sql);
	    return $errors;
	}

	protected function ra_nbparties_delete($array_games)
	{
		global $db, $user;
	    $errors = array();

	    if (!sizeof($array_games))
		{
			$errors[] = $user->lang('NO_SELECTED_GAMES');
		}

		if (sizeof($errors))
		{
			return $errors;
		}

	    $sql_in = $db->sql_in_set('game_id', $array_games);

	    $sql = 'UPDATE ' . RA_SCORES_TABLE . ' SET score_set = 0
			WHERE ' . $sql_in;
	    $db->sql_query($sql);

	    $sql = 'UPDATE ' . RA_GAMESTAT_TABLE .
           ' SET gamestat_set = 0
		   WHERE ' . $sql_in;
	    $db->sql_query($sql);
	    return $errors;
	}

	protected function ra_check_auth($type, $key, $u_access, $is_admin)
	{
		$auth_user = 0;

		if( count($u_access) )
		{
			for($j = 0; $j < count($u_access); $j++)
			{
				$result = 0;
				switch($type)
				{
					case AUTH_ACL:
						$result = $u_access[$j][$key];
						// no break here?

					case AUTH_ADMIN:
						$result = $result || $is_admin;
						break;
				}

				$auth_user = $auth_user || $result;
			}
		}
		else
		{
			$auth_user = $is_admin;
		}

		return $auth_user;
	}

	protected function ra_chmod_dir($path = '')
	{
	  if (strlen($path) > 0 && is_dir($path))
	  {
	    if ($handle = opendir($path))
	    {
	      while (false !== ($file = readdir($handle)))
	      {
	        if ($file != '.' && $file != '..')
	        {
	          if (is_dir($path. '/' . $file))
	          {
			    $old = umask(0);
	            @chmod($path.'/'.$file, 0777);
	            umask($old);
	            $this->ra_chmod_dir($path.'/'.$file);
	          }
	        }
	      }
	      closedir($handle);
	    }
	  }
	  return true;
	}
}
