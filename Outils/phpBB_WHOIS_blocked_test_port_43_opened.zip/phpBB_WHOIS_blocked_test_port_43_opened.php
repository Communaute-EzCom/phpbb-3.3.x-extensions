<?php
function user_ipwhois($ip)
{
    if (empty($ip))
    {
        return '';
    }

    if (preg_match('#^(?:(?:\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.){3}(?:\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$#', $ip))
    {
        // IPv4 address
        $whois_host = 'whois.arin.net.';
    }
    else
    {
        return '';
    }

    $ipwhois = '';

    if (($fsk = @fsockopen($whois_host, 43)))
    {
        // CRLF as per RFC3912
        fputs($fsk, "$ip\r\n");
        while (!feof($fsk))
        {
            $ipwhois .= fgets($fsk, 1024);
        }
        @fclose($fsk);
    }

    $match = array();

    // Test for referrals from $whois_host to other whois databases, roll on rwhois
    if (preg_match('#ReferralServer: whois://(.+)#im', $ipwhois, $match))
    {
        if (strpos($match[1], ':') !== false)
        {
            $pos    = strrpos($match[1], ':');
            $server    = substr($match[1], 0, $pos);
            $port    = (int) substr($match[1], $pos + 1);
            unset($pos);
        }
        else
        {
            $server    = $match[1];
            $port    = 43;
        }

        $buffer = '';

        if (($fsk = @fsockopen($server, $port)))
        {
            fputs($fsk, "$ip\r\n");
            while (!feof($fsk))
            {
                $buffer .= fgets($fsk, 1024);
            }
            @fclose($fsk);
        }

        // Use the result from $whois_host if we don't get any result here
        $ipwhois = (empty($buffer)) ? $ipwhois : $buffer;
    }

    $ipwhois = htmlspecialchars($ipwhois);

    return trim($ipwhois);
}
echo '<pre>' . user_ipwhois('8.8.8.8') . '</pre>'; 