<?php
/**
*
* Extension phpbb-fr demo
*
* @copyright (c) 2015 phpBB-fr.com website team
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace phpbbfr\demo;

/**
* This ext class is optional and can be omitted if left empty.
* However you can add special (un)installation commands in the
* methods enable_step(), disable_step() and purge_step(). As it is,
* these methods are defined in \phpbb\extension\base, which this
* class extends, but you can overwrite them to give special
* instructions for those cases.
*/
class ext extends \phpbb\extension\base
{
	public function disable_step($old_state)
	{
		trigger_error('ACP_DEMO_CANT_DISABLED', E_USER_WARNING);
	}
}
