<?php
/**
 *
 * @package Extension phpbb-fr demo
 * @copyright (c) 2015 phpBB-fr.com website team
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace phpbbfr\demo\event;

/**
 * @ignore
 */
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Event listener
 */
class disable_listener implements EventSubscriberInterface
{
	static public function getSubscribedEvents()
	{
		return array(
			'core.user_session_handler'					=> 'disable_components_after_session',
			'core.adm_page_footer'						=> 'disable_components_before_template',
		);
	}

	/* @var \phpbb\template\template */
	protected $template;

	/* @var \phpbb\user */
	protected $user;

	/* @var \phpbb\auth\auth */
	protected $auth;

	/* @var \phpbb\request\request */
	protected $request;

	/** @var string phpBB root path */
	protected $root_path;

	/** @var string phpBB admin relative path */
	protected $adm_relative_path;

	/** @var string phpEx */
	protected $php_ext;

	/**
	 * Constructor
	 *
	 * @param \phpbb\template\template		$template				Template object
	 * @param \phpbb\user					$user					User object
	 * @param \phpbb\auth\auth				$auth					Auth object
	 * @param \phpbb\request\request		$request				Request object
	 * @param string						$root_path				phpBB root path
	 * @param string						$adm_relative_path		phpBB admin relative path
	 * @param string						$php_ext				phpEx
	 */
	public function __construct(\phpbb\template\template $template, \phpbb\user $user, \phpbb\auth\auth $auth, \phpbb\request\request $request, $root_path, $adm_relative_path, $php_ext)
	{
		$this->template = $template;
		$this->user = $user;
		$this->auth = $auth;
		$this->request = $request;
		$this->root_path = $root_path;
		$this->adm_relative_path = $adm_relative_path;
		$this->php_ext = $php_ext;
	}

	public function disable_components_after_session()
	{
		if (defined('ADMIN_START'))
		{
			switch($this->get_module_name($this->request->variable('i', '')))
			{
				case 'acp_database':
					if ($this->request->variable('action', '') == 'download')
					{
						$this->define_adm_mode();
						trigger_error('ACP_DEMO_BACKUP_DISABLED', E_USER_WARNING);
					}
					break;

				case 'acp_send_statistics':
					$this->define_adm_mode();
					trigger_error('ACP_DEMO_STATS_DISABLED', E_USER_WARNING);
					break;

				case 'acp_attachments':
					if ($this->request->variable('img_imagick', '') != '')
					{
						$this->define_adm_mode();
						trigger_error('ACP_DEMO_CONFIG_ATTACHMENTS_DENIED', E_USER_WARNING);
					}
					break;
			}
		}
	}

	public function disable_components_before_template()
	{
		global $module;

		if ($module->p_name == 'acp_php_info')
		{
			$message  = '<div class="errorbox"><h3>' . $this->user->lang['ERROR'] . '</h3>';
			$message .= '<p>' . $this->user->lang['ACP_DEMO_PHPINFO_DISABLED'] . '</p></div>';

			$this->template->assign_var('PHPINFO', $message);
		}
	}

	/**
	 * Enter in admin mode for correct error handling in disable_components_after_session()
	 */
	protected function define_adm_mode()
	{
		if (!defined('ADMIN_START'))
		{
			// The exception isn't catched
			//throw new \phpbb\exception\runtime_exception("Trying to enter in admin mode from a non-admin script");
			trigger_error('Trying to enter in admin mode from a non-admin script', E_USER_ERROR);
		}

		if (!defined('IN_ADMIN') && $this->auth->acl_get('a_') && !empty($this->user->data['session_admin']))
		{
			define('IN_ADMIN', true);

			// Set custom style for admin area
			$this->template->set_custom_style(array(
				array(
					'name' 		=> 'adm',
					'ext_path' 	=> 'adm/style/',
				),
			), $this->root_path . $this->adm_relative_path . 'style');

			$this->template->assign_var('T_ASSETS_PATH', $this->root_path . 'assets');
			$this->template->assign_var('T_TEMPLATE_PATH', $this->root_path . $this->adm_relative_path . 'style');

			// Load modules infos
			$module = new \p_master();
			$module->list_modules('acp');
			$module->set_active($this->request->variable('i', ''), $this->request->variable('mode', ''));
			$module->assign_tpl_vars(append_sid($this->root_path . $this->adm_relative_path . 'index.' . $this->php_ext));
		}
	}

	/**
	 * Hack to get the module name from a module id
	 *
	 * @param integer|string	$module_id	The module id
	 * @param string			$type		acp/mcp/ucp
	 *
	 * @return string			The module name
	 */
	protected function get_module_name($module_id, $type = 'acp')
	{
		$module = new \p_master();
		$module->list_modules($type);
		$module->set_active($module_id);

		return $module->p_name;
	}
}