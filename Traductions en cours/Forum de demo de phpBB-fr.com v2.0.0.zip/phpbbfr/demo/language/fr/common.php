<?php
/**
 *
 * @package Extension phpbb-fr demo
 * @copyright (c) 2015 phpBB-fr.com website team
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_DEMO_CANT_DISABLED'			=> 'Cette extension ne peut pas être désactivée.',
	'ACP_DEMO_PHPINFO_DISABLED'			=> 'Vous ne pouvez pas accéder aux informations PHP sur le forum de démo.',
	'ACP_DEMO_STATS_DISABLED'			=> 'L`envoi du rapport de statistiques est désactivé sur le forum de démo.',
	'ACP_DEMO_BACKUP_DISABLED'			=> 'Vous ne pouvez pas effectuer de sauvegarde de la base de données sur le forum de démo.',

	'ACP_DEMO_CONFIG_PHP_DENIED'		=> 'Pour des raisons de sécurité, le PHP n`est pas autorisé sur le forum de démo.',
	'ACP_DEMO_CONFIG_ATTACHMENTS_DENIED'=> 'L`utilisation des pièces jointes n`est pas autorisé sur le forum de démo.',
	'ACP_DEMO_CONFIG_MAIL_DENIED'		=> 'Les e-mails ne sont pas autorisés sur le forum de démo.',
	'ACP_DEMO_CONFIG_JABBER_DENIED'		=> 'Jabber n`est pas autorisé sur le forum de démo.',
	'ACP_DEMO_CONFIG_AVATARS_DENIED'	=> 'Vous ne pouvez pas stocker les avatars sur le forum de démo.',
));