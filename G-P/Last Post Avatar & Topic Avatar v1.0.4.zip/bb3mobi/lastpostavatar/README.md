# lastpostavatar
Last post user avatar && Topic Avatar
# Installation
Copy the entire contents of the repository to ext/bb3mobi/lastpostavatar
Navigate in the ACP to Customise -> Extension Management.
Click Enable for Last post avatar.

[![Build Status](https://travis-ci.org/bb3mobi/lastpostavatar.svg)](https://travis-ci.org/bb3mobi/lastpostavatar)
