<?php
/**
 *
 * Obscure Contact Us. An extension for the phpBB Forum Software package.
 * French translation by Galixte (https://www.galixte.com)
 *
 * @copyright (c) 2015 HiFiKabin
 * @license GNU General Public License, version 2 (GPL-2.0-only)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'OBSCURECONTACT_US_ENABLE'				=> 'Activer l’anti-spam pour « Nous contacter »',
	'OBSCURECONTACT_US_ENABLE_EXPLAIN'		=> 'Permet d’activer l’anti-spam pour « Nous contacter », la page de contact proposée par phpBB sera désactivée.',

	'ACP_OBSCURECONTACTUS_CONFIG'			=> 'Paramètres de l’anti-spam pour « Nous contacter »',
	'ACP_OBSCURECONTACTUS_CONFIG_EXPLAIN'	=> 'Sur cette page il est possible de configurer les options de l’extension Anti-spam pour « Nous contacter ».</br>Au moyen du langage JavaScript l’adresse e-mail saisie sera affichée mais sera invisible des robots d’indexation du Web.',
	'ACP_OBSCURECONTACTUS_CONFIG_SET'		=> 'Configuration',
	'OBSCURECONTACTUS_CONFIG_SAVED'			=> 'Les paramètres de l’anti-spam pour « Nous contacter » ont été mise à jour.',

	'OBSCURECONTACTUS_MOUSEOVER'			=> 'Texte affiché au survol de la souris',
	'OBSCURECONTACTUS_MOUSEOVER_EXPLAIN'	=> 'Permet d’afficher un texte au survol de la souris sur le lien « Nous contacter ».',

	'OBSCURECONTACTUS_PREFIX'				=> 'Identifiant de l’adresse e-mail',
	'OBSCURECONTACTUS_PREFIX_EXPLAIN'		=> 'Permet de saisir la partie de l’adresse e-mail située avant le symbole « @ ».',
	'OBSCURECONTACTUS_PREFIX_PLACEHOLDER'	=> 'nom',

	'OBSCURECONTACTUS_SUBJECT'				=> 'Sujet de l’e-mail',
	'OBSCURECONTACTUS_SUBJECT_EXPLAIN'		=> 'Permet de saisir un sujet pour l’e-mail.',

	'OBSCURECONTACTUS_SUFFIX'				=> 'Nom de domaine de l’adresse e-mail',
	'OBSCURECONTACTUS_SUFFIX_EXPLAIN'		=> 'Permet de saisir la partie de l’adresse e-mail située après le symbole « @ ».',
	'OBSCURECONTACTUS_SUFFIX_PLACEHOLDER'	=> 'domaine.fr',

	'OBSCURECONTACTUS_REQUIRE_3.1.0'		=> 'Cette extension requiert phpBB 3.1.0 ou une version plus récente et ne fonctionnera pas sous phpBB 3.2.0 ou une version ultérieure. Pour utiliser cet outil sous phpBB 3.2.x, merci de télécharger de télécharger la version adaptée de l’extension : « Obscure Contact Us ».',
	'OBSCURECONTACTUS_REQUIRE_3.2.0'		=> 'Cette extension requiert phpBB 3.2.0 ou une version plus récente et ne fonctionnera pas avec toutes les versions antérieures de phpBB.',
));
