<?php
/**
*
* @package phpBB Extension - Hidden Poll
* @copyright (c) 2018 FranckTH - http://www.graphogames.fr/Relax/
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace franckth\hiddenpoll\migrations;

class hiddenpoll_schema extends \phpbb\db\migration\migration
{
	public function update_data()
	{
		return array(

			array('config.add', array('hiddenpoll_version', '1.0.0')),
		);
	}

	public function revert_data()
	{
		return array(

			array('config.remove', array('hiddenpoll_version', '1.0.0')),
		);
	}
}
