<?php
/**
*
* @package phpBB Extension - Hidden Poll
* @copyright (c) 2018 FranckTH
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!defined('IN_PHPBB'))
{
    exit;
}

if (empty($lang) || !is_array($lang))
{
    $lang = array();
}

$lang = array_merge($lang, array(
    'HIDDENPOLL'    => 'Vous ne pourrez voir les résultats qu’après la clôture du sondage',
    'HIDDENPOLL_TITLE'   	=> '@ Team Relax'
)); 