<?php
/**
*
* phpBB3 SEO Sitemap extension for the phpBB Forum Software package.
* French translation by Galixte (http://www.galixte.com)
*
* @copyright (c) 2015 Shredder <http://www.phpbb-work.ru>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'SEOMAP'						=> 'Plan du site SEO',
	'SEOMAP_VERSION'				=> 'Version de l’extension : %s. Merci de consulter <a style="font-weight: bold;" href="https://www.phpbb.com/customise/db/extension/seo_sitemap/" onclick="window.open(this.href);return false;">la page de l’extension</a> pour obtenir la dernière version ou pour obtenir de l’aide avec cette extension.',
	'SEOMAP_EXPLAIN'				=> 'Merci de porter une attention toute particulière à l’utilisation des options de priorité et aux paramètres de la fréquence d’actualisation qui sont en mesure d’apporter de réels gains positifs. Avant de prendre toutes décisions, il est recommandé d’utiliser ces paramètres conjointement d’une analyse personnelle des pages devant être considérées comme plus importantes que d’autres. Sans connaissance des ces informations il est préférable de désactiver ces options. <a href="http://www.sitemaps.org/protocol.html#xmlTagDefinitions" onclick="window.open(this.href);return false;">Cliquer ici</a> pour en lire davantage sur les priorités et les fréquences d’actualisations.<br /> Saisir 0 pour désactiver la priorité.',
	'SEOMAP_SETTINGS'				=> 'Paramètres du plan du site SEO',
	'SEOMAP_SETTINGS_UPDATED'		=> '<strong>Mise à jour des paramètres du plan du site SEO</strong>',
	'SEOMAP_SAVED'					=> 'Les paramètres du plan du site SEO ont été mis à jour avec succès.',
	'SEOMAP_EXCLUDED'				=> 'Forums exclus',
	'SEOMAP_EXCLUDED_EXPLAIN'		=> 'Permet de sélectionner les forums et leurs sujets exclus du plan du site.<br /><strong>Merci de noter que :</strong> les catégories et les forums n’ayant aucun sujet sont exclus par défaut.',
	'SEOMAP_CACHE_TIME'				=> 'Durée du cache',
	'SEOMAP_CACHE_TIME_EXPLAIN'		=> 'Permet de réduire la charge du serveur, le plan du site sera mis en cache pendant une durée déterminée. Après celle-ci, il sera à nouveau créé. Saisir le nombre d’heures durant lesquelles le plan du site sera mis en cache ou saisir 0 pour désactiver la mise en cache.',
	'SEOMAP_URL'					=> 'Adresse URL du plan du site : <a href="%s" onclick="window.open(this.href);return false;">%s</a>',
	'SEOMAP_URL_COUNT'				=> 'Nombre d’adresses URL totalisées dans le plan du site : %s',
	'SEOMAP_URL_LIMIT'				=> 'Limite du nombre d’adresses URL',
	'SEOMAP_URL_LIMIT_EXPLAIN'		=> 'Permet de saisir le nombre maximum d’adresse URL prises en charge dans le fichier du plan du site, le protocole SITEMAP du plan du site peut en gérer jusqu’à 50 000. Diminuer cette valeur si des problèmes concernant des limites dépassées sont constatés. Si le nombre total d’adresses URL sur le forum dépasse ce nombre le plan du site sera automatiquement divisé en plusieurs fichiers.',
	'SEOMAP_BATCH_SIZE'				=> 'Taille préférée du traitement par lots',
	'SEOMAP_BATCH_SIZE_EXPLAIN'		=> 'Permet de diminuer la taille du traitement de la génération des données su plan du site lorsque des erreurs concernant la limite de mémoire allouée par le language PHP sont constatées. Merci de noter que la génération du plan du site augmentera significativement pour chaque diminution de la valeur de la taille du traitement.',
	'SEOMAP_PRIORITY_0'				=> 'Priorité pour les sujets par défaut',
	'SEOMAP_PRIORITY_1'				=> 'Priorité pour les post-it',
	'SEOMAP_PRIORITY_2'				=> 'Priorité pour les annonces',
	'SEOMAP_PRIORITY_3'				=> 'Priorité pour les annonces globales',
	'SEOMAP_PRIORITY_4'				=> 'Priorité pour les messages',
	'SEOMAP_PRIORITY_F'				=> 'Priorité pour les forums',
	'SEOMAP_FREQ_0'					=> 'Fréquence d’actualisation pour les sujets par défaut',
	'SEOMAP_FREQ_1'					=> 'Fréquence d’actualisation pour les post-it',
	'SEOMAP_FREQ_2'					=> 'Fréquence d’actualisation pour les annonces',
	'SEOMAP_FREQ_3'					=> 'Fréquence d’actualisation pour les annonces globales',
	'SEOMAP_FREQ_4'					=> 'Fréquence d’actualisation pour les messages',
	'SEOMAP_FREQ_F'					=> 'Fréquence d’actualisation pour les forums',
	'SEOMAP_FREQ_NEVER'				=> 'Jamais',
	'SEOMAP_FREQ_YEARLY'			=> 'Annuel',
	'SEOMAP_FREQ_MONTHLY'			=> 'Mensuel',
	'SEOMAP_FREQ_WEEKLY'			=> 'Hebdomadaire',
	'SEOMAP_FREQ_DAILY'				=> 'Quotidienne',
	'SEOMAP_FREQ_HOURLY'			=> 'Chaque heure',
	'SEOMAP_FREQ_ALWAYS'			=> 'Tout le temps',
	'SEOMAP_NO_DATA'				=> 'Il n’y a aucune donnée disponible pour le plan du site.',
	'SEOMAP_NO_FILE'				=> 'Impossible d’ouvrir le fichier :<br /><strong>%s</strong>',
	'SEOMAP_CANT_WRITE'				=> 'Le répertoire <strong>%s</strong> n’existe pas ou ne possède pas les permissions en écriture. Merci de corriger ceci au moyen du logiciel client FTP utilisé.',
	'SEOMAP_COPYRIGHT'				=> 'Extensions & MOD pour phpBB',

// Sync section
	'SEOMAP_SYNC_COMPLETE' 			=> 'Synchronisation terminée avec succès.<br /><br /><a style="font-weight: bold;" href="%s">&laquo; Retour aux paramètres</a>',
	'SEOMAP_SYNC_PROCESS'			=> '<strong>Synchronisation en cours. Merci de ne pas fermer cette page ni interrompre le script avant qu’il ait terminé toutes ses opérations.</strong><br /><br /><strong>%1$s%%</strong> terminé. Traitement de <strong>%2$s</strong> messages. Nombre total de messages : <strong>%3$s</strong>.',
	'SEOMAP_SYNC_REQ' 				=> 'Merci de synchroniser les dates de modification des messages avant d’utiliser le plan du site. Ceci est nécessaire pour générer la date de la dernière modification des pages du forum. <a style="font-weight: bold;" href="%s">Cliquer ici pour synchroniser</a>.',
));
