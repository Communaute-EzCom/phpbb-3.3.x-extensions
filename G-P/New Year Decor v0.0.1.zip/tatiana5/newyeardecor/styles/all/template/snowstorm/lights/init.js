var urlBase = './ext/tatiana5/newyeardecor/styles/all/template/snowstorm/lights/'; 
soundManager.url = './ext/tatiana5/newyeardecor/styles/all/template/snowstorm/lights/'; 