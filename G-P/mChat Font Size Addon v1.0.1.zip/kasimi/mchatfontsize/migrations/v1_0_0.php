<?php

/**
 *
 * @package phpBB Extension - mChat in Forums and Topics
 * @copyright (c) 2016 kasimi - https://kasimi.net
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace kasimi\mchatfontsize\migrations;

use phpbb\db\migration\migration;

class v1_0_0 extends migration
{
	static public function depends_on()
	{
		return array('\dmzx\mchat\migrations\mchat_2_0_0_rc7');
	}

	public function update_data()
	{
		return array(
			array('config.add', array('mchat_font_size', 12)),
			array('permission.add', array('u_mchat_font_size', true)),
		);
	}

	public function update_schema()
	{
		return array(
			'add_columns' => array(
				$this->table_prefix . 'users' => array(
					'user_mchat_font_size' => array('USINT', 12),
				),
			),
		);
	}

	public function revert_schema()
	{
		return array(
			'drop_columns' => array(
				$this->table_prefix . 'users' => array(
					'user_mchat_font_size',
				),
			),
		);
	}
}
