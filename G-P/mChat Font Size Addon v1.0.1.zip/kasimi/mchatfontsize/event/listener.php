<?php

/**
 *
 * @package phpBB Extension - mChat Font Size
 * @copyright (c) 2016 kasimi - https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatfontsize\event;

use dmzx\mchat\core\settings;
use phpbb\template\template;
use phpbb\user;
use Symfony\Component\EventDispatcher\Event;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	/** @var user */
	protected $user;

	/** @var template */
	protected $template;

	/** @var settings */
	protected $settings;

	/**
	 * Constructor
	 *
	 * @param user		$user
	 * @param template	$template
	 * @param settings	$settings
	 */
	public function __construct(
		user $user,
		template $template,
		settings $settings = null
	)
	{
		$this->user		= $user;
		$this->template	= $template;
		$this->settings	= $settings;
	}

	/**
	 * @return array
	 */
	static public function getSubscribedEvents()
	{
		return array(
			'dmzx.mchat.render_page_after'								=> 'render_page_after',

			// Inject our settings
			'dmzx.mchat.ucp_settings_modify'							=> 'ucp_settings_modify',

			// UCP and ACP settings
			'core.permissions'											=> array('permissions', -10),
			'core.acp_users_prefs_modify_template_data'					=> array('add_lang', 10),
			'dmzx.mchat.acp_globalusersettings_modify_template_data'	=> array('add_lang', 10),
			'dmzx.mchat.ucp_modify_template_data'						=> array('add_lang', 10),
		);
	}

	/**
	 * @param Event $event
	 */
	public function render_page_after($event)
	{
		$this->template->assign_var('MCHAT_FONT_SIZE', $this->settings->cfg('mchat_font_size'));
	}

	/**
	 * @param Event $event
	 */
	public function add_lang($event)
	{
		if ($this->settings !== null)
		{
			$this->user->add_lang_ext('kasimi/mchatfontsize', array('mchatfontsize_ucp'));
		}
	}

	/**
	 * @param object $event
	 */
	public function ucp_settings_modify($event)
	{
		$event['ucp_settings'] = array_merge($event['ucp_settings'], array(
			'mchat_font_size' => array(
				'default'		=> 12,
				'validation'	=> array('num', false, 6, 99),
			),
		));
	}

	/**
	 * @param Event $event
	 */
	public function permissions($event)
	{
		$category = 'mchat_user_config';

		$new_permissions = array(
			'u_mchat_font_size',
		);

		$categories = $event['categories'];

		if (!empty($categories[$category]))
		{
			$permissions = $event['permissions'];

			foreach ($new_permissions as $new_permission)
			{
				$permissions[$new_permission] = array(
					'lang' => 'ACL_' . strtoupper($new_permission),
					'cat' => $category,
				);
			}

			$event['permissions'] = $permissions;
		}
	}
}
