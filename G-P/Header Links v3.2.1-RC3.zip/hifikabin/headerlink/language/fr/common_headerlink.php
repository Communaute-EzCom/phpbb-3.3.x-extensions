<?php
/**
 *
 * Header Link. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 HiFiKabin
 * @license GNU General Public License, version 2 (GPL-2.0-only)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'ACP_HEADERLINK_CONFIG_EXPLAIN'				=> 'Aperçu et configuration des liens de l’entête.' ,
	'ACP_HEADERLINK_INSTRUCTIONS'				=> 'Page de configuration des liens comprenant chacun un nom et une URL.',

	'ACP_HEADERLINK_NOTES'						=> 'Il est possible de modifier et de supprimer (en laissant le champ de l’URL vide) n’importe quel lien. Le résulat de la configuration définie ci-après sera visible dès lors que cette page aura été enregistrée.<br>',
	'ACP_HEADERLINK_URL'						=> 'Liens',
	'ACP_HEADERLINK_URL_EXPLAIN'				=> 'Toutes les URL saisies doivent comprendre « http:// ». En laissant ce champ vide celui-ci sera supprimé.<br>',
	'ACP_HEADERLINK_NAME'						=> 'Nom du lien',
	'ACP_HEADERLINK_NAME_EXPLAIN'				=> 'Permet de saisir le nom du lien.<br>',
	'ACP_HEADERLINK_HOVER'						=> 'Survol de la souris',
	'ACP_HEADERLINK_HOVER_EXPLAIN'				=> 'Permet de saisir le texte affiché au survol du lien par la souris.<br>',
	'ACP_HEADERLINK_ICON_EXPLAIN'				=> 'Permet d’obtenir les codes de la police de caractères « Font Awesome » en cliquant sur le bouton ci-dessous. Saisir le code dans le champ, tel que par exemple : fa-credit-card.<br>',
	'ACP_HEADERLINK_ICON'						=> 'Icône FA',
	'ACP_HEADERLINK_ICON_CODE'					=> 'Code l’icône « Font Awesome »',
	'ACP_HEADERLINK_ICON_COLOUR'				=> 'Couleur de l’icône',
	'ACP_HEADERLINK_TEXT_SHADOW'				=> 'Ombre portée du texte :',
	'ACP_HEADERLINK_TEXT_SHADOW_COLOUR'			=> 'Couleur de l’ombre portée',
	'ACP_HEADERLINK_COLOUR'						=> 'Couleurs',
	'ACP_HEADERLINK_COLOUR_EXPLAIN'				=> 'Les couleurs du bouton, de l’ombre portée et du texte doivent être saisies en HEXADECIMAL, tel que : #FF0000 ou via leur nom, tel que : red.<br>',
	'ACP_HEADERLINK_COLOUR_FINDER'				=> 'Palette de couleurs',
	'ACP_HEADERLINK_COLOUR_FINDER_EXPLAIN'		=> 'Permet de sélectionner une couleur en cliquant sur le champ ci-dessous, pour afficher la palette de couleurs disponibles, puis en copiant le code affiché afin de le coller dans le champ concerné.',
	
	'ACP_HEADERLINK_ENABLE'						=> 'Activer les liens de l’entête',
	'ACP_HEADERLINK_HOVER_COLOUR'				=> 'Couleur au survol du bouton',
	'ACP_HEADERLINK_HOVER_COLOUR_EXPLAIN'		=> 'Permet de définir la couleur affichée lors du survol du bouton par la souris.',
	'ACP_HEADERLINK_NAVBAR'						=> 'Emplacement de la barre des liens de l’entête',

	'ACP_HEADERLINK_SWITCH_IN_HEADER'			=> 'Dans l’entête',
	'ACP_HEADERLINK_SWITCH_UNDER_HEADER'		=> 'Sous l’entête',
	'ACP_HEADERLINK_SWITCH_IN_NAVBAR'			=> 'Dans la barre de navigation',

	'ACP_HEADERLINK_HIDE'						=> 'Masquer',
	'ACP_HEADERLINK_SHOW'						=> 'Afficher',

	'ACP_HEADERLINK_URL'						=> 'URL',
	'ACP_HEADERLINK_NAME'						=> 'Nom du lien',
	'ACP_HEADERLINK_HOVER'						=> 'Survol de la souris',
	'ACP_HEADERLINK_TARGET'						=> 'Ouvrir le lien dans',
	'ACP_HEADERLINK_SAME'						=> 'le même onglet',
	'ACP_HEADERLINK_NEW'						=> 'un nouvel onglet',

	'ACP_HEADERLINK_PERMISSION'					=> 'Permission d’afficher ce lien',
	'ACP_HEADERLINK_DISABLE'					=> 'personne',
	'ACP_HEADERLINK_GUEST'						=> 'seulement aux invités',
	'ACP_HEADERLINK_MEMBER'						=> 'seulement aux membres',
	'ACP_HEADERLINK_ACTIVE'						=> 'à tous',
	'ACP_HEADERLINK_ADMIN'						=> 'seulement aux administrateurs',
	'ACP_HEADERLINK_MOD'						=> 'seulement aux modérateurs',

	'ACP_HEADERLINK_BUTTON_COLOUR'				=> 'Couleur du bouton',
	'ACP_HEADERLINK_TEXT_COLOUR'				=> 'Couleur du texte',

	'ACP_HEADERLINK_MORE_LINKS'					=> 'Ajouter un nouveau lien',

	'HEADERLINK_CONFIG'							=> 'Paramètres des liens de l’entête',
	'HEADERLINK_SAVED'							=> 'Paramètres des liens de l’entête enregistrés',

	'HEADERLINK_MENU'							=> 'Liens',
	'HEADERLINK_MENU_HOVER'						=> 'Afficher les liens',
));
